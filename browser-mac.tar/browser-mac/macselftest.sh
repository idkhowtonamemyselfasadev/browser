#!/bin/sh
# macselftest.sh -- the whole of what only a Mac can answer, in one go.
#
# Nothing in this edition has ever been started on the platform it
# targets. This script is how that stops being true.
#
# It does two things:
#
#   A. finds out everything a machine can find out by itself -- what
#      this Mac is, what Python and Qt are here, whether the install
#      worked, whether the suite is green, how fast it is;
#
#   B. prints ONE block, with those facts already filled in and 24
#      blank lines for the things only a person can answer.
#
# You copy that one block, type your answers after the colons, and
# paste it back in a message. That is the whole job. There is no file
# to go and find, and the script does not ask you 24 questions one at
# a time.
#
# RUNS ON A STOCK MAC. System /bin/sh only. It never needs Homebrew,
# never runs pip, and never touches a command that would pop up the
# "install the command line developer tools" dialog. If this Mac has
# no developer tools it says so in the block and carries on -- that is
# itself one of the answers we need.
#
# Usage
#   sh macselftest.sh              everything, then print the block
#   sh macselftest.sh --sheet      just the questions, run nothing
#   sh macselftest.sh --ask        ask them one at a time instead
#   sh macselftest.sh --quick      skip the slow benchmarks
#   sh macselftest.sh --no-install skip the install step
#   sh macselftest.sh --out FILE   where the full log goes

set -u
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
EDITION="$HERE/browser-mac"
OUT="$HERE/logs/macselftest-$(date +%Y%m%d-%H%M%S).txt"
SHEET=""
ASK=""
INSTALL="yes"
QUICK=""
LEFTOVERS=""

while [ $# -gt 0 ]; do
  case "$1" in
    --sheet)      SHEET="yes" ;;
    --ask)        ASK="yes" ;;
    --no-install) INSTALL="" ;;
    --quick)      QUICK="--quick" ;;
    --leftovers)  LEFTOVERS="yes" ;;
    # the value is required and may not be another flag. `--out` with
    # nothing after it used to fall back to the default, which is at
    # least harmless; `--out --quick` silently took "--quick" as the
    # FILENAME and then ran without --quick, so the run was slower than
    # asked for and the log landed in a file called --quick. Same shape
    # as install-mac.sh's --to, found the same afternoon.
    --out)        shift
                  [ $# -ge 1 ] || { echo "--out needs a filename" >&2
                                    exit 2; }
                  case "$1" in
                    ""|-*) echo "--out needs a filename, not \"$1\"" >&2
                           exit 2 ;;
                  esac
                  OUT="$1" ;;
    -h|--help)    sed -n '2,33p' "$0"; exit 0 ;;
    *) echo "unknown option: $1" >&2; exit 2 ;;
  esac
  shift
done

# =====================================================================
# --leftovers: QA plan section 18, the half that can only be answered
# AFTER the app is in the Bin.
#
# "Uninstall cleanly, what is left behind, is there an option to keep
# or remove user data" -- there is no uninstaller here at all, so the
# answer is whatever dragging browser.app to the Bin leaves on the
# disk. This prints exactly that and nothing else, so it can be run on
# its own at the very end and pasted back.
#
# It only ever LISTS. It deletes nothing: what to remove is the user's
# decision, and a self-test that tidies up after itself would also be
# destroying the evidence it was run to collect.
# =====================================================================
if [ -n "$LEFTOVERS" ]; then
  echo "8<----------------- COPY FROM HERE -----------------"
  echo "browser macOS leftovers -- $(date '+%Y-%m-%d %H:%M')"
  echo "(run after dragging browser.app to the Bin)"
  echo
  still=0
  for d in "$HOME/Applications/browser.app" "/Applications/browser.app"; do
    if [ -e "$d" ]; then
      echo "APP STILL THERE:   ${d#"$HOME"/}"
      still=1
    fi
  done
  [ "$still" = "0" ] && echo "the app itself:    gone"
  echo
  echo "what it left behind:"
  found=0
  # every place this edition is known to write, named one by one rather
  # than found by a wildcard sweep of the home folder: a guess that
  # matched something of the user's own would read as the browser's.
  for d in \
    "$HOME/Library/Application Support/browser" \
    "$HOME/Library/Caches/browser" \
    "$HOME/Library/Caches/com.browser.app" \
    "$HOME/Library/Preferences/com.browser.app.plist" \
    "$HOME/Library/Saved Application State/com.browser.app.savedState" \
    "$HOME/Library/WebKit/com.browser.app" \
    "$HOME/Library/HTTPStorages/com.browser.app" \
    "$HOME/Library/Logs/browser"
  do
    if [ -e "$d" ]; then
      sz=$(du -sk "$d" 2>/dev/null | awk '{printf "%.1f MB", $1/1024}')
      echo "  LEFT  ${sz:-?}  ${d#"$HOME"/}"
      found=$((found + 1))
    fi
  done
  [ "$found" = "0" ] && echo "  nothing in any of the places it writes"
  echo
  echo "login items / launch agents of its own:"
  la=0
  for d in "$HOME/Library/LaunchAgents"/*browser* ; do
    [ -e "$d" ] && { echo "  LEFT  ${d#"$HOME"/}"
                     la=$((la + 1)); }
  done
  [ "$la" = "0" ] && echo "  none (expected -- this browser installs none)"
  echo
  echo "NOTE: your settings, bookmarks and passwords are the"
  echo "'Application Support/browser' line. Nothing removed them,"
  echo "which is on purpose -- but there is no uninstaller offering"
  echo "to, and that is the finding."
  echo "8<------------------ COPY TO HERE ------------------"
  exit 0
fi

mkdir -p "$(dirname -- "$OUT")" 2>/dev/null || true
: > "$OUT" 2>/dev/null || OUT=/dev/null

FACTS="${TMPDIR:-/tmp}/macselftest.facts.$$"
: > "$FACTS"
trap 'rm -f "$FACTS" "$FACTS.ans"' EXIT INT TERM

# say  -> progress, on screen and in the log, NOT in the block
# fact -> one line of the block, and in the log
say()  { printf '%s\n' "$*"; printf '%s\n' "$*" >> "$OUT"; }
fact() { printf '%s\n' "$*" >> "$FACTS"; printf '%s\n' "$*" >> "$OUT"; }
rule() { say "------------------------------------------------------------"; }

# =====================================================================
# the questions
#
# tier | Test ID | QA area | short label | what to do | what to look for
#
# The Test IDs and areas are the ones in the QA plan
# (~/claude/browser-pages/briefs/QA-PLAN.md), so an answer that comes
# back drops straight into that report's test log instead of having to
# be translated into it first.
#
# TIER 1 is the ten minutes. Those are the questions whose answers are
# BLOCKED here and cannot be got any other way: there is no Mac on this
# side, so sections 1, 2, 6, 12, 13, 16 and 18 of the plan are guesses
# until a person on real hardware answers them. TIER 2 is everything
# else worth knowing, clearly marked optional, so the coverage is not
# silently dropped just because the first ten minutes were the budget.
# =====================================================================
questions() {
cat <<'Q'
1|MAC-01-01|1 install|it starts at all|Run install-mac.sh, then open browser.app from Applications.|Did a window appear, and did you need one of the START-HERE step-5 escapes (Open Anyway / right-click Open / xattr)? Say which. If it never opened, paste the exact error.
1|MAC-01-02|1 install|first run|Watch the very first launch closely.|What did it show you before the start page? Any onboarding, any "make me your default browser", any offer to import bookmarks or passwords? (list what appeared, or "nothing")
1|MAC-02-01|2 UI|the traffic lights|Look at the top-left corner of the window, next to Safari for comparison.|Are close/minimise/zoom there, top-LEFT, the right size and the right spacing, and does the title bar look like a Mac title bar? (yes / or what is off)
1|MAC-02-02|2 UI|Command or Control|Press Cmd+T, Cmd+W, Cmd+L, Cmd+F, Cmd+R, Cmd+1..9, Cmd+Shift+T. Then Cmd+/ for the cheat sheet and LOOK at how the keys are written.|Two answers. (a) did every shortcut work with Command? Name any that needed Control. (b) does the cheat sheet show the Mac symbols like Cmd-T, or does it still print the word "Ctrl"?
1|MAC-02-03|2 UI|native dialogs|Open Settings -> Downloads -> pick a folder. Then right-click a link, an image, selected text, and blank page.|Is the folder picker the real macOS one, and do the four right-click menus look native? (yes / or which one looks wrong)
1|MAC-02-04|2 UI|Retina|Look at toolbar text, tab labels and page text on the built-in display.|Crisp at the panel's real resolution, or soft/blurry anywhere? (crisp / where it is soft)
1|MAC-06-01|6 media|DRM video|Open Netflix, Amazon Music or an ARD stream and play something.|Does protected video play? (plays / black / error text)
1|MAC-06-02|6 media|H.264|Open a Twitch stream, then play any .mp4 you have.|Did both play? (both / which failed) -- the codecs line in the block below says what the build has
1|MAC-12-01|12 perf|launch feel|The block below has three MEASURED launches. Now click the Dock icon yourself.|From click to a usable window, does it feel instant, a beat, or slow? (instant / a-beat / slow)
1|MAC-12-02|12 perf|memory, ten tabs|Open ten ordinary tabs (news, YouTube, whatever you use). Wait a minute. Open Activity Monitor, Memory tab, and find browser plus every "browser Helper" row.|Add those rows up: how many GB? Also say what the biggest single row is. (On Linux the same code costs about 1.3 GB for 10 tabs - we have no Mac number at all, which is why this is being asked.)
1|MAC-13-01|13 a11y|keyboard only|Put the mouse down. Tab through the toolbar and through Settings.|Can you reach every control, and can you always SEE which one has focus? (yes / what you could not reach or could not see)
1|MAC-13-02|13 a11y|VoiceOver|Press Cmd+F5 to turn VoiceOver on, move through the toolbar and a page, then Cmd+F5 off.|Does it name the buttons and read the page, or is it silent / does it read nonsense? (names-them / silent / nonsense)
1|MAC-18-01|18 update|the Update button|Settings -> scroll to the updater and press Update.|What exactly does it say? (paste the sentence -- it should mention browser-mac.tar.gz and install-mac.sh, NOT a "zip" and NOT a git clone)
1|MAC-18-02|18 uninstall|uninstall|LAST. Quit the browser, drag browser.app to the Bin, then run: sh macselftest.sh --leftovers|Paste what that prints. It lists what the browser left behind.
2|MAC-02-05|2 UI|the icon|Look at it in the Dock next to Safari, Mail and Finder.|Does its rounded square line up with theirs, same size and corners? (yes/too-big/too-small/wrong-corners)
2|MAC-02-06|2 UI|the menu bar|Look at the menu bar while the browser is in front.|What is in it? (expected: only the app menu with About/Quit -- this browser has no menus of its own)
2|MAC-02-07|2 UI|closing last window|Close the only window with the red button.|Did the whole app quit, or is it still running with no window? (quit/still-running)
2|MAC-02-08|2 UI|system theme|Switch macOS between Light and Dark in System Settings while the browser is open.|Does the browser follow, and does it look right both ways? (follows/ignores/looks-wrong-one-way)
2|MAC-02-09|2 UI|two-finger swipe|On a page with history behind it, swipe back with two fingers on the trackpad.|Nothing should happen -- it is deliberately OFF here. Do you MISS it? (dont-care / want-it)
2|MAC-02-10|2 UI|two screens|Drag the window to an external monitor and back, with the Dock look on.|Smooth and sharp on both? (yes / what went wrong)
2|MAC-06-03|6 media|HEVC|Open an ARD or ZDF live stream.|Plays, or "Wiedergabefehler"? (plays/error -- an error is EXPECTED unless PyQt6 came from Homebrew)
2|MAC-06-04|6 media|picture in picture|Play a video, then send it to picture-in-picture, then full screen.|Do both work and stay on top properly? (both / which failed)
2|MAC-06-05|6 media|media keys|Play a video, then press the play/pause key on the keyboard.|Does it pause the browser? (yes / nothing-happens) -- "nothing" is the EXPECTED answer, Qt cannot speak macOS Now Playing
2|MAC-06-06|6 media|subtitles button|Open the player (Settings -> Play a file), click "Subtitles...".|Does anything at all happen? "Nothing" is the expected answer -- the button is known dead and we want it confirmed from the outside. (nothing / something -- say what)
2|MAC-12-06|12 perf|Speedometer|Open browserbench.org/Speedometer3.0 and run it once.|What score? (a number)
2|MAC-12-03|12 perf|video CPU|Play a 1080p60 video full screen, watch Activity Monitor.|Browser CPU percent, and does it drop frames? (e.g. "25%, no drops")
2|MAC-12-04|12 perf|idle, ten tabs|Open ten ordinary tabs, leave it five minutes, look at Activity Monitor.|CPU while idle, and can you hear the fan? (e.g. "1.5%, silent")
2|MAC-12-05|12 perf|scrolling|Scroll a long page with the trackpad. Then Settings -> Look -> Dock and run the mouse along the pinned row.|Does scrolling have proper momentum, and does the magnification glide or step? (both-smooth / what stutters)
2|MAC-16-01|16 stability|frozen page|Open the console on any page and run: while(true){}|Does a "page is not responding" dialog appear and can you kill just that tab? (dialog / whole-browser-freezes)
2|MAC-16-02|16 stability|sleep and wake|Close the lid or let the Mac sleep with tabs open, then wake it.|Does it come back cleanly, and do pages still work? (clean / what broke)
2|MAC-10-01|10 privacy|screen sharing|Open a call site and try to share your screen BEFORE granting anything.|Does it warn that Screen Recording is not granted, or hand over a blank picture? (warns/blank/works)
2|MAC-10-02|10 privacy|screen permission|Grant System Settings -> Privacy -> Screen Recording, restart, open the mic/camera test page.|Does the call panel now say screen sharing can work? (yes/no/still-unknown)
2|MAC-10-03|10 privacy|the firewall|Settings -> switch on "Take a page off the phone".|Did macOS ask about incoming connections, and did it work once allowed? (asked-and-works/asked-and-denied/never-asked)
2|MAC-10-04|10 privacy|where things land|Download a file, then look in Finder.|Did it land in ~/Downloads, and is anything of the browser's in Documents, Desktop or iCloud Drive? (downloads-ok / name what is misplaced)
2|MAC-02-11|2 UI|notification text|Settings -> Notifications on, then let a page send one (or finish a download).|Real words, or just "--"? (words/dashes)
2|MAC-02-12|2 UI|screen stays awake|Settings -> "Keep the screen awake while a video plays", play fullscreen, leave the mouse past your screen-off time.|Did the screen stay on, then sleep again within a minute or two of stopping? (yes/no/partly)
2|MAC-02-13|2 UI|read aloud|Open any article, press Cmd+Alt+V.|Does a voice read it, in the interface language? (yes / what happened)
2|MAC-16-03|16 stability|back from background|Leave the browser behind another app for ten minutes, then click it.|Does it come back immediately, or stall for a moment first? (immediate/stalls)
2|MAC-02-15|2 UI|the glass look|Settings -> Look -> Classic, then Theme -> any dark theme. Look at the toolbar and the dock island.|Solid and deliberate, or see-through and glitchy? (solid/see-through)
2|MAC-02-14|2 UI|screenshots|Cmd+Shift+S, then Cmd+Alt+Shift+S, then open the files.|Sharp at the panel's real resolution, and are password fields blurred? (sharp+blurred / soft / password-visible)
Q
}

print_questions() {
  n1=$(questions | awk -F'|' '$1==1' | wc -l | tr -d ' ')
  n2=$(questions | awk -F'|' '$1==2' | wc -l | tr -d ' ')
  echo "What only a Mac can answer. $n1 that matter most, then $n2 more."
  echo
  echo "TIER 1 -- about ten minutes. Please do these."
  echo "These are the ones nobody on the other side can answer at all:"
  echo "there is no Mac there, so the whole of QA plan sections 1, 2, 6,"
  echo "12, 13, 16 and 18 is guesswork until you answer them."
  echo
  questions | while IFS='|' read -r tier id area name what look; do
    [ "$tier" = "1" ] || continue
    printf '%s  [%s]  %s\n    do:   %s\n    ask:  %s\n\n' \
      "$id" "$area" "$name" "$what" "$look"
  done
  echo "------------------------------------------------------------"
  echo "TIER 2 -- optional, another twenty minutes or so."
  echo "Worth having, not worth blocking on. Skip any of them freely;"
  echo "a blank is an honest answer and a guess is not."
  echo
  questions | while IFS='|' read -r tier id area name what look; do
    [ "$tier" = "2" ] || continue
    printf '%s  [%s]  %s\n    do:   %s\n    ask:  %s\n\n' \
      "$id" "$area" "$name" "$what" "$look"
  done
}

if [ -n "$SHEET" ]; then
  print_questions
  exit 0
fi

# =====================================================================
# Finding a Python WITHOUT waking the Xcode prompt.
#
# /usr/bin/python3 on a Mac with no developer tools is not Python. It
# is a stub whose whole job is to pop up a window asking to install
# them. Running it to "see if Python is there" is how a zero-setup
# script stops being zero-setup, so it is never run blind: the stub is
# only Python once xcode-select reports a developer directory, and
# until then we look in the places a real Python actually installs to.
# Same reasoning for xattr and codesign further down.
# =====================================================================
HAVE_CLT=""
if /usr/bin/xcode-select -p >/dev/null 2>&1; then HAVE_CLT="yes"; fi

PY=""
if [ -n "${BROWSER_PYTHON:-}" ] && [ -x "${BROWSER_PYTHON}" ]; then
  PY="$BROWSER_PYTHON"
else
  for cand in /opt/homebrew/bin/python3 /usr/local/bin/python3 \
              /Library/Frameworks/Python.framework/Versions/Current/bin/python3 \
              /Library/Frameworks/Python.framework/Versions/3.13/bin/python3 \
              /Library/Frameworks/Python.framework/Versions/3.12/bin/python3 \
              /Library/Frameworks/Python.framework/Versions/3.11/bin/python3; do
    [ -x "$cand" ] && { PY="$cand"; break; }
  done
  # /usr/bin/python3 is only safe to touch once the tools are really in
  if [ -z "$PY" ] && [ -n "$HAVE_CLT" ] && [ -x /usr/bin/python3 ]; then
    PY=/usr/bin/python3
  fi
fi

say "browser -- macOS self test"
say "$(date)"
say ""
say "Working. This takes a few minutes; the block you send back comes"
say "at the end."
say ""

# =====================================================================
rule; say "1. what this machine is"; rule
fact "--- machine ---"
fact "uname:         $(uname -a 2>/dev/null)"
fact "hardware:      $(sysctl -n machdep.cpu.brand_string 2>/dev/null || echo '?')"
fact "Apple Silicon: $(sysctl -n hw.optional.arm64 2>/dev/null || echo 'no (or not a Mac)')"
fact "Rosetta:       $(sysctl -n sysctl.proc_translated 2>/dev/null || echo 0)"
fact "macOS:         $(sw_vers -productVersion 2>/dev/null || echo 'not macOS')"
fact "memory:        $(( $(sysctl -n hw.memsize 2>/dev/null || echo 0) / 1073741824 )) GB"
if [ -n "$HAVE_CLT" ]; then
  fact "dev tools:     installed"
else
  fact "dev tools:     NOT installed"
fi
fact "homebrew:      $( [ -x /opt/homebrew/bin/brew ] && echo 'yes (arm)' || { [ -x /usr/local/bin/brew ] && echo 'yes (intel path)' || echo 'no'; } )"

if [ -n "$PY" ]; then
  fact "python:        $PY"
  fact "python arch:   $("$PY" -c 'import platform;print(platform.machine())' 2>/dev/null || echo '?')"
  fact "python build:  $("$PY" -c 'import sys;print(sys.version.replace(chr(10)," "))' 2>/dev/null || echo '?')"
  "$PY" - <<'PYEOF' >> "$FACTS" 2>/dev/null || true
try:
    from PyQt6.QtCore import QT_VERSION_STR
    import PyQt6.QtCore as c
    print("Qt:            " + QT_VERSION_STR)
    print("QtCore at:     " + c.__file__)
except Exception as exc:
    print("Qt:            PyQt6 NOT INSTALLED (%s)" % exc)
try:
    from PyQt6.QtWebEngineCore import qWebEngineChromiumVersion as v
    print("Chromium:      " + v())
except Exception as exc:
    print("Chromium:      QtWebEngine NOT INSTALLED (%s)" % exc)
PYEOF
  QTLIB=$("$PY" -c 'import PyQt6.QtCore as m;print(m.__file__)' 2>/dev/null || true)
  if [ -n "$QTLIB" ] && [ -n "$HAVE_CLT" ]; then
    fact "PyQt6 arch:    $(/usr/bin/file -b "$QTLIB" 2>/dev/null | tr ',' '\n' | grep -Eo 'arm64|x86_64' | sort -u | tr '\n' ' ')"
  elif [ -n "$QTLIB" ]; then
    fact "PyQt6 arch:    unknown (no developer tools, cannot run file)"
  fi
else
  fact "python:        NONE FOUND"
  fact "Qt:            cannot look -- no python"
  if [ -z "$HAVE_CLT" ]; then
    fact "               (no developer tools either, so /usr/bin/python3"
    fact "                is only a prompt, not a Python. Not run.)"
  fi
fi
cat "$FACTS" | tail -20
say ""

# =====================================================================
rule; say "2. the install"; rule
if [ -n "$INSTALL" ] && [ -d "$EDITION" ]; then
  # how long it takes is one of the plan's section-1 questions, and
  # `date +%s` is in the base system where `time`'s output format is
  # not worth parsing
  T0=$(date +%s)
  ( cd "$EDITION" && BROWSER_PYTHON="${PY:-python3}" sh install-mac.sh ) >> "$OUT" 2>&1
  INST=$?
  T1=$(date +%s)
  say "install-mac.sh exit=$INST  (full output in the log)"
  fact "--- install ---"
  fact "install-mac.sh: exit $INST"
  fact "install took:  $((T1 - T0)) s"
  tail -3 "$OUT" | sed 's/^/install: /' >> "$FACTS"
else
  say "skipped"
  fact "--- install ---"
  fact "install-mac.sh: skipped"
fi

APP="$HOME/Applications/browser.app"
[ -d "$APP" ] || APP="/Applications/browser.app"
APP_BIN="$APP/Contents/MacOS/browser"
if [ -d "$APP" ]; then
  fact "bundle:        $APP"
  # the plan's other section-1 number. -k because BSD du has no -b.
  fact "disk use:      $(du -sk "$APP" 2>/dev/null | awk '{printf "%.1f MB", $1/1024}')"
  # xattr is a developer-tools stub too; ls -l@ is in the base system
  if [ -n "$HAVE_CLT" ] && [ -x /usr/bin/xattr ]; then
    fact "quarantine:    $(/usr/bin/xattr -p com.apple.quarantine "$APP" 2>/dev/null || echo 'none (good)')"
  else
    fact "quarantine:    $(ls -l@d "$APP" 2>/dev/null | grep -c 'com.apple.quarantine' | sed 's/^0$/none (good)/;s/^[1-9].*/PRESENT/')"
  fi
  if [ -n "$HAVE_CLT" ] && [ -x /usr/bin/codesign ]; then
    fact "signature:     $(/usr/bin/codesign -dv "$APP" 2>&1 | head -2 | tr '\n' ' ')"
  else
    fact "signature:     not checked (no developer tools)"
  fi
else
  fact "bundle:        NOT FOUND -- question 1 will be 'no'"
fi
say ""

# =====================================================================
rule; say "3. the suite"; rule
fact "--- suite ---"
if [ -n "$PY" ] && [ -f "$EDITION/tools/runall.sh" ]; then
  SUITE="${TMPDIR:-/tmp}/macselftest.suite.$$"
  ( cd "$EDITION" && BROWSER_PYTHON="$PY" sh tools/runall.sh ) > "$SUITE" 2>&1
  SRC=$?
  cat "$SUITE" >> "$OUT"
  tail -6 "$SUITE"
  if grep -q '^all green' "$SUITE"; then
    fact "result:        all green"
  else
    fact "result:        FAILED (exit $SRC)"
    grep '^FAILED:' "$SUITE" 2>/dev/null | head -3 | sed 's/^/suite: /' >> "$FACTS"
  fi
  rm -f "$SUITE"
else
  say "no python, or no suite here"
  fact "result:        not run (no python)"
fi
say ""
say "A green suite proves the shared code behaves. It proves nothing"
say "about any of the questions below."
say ""

# =====================================================================
rule; say "4. the benchmark"; rule
fact "--- benchmark ---"
if [ -n "$PY" ] && [ -f "$EDITION/tools/macbench.py" ]; then
  BENCH="${TMPDIR:-/tmp}/macselftest.bench.$$"
  ( cd "$EDITION" && "$PY" tools/macbench.py $QUICK \
      --json "$HERE/logs/macbench-darwin.json" ) > "$BENCH" 2>&1 || true
  cat "$BENCH" >> "$OUT"
  tail -20 "$BENCH"
  # the codecs line is MAC-06-02; carry it into the block
  grep -iE 'codec|h\.264|h264|aac|hevc' "$BENCH" 2>/dev/null | head -6 \
    | sed 's/^[[:space:]]*/codecs: /' >> "$FACTS"
  grep -iE '^[[:space:]]*(startup|first paint|cold|warm|memory|rss)' "$BENCH" 2>/dev/null \
    | head -8 | sed 's/^[[:space:]]*/bench:  /' >> "$FACTS"
  rm -f "$BENCH"
else
  say "no python, or no benchmark here"
  fact "result:        not run (no python)"
fi
say ""
say 'A QtWebEngine installed from a pip wheel has NO H.264, NO HEVC and'
say 'NO AAC, so Twitch, .mp4 files and the ARD/ZDF live streams cannot'
say 'play on any hardware. "brew install pyqt" gives a build that has'
say 'them. That is what MAC-06-02 and MAC-06-03 are for.'
say ""

# =====================================================================
# 5. the launches, MEASURED
#
# The QA plan wants three runs averaged, and until today the only way
# to read this number was to open Settings and look at it -- which on
# the one platform where it is an open question meant a stopwatch and a
# single run. browser.py prints it under BROWSER_TIMING=1 now, so a
# script can take it properly: one genuinely first-ever launch against
# an empty profile, then three warm ones against that same profile.
#
# Each run is the REAL app if browser.app is installed, launcher and
# bundle and all, and it is ended the moment it reports its number.
# Windows will appear and vanish a few times. That is this section.
# =====================================================================
rule; say "5. the launches, measured"; rule
fact "--- launches ---"

LPROF="${TMPDIR:-/tmp}/macselftest.lprof.$$"
LLOG="${TMPDIR:-/tmp}/macselftest.launch.$$"
rm -rf "$LPROF"

# the real bundle if it is there, otherwise this folder's browser.py
if [ -x "$APP_BIN" ]; then
  LAUNCH_WHAT="browser.app (the installed bundle)"
else
  LAUNCH_WHAT="browser.py in this folder (browser.app not found)"
fi
fact "measured on:   $LAUNCH_WHAT"

one_launch() {
  : > "$LLOG"
  if [ -x "$APP_BIN" ]; then
    BROWSER_TIMING=1 BROWSER_HOME="$LPROF" "$APP_BIN" >"$LLOG" 2>&1 &
  else
    [ -n "$PY" ] || return 1
    ( cd "$EDITION" && BROWSER_TIMING=1 BROWSER_HOME="$LPROF" \
        "$PY" browser.py >"$LLOG" 2>&1 ) &
  fi
  lpid=$!
  # wait for its own number, up to 90 s
  j=0
  while [ "$j" -lt 900 ]; do
    grep -q 'startup total' "$LLOG" 2>/dev/null && break
    kill -0 "$lpid" 2>/dev/null || break
    sleep 0.1 2>/dev/null || sleep 1
    j=$((j + 1))
  done
  kill "$lpid" 2>/dev/null
  wait "$lpid" 2>/dev/null
  # 2>/dev/null: the shell announces a killed job on some shells
  sed -n 's/.*startup total *\([0-9.]*\) ms.*/\1/p' "$LLOG" | head -1
}

if [ -n "$PY" ] || [ -x "$APP_BIN" ]; then
  FIRST=$(one_launch)
  fact "first ever:    ${FIRST:-could not measure} ms  (empty profile)"
  say "first ever:    ${FIRST:-could not measure} ms"
  WARM=""
  i=1
  while [ "$i" -le 3 ]; do
    W=$(one_launch)
    fact "warm run $i:    ${W:-could not measure} ms"
    say "warm run $i:    ${W:-could not measure} ms"
    [ -n "$W" ] && WARM="$WARM $W"
    i=$((i + 1))
  done
  if [ -n "$WARM" ] && [ -n "$PY" ]; then
    AVG=$("$PY" -c 'import sys
v=[float(x) for x in sys.argv[1:] if x]
print("%.1f" % (sum(v)/len(v)) if v else "")' $WARM 2>/dev/null)
    fact "warm average:  ${AVG:-?} ms  (of $(echo $WARM | wc -w | tr -d " ") runs)"
  fi
else
  fact "result:        not run (no python and no browser.app)"
fi
rm -rf "$LPROF"; rm -f "$LLOG"
say ""
say "That is click-to-window as the browser itself measures it. How it"
say "FEELS is MAC-12-01, and only you can answer that."
say ""

# =====================================================================
# the questions, either as one block or one at a time
# =====================================================================
: > "$FACTS.ans"

rule
say "6. the questions only a Mac can answer"
rule

if [ -n "$ASK" ]; then
  # Asking needs the terminal, and the terminal is NOT stdin here: the
  # loop below is fed by `questions`, so a bare `read` would eat the
  # next question instead of waiting for a person. It reads from the
  # controlling terminal on fd 3 or it does not ask at all.
  if [ -r /dev/tty ]; then
    exec 3</dev/tty
    questions | while IFS='|' read -r tier id area name what look; do
      printf '\n%s  [%s]  %s\n   DO:  %s\n   ASK: %s\n   > ' \
        "$id" "$area" "$name" "$what" "$look"
      read -r answer <&3 || answer=""
      [ -n "$answer" ] || answer=""
      printf '%-11s %-24s : %s\n' "$id" "$name" "$answer" >> "$FACTS.ans"
    done
    exec 3<&-
  else
    say "--ask needs a terminal; printing the blank block instead."
    ASK=""
  fi
fi

if [ -z "$ASK" ]; then
  print_questions | tee -a "$OUT"
  {
    echo "--- TIER 1: the ten minutes. Please answer these. ---"
    questions | while IFS='|' read -r tier id area name what look; do
      [ "$tier" = "1" ] || continue
      printf '%-11s %-24s : \n' "$id" "$name"
    done
    echo
    echo "--- TIER 2: optional. Blank is fine. ---"
    questions | while IFS='|' read -r tier id area name what look; do
      [ "$tier" = "2" ] || continue
      printf '%-11s %-24s : \n' "$id" "$name"
    done
  } >> "$FACTS.ans"
fi

# =====================================================================
# THE BLOCK. This is the deliverable.
# =====================================================================
BLOCK="${TMPDIR:-/tmp}/macselftest.block.$$"
{
  echo "8<----------------- COPY FROM HERE -----------------"
  echo "browser macOS report -- $(date '+%Y-%m-%d %H:%M')"
  echo "UNVERIFIED BUILD: this browser had never been run on a Mac"
  echo "before this report."
  echo
  cat "$FACTS"
  echo
  echo "--- the answers (type yours after the colon) ---"
  cat "$FACTS.ans"
  echo
  echo "--- anything else you noticed ---"
  echo ": "
  echo "8<------------------ COPY TO HERE ------------------"
} > "$BLOCK"

echo
echo
cat "$BLOCK"
cat "$BLOCK" >> "$OUT"
rm -f "$BLOCK"

echo
echo "============================================================"
if [ -n "$ASK" ]; then
  echo "DONE. Copy the block above -- everything between the two"
  echo "scissor lines -- and paste it back to whoever sent you this."
else
  echo "DONE. Copy the block above -- everything between the two"
  echo "scissor lines -- into a message, type your answers after the"
  echo "colons, and send it back."
  echo
  echo "The questions are printed in full just above the block."
  echo "Anything you cannot test, leave blank. A blank is an honest"
  echo "answer and a guess is not."
fi
echo
echo "Nothing is verified until that block comes back, however green"
echo "the suite above was."
echo "(A full log, if you ever need it: $OUT)"
echo "============================================================"
