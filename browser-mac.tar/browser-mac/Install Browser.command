#!/bin/bash
# ============================================================================
#  Install Browser  --  double-click this file. That is the whole install.
# ============================================================================
#
# This is the one file your friend touches. Double-clicking it opens Terminal
# and does every step that used to be pasted by hand: it gets Homebrew (the
# thing that brings the video-capable Qt), installs that Qt, builds browser.app
# and drops it in your Applications, then opens it.
#
# Why Terminal still shows up: a Mac has no Python with video-capable Qt out of
# the box, and the only way to add it without a Mac to pre-build on is Homebrew,
# which must run in a shell and asks for your password once. You do not type any
# commands -- you just watch, and type your login password when macOS asks.
#
# First time you double-click, macOS may say "unidentified developer" and
# refuse. That is normal for anything not from the App Store. Right-click the
# file (or Control-click) -> Open -> Open. You only do that once.
#
# It installs nothing as root, nothing runs at login, nothing runs in the
# background. Everything lands in your own home folder. ERASE.command removes it.
set -e

# Double-clicked, the working directory is your home folder, not this folder.
cd "$(dirname "$0")"
HERE="$(pwd)"
EDITION="$HERE/browser-mac"

say()  { printf '\n\033[1m%s\033[0m\n' "$*"; }
ok()   { printf '  \033[32m%s\033[0m\n' "$*"; }
die()  { printf '\n\033[31m%s\033[0m\n\n' "$*"; echo "Press Return to close."; read -r _; exit 1; }

clear
echo "============================================================"
echo "  Installing browser - macOS edition"
echo "============================================================"

[ -d "$EDITION" ] || die "Can't find the browser-mac folder next to this installer.
Unpack the whole browser-mac.tar.gz first, then double-click this file inside it."

# ---- 1. Apple Silicon vs Intel: decides where Homebrew lives -----------------
ARCH="$(uname -m)"
if [ "$ARCH" = "arm64" ]; then
  BREW_PREFIX="/opt/homebrew"
else
  BREW_PREFIX="/usr/local"
  say "Heads up: this is an Intel Mac ($ARCH)."
  echo "  It will work, but the browser runs best on Apple Silicon (M1-M4)."
fi
BREW="$BREW_PREFIX/bin/brew"

# ---- 2. Homebrew -------------------------------------------------------------
if [ -x "$BREW" ]; then
  ok "Homebrew already here."
else
  say "Step 1 of 3 - installing Homebrew (this is the step that asks for your password)."
  echo "  Type your Mac login password when it asks. You won't see the characters; that's normal."
  NONINTERACTIVE=1 /bin/bash -c \
    "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)" \
    || die "Homebrew install failed. Check your internet connection and try again."
  [ -x "$BREW" ] || die "Homebrew installed but isn't where expected ($BREW)."
  ok "Homebrew installed."
fi
eval "$("$BREW" shellenv)"

# ---- 3. The Qt with video codecs --------------------------------------------
if "$BREW" list pyqt >/dev/null 2>&1; then
  ok "Qt (pyqt) already installed."
else
  say "Step 2 of 3 - installing the browser engine (pyqt). This takes 10-20 minutes."
  echo "  Good time for a coffee. It's downloading and building a lot; that's expected."
  "$BREW" install pyqt || die "Installing pyqt failed. Run this installer again - it picks up where it stopped."
  ok "Engine installed."
fi

PYBIN="$BREW_PREFIX/bin/python3"
[ -x "$PYBIN" ] || PYBIN="$("$BREW" --prefix)/bin/python3"
[ -x "$PYBIN" ] || die "Homebrew's python3 isn't where expected. Open ERASE.command, then try again."

# ---- 4. Build the app and put it in ~/Applications --------------------------
say "Step 3 of 3 - building browser.app and putting it in your Applications."
mkdir -p "$HOME/Applications"
BROWSER_PYTHON="$PYBIN" sh "$EDITION/install-mac.sh" --to "$HOME/Applications" \
  || die "The app build failed. The messages just above say why."
ok "browser.app is in your Applications folder."

# ---- 5. Open it -------------------------------------------------------------
APP="$HOME/Applications/browser.app"
say "Done. Opening it now."
echo "  If macOS says \"unidentified developer\": right-click browser.app in"
echo "  Applications -> Open -> Open. Once only."
echo
open "$APP" 2>/dev/null || true
echo "From now on, launch it from your Applications folder (or Launchpad)."
echo
echo "Press Return to close this window."
read -r _
