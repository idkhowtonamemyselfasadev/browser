#!/bin/bash
# ============================================================================
#  Erase Browser  --  double-click to remove everything the browser installed.
# ============================================================================
# Removes the app and the data it wrote, all in your own home folder. Leaves
# Homebrew and pyqt, since you may want them for other things (remove those
# yourself with:  brew uninstall pyqt).
cd "$(dirname "$0")"
echo "This removes browser.app and its data from your home folder."
printf "Type  yes  to continue: "
read -r a
[ "$a" = "yes" ] || { echo "Nothing removed."; echo "Press Return to close."; read -r _; exit 0; }

rm -rf "$HOME/Applications/browser.app"
rm -rf "$HOME/Library/Application Support/browser"
rm -rf "$HOME/Library/Caches/browser"
echo
echo "Done. browser.app and its data are gone."
echo "Homebrew and pyqt were left in place (brew uninstall pyqt to remove the engine)."
echo
echo "Press Return to close."
read -r _
