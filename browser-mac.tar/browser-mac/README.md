# browser, the macOS edition

A third edition of the browser (`~/browser`, Linux, PyQt6 +
QtWebEngine), for **Apple Silicon, macOS 12 or newer**. It is
generated out of the Linux one rather than forked, so a feature
written once arrives in all three.

> **UNVERIFIED — never executed.**
>
> **Nobody has ever started this on a Mac.** The owner does not own one
> (confirmed 2026-10-26), there is no emulator for it and none was
> borrowed. Everything in here was built and tested on a Linux
> machine: every `darwin` branch is exercised with a faked `sys`, every
> parser is fed real `ps`/`say`/`Info.plist`/`.icns` input, the whole
> Linux suite is green against the same shared file, and the
> performance work whose cost is platform-independent is measured with
> the numbers written down. **None of that is the same thing as
> working.** `PORT.md`'s last section lists the twenty-four questions
> only a real Mac can answer, and `macselftest.sh` walks them.

---

## What to do on a fresh Mac

1. `brew install pyqt` — **not** `pip install PyQt6`. Both give you a
   working browser, but the pip wheel's QtWebEngine is built without
   the patent-encumbered codecs: **no H.264, no HEVC, no AAC**, so
   Twitch, any `.mp4` and the ARD/ZDF live streams will not play on any
   hardware. Measured, not assumed — `PORT.md` §5h. Homebrew's
   `qtwebengine` is built with those codecs on, and on Apple Silicon it
   is arm64 native, which is the other thing that matters.
2. `cd browser-mac && BROWSER_PYTHON=/opt/homebrew/bin/python3 sh install-mac.sh`
3. It prints the architecture of the machine, of the Python and of the
   Qt build, says which engine you got, and **refuses** if anything
   would run under Rosetta. That refusal is the single most useful
   thing this script does: a translated Chromium is the biggest source
   of lag available on that machine and it looks like a broken browser,
   not like a wrong install.
4. Open `~/Applications/browser.app` **by right-clicking → Open** the
   first time. It is not notarised, so a double-click is refused with
   no reason given.
5. For screen sharing in a call: System Settings → Privacy & Security
   → Screen Recording → tick browser. macOS gives an app no way to ask
   for this, so nothing in the browser will prompt you.
6. To make it the default: System Settings → Desktop & Dock → Default
   web browser.
7. Then run `sh macselftest.sh` from the folder above and answer the
   questions it asks. That file is the evidence this edition has never
   had.

---

## What is in here

    browser-mac/        the generated macOS edition -- this is what ships
    browser-mac/tools/  the port (mac_port.py + .json), the suite runner,
                        the benchmark (macbench.py) and its test page
    tools/              the two one-off builders: the icon, the first edits
    logs/               suite runs and benchmark JSON
    macselftest.sh      the one command to run on a real Mac
    START-HERE.txt      the install sheet that goes to the person with
                        the Mac -- nine steps, no jargon
    pack/               make.sh builds the tarball that leaves the
                        house; scan.py is the gate it has to pass
    PORT.md             parity table, the drop list with reasons, the
                        performance work with its numbers, and the list
                        of what only a Mac can answer
    HANDBACK-mac.md     the progress log, newest entry last
    .venv/              PyQt6 6.11 for running the suite here

This folder is self-contained and safe to move: everything it needs is
inside it except `~/browser`, which is the **source of truth** for
every feature and is referenced by absolute path on purpose.

---

## Handing it to somebody with a Mac

    sh pack/make.sh

Builds `pack/browser-mac.tar.gz` (5.8 MB), which unpacks to a folder with
`START-HERE.txt` at the top. That sheet is written for the person with the
Mac, not for a session: nine numbered steps, the reason behind each one, and
an uninstall block.

`make.sh` names what goes **in**, never what stays out. An exclude list is a
list of the leaks somebody thought of. `.git` is not in the package: its
history still carries a LAN address and the old bundle identifier (the
one built from the owner's own domain), and deleting a file does not take a
commit back.

**Nothing is written until `pack/scan.py` passes.** It reads every byte of
the staged tree against `~/claude/gitguard/personal.txt` and exits non-zero
on a hit, which stops `make.sh` before the tarball exists. The git hooks are
no help here at all — a tarball is not a commit — and this is the one case
the guard exists for, because the person receiving it is not the owner. Its first
run found 38 hits, including his username in a folder placeholder visible
in the settings page and his subnet in a UI hint in **both** languages.

It greps bytes, not a list of file extensions. The last sweep that trusted
`--include='*.py' --include='*.md'` came back clean twice while the hit sat in
an `Info.plist`.

The thing to ask for back is the one file `macselftest.sh` prints the path to.

---

## How a port is done

Features are written in `~/browser`, behind `sys.platform == "darwin"`
where they differ — **never in `browser-mac/`**, which is generated and
would lose the edit at the next port.

```sh
cd browser-mac
python3 tools/mac_port.py --to main --dry-run    # say what would change
python3 tools/mac_port.py --to main              # do it
python3 tools/mac_port.py --check                # every marker, no rewrite
PATH=~/claude/browser-mac/.venv/bin:$PATH sh tools/runall.sh
```

`tools/mac_port.json` is the data: what is three-way merged, what is
copied, the substitutions (font stacks macOS has no fonts for, settings
rows that named a Linux program), the files this edition owns, what
deliberately does not come across and why, and the markers that must
still hold afterwards. A failed marker writes nothing at all.

`--to worktree` ports the Linux **working tree**, uncommitted work
included. That is how this edition was born and `mac_port.json` records
it (`ported_from_worktree`), because a three-way merge whose base does
not contain what was ported hands those lines back again. When
`--dry-run` says **"would change: nothing"**, the port is idempotent —
which is the only real proof of it.

## How it is tested

```sh
cd browser-mac
PATH=~/claude/browser-mac/.venv/bin:$PATH sh tools/runall.sh   # ~100 files
```

and in the Linux repository, the one that matters most:

```sh
cd ~/browser && python3 test_macbranch.py      # every darwin branch, here
```

`test_macbranch.py` lives in `~/browser` on purpose: it runs in the
**Linux** suite, so a darwin branch cannot rot the way the Windows
edition's hand-kept regions did. **`hand_regions` is `[]` and must stay
`[]`** — `test_mac.py` asserts it.

## How it is measured

```sh
cd browser-mac
python3 tools/macbench.py --json ../logs/macbench-linux.json
python3 tools/macbench.py --list      # the eight benches
python3 tools/macbench.py --quick     # skip the slow ones
```

Eight benches: the CPython compile cost, the per-paint cost of the Qt
layer at 1× and 2×, startup, a cold process against a warm one, frames
a second over a heavy page, a 1080p60 clip, ten tabs idle, and how the
housekeeping timers are spread. Everything runs offscreen against a
throwaway profile — it never touches the browser you use.

The Linux column is filled in. **The macOS column is empty and
labelled `unmeasured`.** It is not estimated and not scaled from the
Linux number.

## What to remember

* **Features go in `~/browser`.** A fix typed into
  `browser-mac/browser.py` is gone at the next port.
* **`hand_regions` stays `[]`.** The Windows edition's three are the
  part of that port that rots.
* **Never write that something works on macOS.** The honest words are
  *"unverified — needs a Mac"*, and `PORT.md` has a section for exactly
  that. Every claim is either a command run on this box with its
  result, or a numbered question in that section.
* **Another session may own `~/browser`.** Check before editing the
  shared file, keep the log in `HANDBACK-mac.md`, and hand anything
  that is not Mac-specific to whoever owns the Linux file instead of
  fixing it behind their back.
* **The icon is the browser's own `icon.svg`**, converted and fitted to
  the shape every macOS icon is — not new art. `tools/mkicns.py`
  rebuilds it from the SVG at any time. New artwork, if it is ever
  needed, is made with `imagegen` (`~/claude/imagegen2/bin/ig2`), never
  drawn in code.
