macselftest.sh writes its report in here. That file is the one to send
back.
