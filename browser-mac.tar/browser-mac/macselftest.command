#!/bin/bash
# Double-click to run the self-test and print the block to send back.
cd "$(dirname "$0")"
sh macselftest.sh
echo
echo "Copy the block above and send it back. Press Return to close."
read -r _
