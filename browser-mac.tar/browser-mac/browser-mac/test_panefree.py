#!/usr/bin/env python3
"""A page you closed stops costing you a renderer.

open_pane caches every one of the browser's own pages it builds, in
self._panes, so that reopening one is instant. Nothing ever took one
out again: close_pane calls dismiss(), and dismiss() only hides. Each
pane is a whole QWebEngineView with its own renderer process behind it.

Measured on this box, 2026-10-29, before the fix: visiting seven of the
browser's own pages once and closing every one of them held 725.8 MiB
for the rest of the session -- about 104 MiB a page, 172 for Settings --
with nothing on screen. After: free_idle_panes() gives 454 MiB of that
back, which is the whole of the cached-pane part of it. (The remainder
is not a leak and is not this file's business: notes.html is a panel
rather than a pane, and the player is a real tab the user opened.)

What has to stay true, and is what this file checks:

  * the pane he just closed is KEPT. Closing Settings and opening it
    again is an ordinary move, and rebuilding it in that moment is the
    one time freeing it would be felt.
  * everything else is freed, and the memory really comes back -- not
    just the dict entry.
  * a freed page still opens. The cache is an optimisation; losing it
    may cost a moment and may never cost a feature.
  * a VISIBLE pane is never freed, whatever it is asked.

Offscreen, scratch profile. mac-only until upstream takes it.
"""
import os
import sys
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
os.environ.setdefault("BROWSER_NO_LIB_CHECK", "1")
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from _boot import B                       # noqa: E402
from tests.harness import app, spin       # noqa: E402

fails = []


def check(what, ok, detail=""):
    print(("  ok   " if ok else "  FAIL ") + what
          + (("  <" + str(detail) + ">") if detail != "" else ""))
    if not ok:
        fails.append(what)


def tree_rss_kb(root=None):
    """This process and every child, resident, from the kernel."""
    root = root or os.getpid()
    kids = {}
    for p in Path("/proc").iterdir():
        if not p.name.isdigit():
            continue
        try:
            ppid = int((p / "stat").read_text()
                       .rsplit(") ", 1)[1].split()[1])
            kids.setdefault(ppid, []).append(int(p.name))
        except (OSError, ValueError, IndexError):
            continue
    total, stack = 0, [root]
    while stack:
        pid = stack.pop()
        try:
            with open("/proc/%d/statm" % pid) as fh:
                total += int(fh.read().split()[1])
        except (OSError, ValueError, IndexError):
            pass
        stack.extend(kids.get(pid, []))
    return total * (os.sysconf("SC_PAGE_SIZE") // 1024)


qapp = app()
win = B.Browser()
win.show()
spin(2000)

print("(1) the cache fills, as it is meant to")
base = tree_rss_kb()
for opener in ("open_history", "open_downloads", "open_bookmarks",
               "open_settings"):
    fn = getattr(win, opener, None)
    if fn is None:
        continue
    fn()
    spin(2500)
    win.close_pane()
    spin(600)
cached = sorted((win._panes or {}).keys())
check("panes were built and kept", len(cached) >= 3, cached)
held = tree_rss_kb()
check("...and they cost real memory (MiB over baseline)",
      (held - base) / 1024.0 > 100, "%.1f" % ((held - base) / 1024.0))

print("\n(2) the one he just closed is kept, the rest are freed")
# close_pane armed the timer with the pane it dismissed; ask directly
# so the test does not wait PANE_FREE_AFTER_MS
keep_name = cached[-1]
keep = (win._panes or {}).get(keep_name)
freed = win.free_idle_panes(keep=keep)
check("something was freed", bool(freed), freed)
check("...and the kept one was not", keep_name not in freed, freed)
check("...and it is still in the cache",
      keep_name in (win._panes or {}), sorted((win._panes or {}).keys()))
spin(5000)
after = tree_rss_kb()
back = (held - after) / 1024.0
check("the memory actually came back (MiB)", back > 50, "%.1f" % back)

print("\n(3) a freed page still opens")
gone = freed[0]
opener = {"history": "open_history", "downloads": "open_downloads",
          "bookmarks": "open_bookmarks", "settings": "open_settings"}.get(gone)
check("the freed page has an opener to test", bool(opener), gone)
if opener:
    getattr(win, opener)()
    spin(3000)
    check("%s reopens after being freed" % gone, win.pane_open(gone) is True)
    check("...and is back in the cache", gone in (win._panes or {}))

print("\n(4) a pane that is ON SCREEN is never freed")
# one is open right now, from (3)
open_now = win._pane
check("a pane is up", open_now is not None and win.pane_open())
freed2 = win.free_idle_panes(keep=None)
check("the visible pane survived being asked",
      open_now is win._pane and win.pane_open(),
      "freed: %s" % freed2)
check("...and it is still cached", gone in (win._panes or {}),
      sorted((win._panes or {}).keys()))

print("\n(5) and it is safe to call with nothing to do")
win.close_pane()
spin(600)
win.free_idle_panes()
check("twice over, no exception", win.free_idle_panes() == [])

print("\n%d checks failed" % len(fails))
for f in fails:
    print("  - " + f)
sys.stdout.flush()
os._exit(1 if fails else 0)
