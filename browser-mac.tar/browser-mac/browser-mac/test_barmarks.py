#!/usr/bin/env python3
"""The marks beside the address: do they ever actually appear?

The bar is supposed to say two things about the page itself -- that the
connection is plain http, and that the name in front of you is dressed
up as another one. Both are real, both are translated, both have a
working detector behind them (lookalike_warning, tested as a function
in test_bar.py), and on 2026-10-29 neither had ever been seen on screen.

The reason is one line:

    parsed = QUrl(str(url or ""))

str() of a QUrl is not an address, it is the repr:

    "PyQt6.QtCore.QUrl('https://example.com/')"

and QUrl() of that parses to an empty host. Every real navigation
reaches the bar as a QUrl -- urlChanged emits one, _url_changed passes
it on to show_address, show_address hands it to update_bar_marks -- so
host was always "", lookalike_warning was always asked about "", and
the else branch hid both marks on every single page load. The only
caller that worked was restore_address (Escape in the bar), which
happens to pass a string.

Browser._host_of already existed for exactly this, and its docstring
says so: "str(QUrl) is "PyQt6.QtCore.QUrl(...)", not an address: every
place that takes either has to come through here." Five places did not.
Four of them were broken in the same way and are checked here too:
save_link_target (Alt+click on a link, and both context menus, all of
which hand it a QUrl -- so it saved nothing, ever), group_rule_for and
session_rule_for (new_tab is "sometimes handed a QUrl", see _tab_url),
and discord_route (which loaded the repr into the Discord tab).

The second bug was hiding behind the first. Showing a mark does not
place it: left alone the label keeps its default 100x30 at (0,0), which
is on top of the lock button and over the first inch of the address.
place_bar_extras is what knows where the extras go and how much margin
the text needs, and update_bar_marks never called it. Nobody had seen
it because nobody had seen the mark.

So this test asks the question the function-level tests cannot: drive
the real path with the real argument type, and look at what the widget
says and where it sits.

Offscreen, scratch data, one local http server. Nothing reaches the
network.
"""
import os
import sys
from pathlib import Path

os.environ["QT_QPA_PLATFORM"] = "offscreen"
os.environ["BROWSER_NO_LIB_CHECK"] = "1"
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE / "tests"))

import harness as H  # noqa: E402
B = H.boot()
from PyQt6.QtCore import QUrl  # noqa: E402

fails = []


def check(what, ok, detail=""):
    print(("  ok   " if ok else "  FAIL ") + what
          + (("  <" + str(detail) + ">") if detail != "" else ""))
    if not ok:
        fails.append(what)


app = H.app()
srv = H.Server({"/plain.html": "<title>plain</title><h1>over http</h1>"})
win = B.Browser()
win.resize(1100, 700)
win.show()
H.spin(400)
lbl = win._securelbl
lock = win._barextras["lockbtn"]

# the three attacks, in the punycode a real address arrives as, and the
# names that must stay quiet. "whole-script" is the all-Cyrillic one
# that mixes nothing and so slips past a mixed-script rule.
LOUD = (
    ("https://xn--pple-43d.com/", "mixed script: apple with a Cyrillic a"),
    ("https://xn--pypal-4ve.com/", "mixed script: paypal with a Cyrillic a"),
    ("https://xn--80ak6aa92e.com/", "whole script: all-Cyrillic apple"),
    ("https://rnicrosoft.com/", "rn read as m: microsoft"),
)
QUIET = (
    ("https://apple.com/", "the real apple.com"),
    ("https://example.com/", "an ordinary https name"),
    ("https://xn--mnchen-3ya.de/", "muenchen.de, a legitimate IDN"),
    ("https://xn--bcher-kva.de/", "buecher.de, a legitimate IDN"),
)

print("(1) a look-alike name, handed over the way a navigation hands it")
for url, name in LOUD:
    win.update_bar_marks(QUrl(url))
    H.spin(40)
    check("warned about " + name,
          lbl.isVisible() and lbl.property("state") == "bad",
          "vis=%s state=%s" % (lbl.isVisible(), lbl.property("state")))
    check("...and it says which name it reads as",
          "%" not in lbl.toolTip() and len(lbl.toolTip()) > 10,
          lbl.toolTip()[:60])

print("\n(2) ...and the names it must not cry wolf over")
for url, name in QUIET:
    win.update_bar_marks(QUrl(url))
    H.spin(40)
    check("quiet about " + name, not lbl.isVisible(),
          "vis=%s text=%r" % (lbl.isVisible(), lbl.text()))

print("\n(3) plain http says so")
win.update_bar_marks(QUrl("http://example.com/"))
H.spin(40)
check("http puts the mark up", lbl.isVisible(), lbl.isVisible())
check("...as a warning, not as a look-alike",
      lbl.property("state") == "warn", lbl.property("state"))
check("...and it is the translated string, not a key",
      lbl.text() == win._ui_str("barNotSecure"), lbl.text())

print("\n(4) a string still works, and says the same thing")
# restore_address passes a string; the two callers must not disagree
for url, _name in LOUD + QUIET + (("http://example.com/", ""),):
    win.update_bar_marks(QUrl(url))
    H.spin(20)
    as_url = (lbl.isVisible(), lbl.property("state"), lbl.text())
    win.update_bar_marks(url)
    H.spin(20)
    as_str = (lbl.isVisible(), lbl.property("state"), lbl.text())
    check("QUrl and string agree on " + url, as_url == as_str,
          "%s vs %s" % (as_url, as_str))

print("\n(5) the mark is put somewhere, not left at (0, 0)")
win.update_bar_marks(QUrl("http://example.com/"))
H.spin(60)
check("it is not sitting on the lock button",
      not lbl.geometry().intersects(lock.geometry()),
      "badge=%s lock=%s" % (lbl.geometry().getRect(),
                            lock.geometry().getRect()))
check("it is not still at the default (0, 0)",
      lbl.geometry().topLeft().x() > 0,
      lbl.geometry().getRect())
check("its whole text fits in it",
      lbl.width() >= lbl.sizeHint().width(),
      "%d wide, wants %d" % (lbl.width(), lbl.sizeHint().width()))
check("and the address starts to the right of it",
      win.urlbar.textMargins().left()
      >= lbl.geometry().x() + lbl.width(),
      "margin %d, badge ends at %d"
      % (win.urlbar.textMargins().left(),
         lbl.geometry().x() + lbl.width()))

print("\n(6) the four others that took str(QUrl) the same way")
win.config["groupRules"] = [{"group": "Mods", "match": "modrinth.com"}]
MOD = "https://modrinth.com/mod/x"
check("group_rule_for sees a QUrl",
      win.group_rule_for(QUrl(MOD)) == "Mods", win.group_rule_for(QUrl(MOD)))
check("...and still sees a string",
      win.group_rule_for(MOD) == "Mods", win.group_rule_for(MOD))
check("...and still says no to an address with no rule",
      win.group_rule_for(QUrl("https://example.com/")) is None,
      win.group_rule_for(QUrl("https://example.com/")))

win.sessions = list(getattr(win, "sessions", []) or [])
sids = {e["sid"] for e in win.sessions}
if sids:
    sid = sorted(sids)[0]
    win.config["sessionSites"] = {"modrinth.com": sid}
    check("session_rule_for sees a QUrl",
          win.session_rule_for(QUrl(MOD)) == sid,
          win.session_rule_for(QUrl(MOD)))
    check("...and agrees with the string form",
          win.session_rule_for(QUrl(MOD)) == win.session_rule_for(MOD),
          "%s vs %s" % (win.session_rule_for(QUrl(MOD)),
                        win.session_rule_for(MOD)))
else:
    print("  n/a  session_rule_for: this profile has no virtual browsers")

view = win.current()
check("save_link_target takes the QUrl all three menus hand it",
      win.save_link_target(QUrl("https://example.com/f.zip"), view) is True,
      win.save_link_target(QUrl("https://example.com/f.zip"), view))
check("...and still refuses a scheme it cannot download",
      win.save_link_target(QUrl("mailto:someone@example.com"), view)
      is False)
check("discord_route reads the host off a QUrl",
      B.Browser._host_of(QUrl("https://discord.com/channels/1"))
      == "discord.com",
      B.Browser._host_of(QUrl("https://discord.com/channels/1")))

print("\n(7) end to end: a real page over real http")
tab = win.new_tab(srv.url("/plain.html"))
H.wait_for(lambda: "over http" in (H.js(tab, "document.body.innerText")
                                   or ""), 8000)
win.tabs.setCurrentWidget(tab)
tab.setFocus()
H.spin(300)
# exactly what the engine does: urlChanged hands _url_changed a QUrl
win._url_changed(tab, tab.url())
H.spin(200)
check("the bar is showing the page", "plain.html" in win.urlbar.text(),
      win.urlbar.text())
check("...and the mark went up on its own",
      lbl.isVisible() and lbl.text() == win._ui_str("barNotSecure"),
      "vis=%s text=%r" % (lbl.isVisible(), lbl.text()))

print("\n%d check(s) failed" % len(fails))
for name in fails:
    print("  - " + name)
sys.stdout.flush()
os._exit(1 if fails else 0)
