#!/usr/bin/env python3
"""Every control on the nine pages has something wired to it.

Three guards now ask three different versions of "is this control
real", and each one caught something the others could not:

  test_histrender (1)  an element the script dereferences has to exist
                       -> caught a handler left behind by a deleted button
  test_bridgecalls     every bridge.X( has to be a method on the Bridge
                       -> caught playerQueue throwing on every player open
  this file            every control with an id has to be MENTIONED by
                       the page's own script, or driven from its markup

The third is the blunt one, and it is the one that answers the question
asked on bug-fix day: not "does this control's handler work" but "is
there a handler at all". The Subtitles button was the warning -- a
control that is shown is a promise, and it had none behind it.

It also happens to be the only check that covers this edition's two
exclusives from the outside: the call panel in mictest.html and the
phone-drop controls in settings.html exist in no other edition, so
nothing upstream will ever look at them.

A note on what this file is NOT allowed to do. The first draft of it
reported the two page-URL Save buttons as dead. They are wired at
settings.html by `getElementById(f.box + "save")`, built by
concatenation, and a report of two broken Save buttons that work
perfectly well would have cost somebody an afternoon. A detector with
false positives is not a weaker detector, it is a worse one: it is the
`grep` that matched the comment explaining the fix. Hence the
concatenation case below, and hence the self-test at the end that
injects a genuinely dead button and insists on finding it.

Static: reads the nine .html files. No Qt, no browser, no network,
writes nothing. Runs from anywhere. mac-only.
"""
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
fails = []


def check(what, ok, detail=""):
    print(("  ok   " if ok else "  FAIL ") + what
          + (("  <" + str(detail) + ">") if detail != "" else ""))
    if not ok:
        fails.append(what)


def orphans(text):
    """Controls in this page that nothing refers to."""
    script = "\n".join(re.findall(r"<script[^>]*>(.*?)</script>",
                                  text, re.S))
    ids = re.findall(
        r"<(?:button|select|textarea)\b[^>]*\bid=\"([A-Za-z0-9_\-]+)\"",
        text)
    ids += re.findall(r"<input\b[^>]*\bid=\"([A-Za-z0-9_\-]+)\"", text)
    out = []
    for cid in sorted(set(ids)):
        # named outright in the script
        if re.search(r"[\"']" + re.escape(cid) + r"[\"']", script):
            continue
        # driven from the markup: an inline handler, a form, a submit
        tag = re.search(r"<[^>]*\bid=\"" + re.escape(cid) + r"\"[^>]*>",
                        text)
        blob = tag.group(0) if tag else ""
        if re.search(r"\bon[a-z]+=|\bform=|\btype=\"(submit|hidden)\"",
                     blob):
            continue
        # a <label for=...> makes the control the label's business
        if re.search(r'for="' + re.escape(cid) + r'"', text):
            continue
        # an id built by concatenation: getElementById(f.box + "save")
        if any(re.search(r'\+\s*"' + re.escape(cid[i:]) + r'"', script)
               and re.search(r'"' + re.escape(cid[:i]) + r'"', script)
               for i in range(1, len(cid))):
            continue
        out.append(cid)
    return sorted(set(ids)), out


pages = sorted(HERE.glob("*.html"))
print("(1) nothing on any page is shown with nothing behind it")
check("the nine pages are there", len(pages) == 9, len(pages))

total = 0
for page in pages:
    text = page.read_text(encoding="utf-8")
    ids, dead = orphans(text)
    total += len(ids)
    check("%s: %d controls, all wired" % (page.name, len(ids)),
          not dead, ", ".join(dead))
check("and there are enough of them to be worth checking", total > 300,
      total)

print("\n(2) ...and it can tell, which is the part worth doubting")
# a real dead button, injected into the real page
victim = (HERE / "settings.html").read_text(encoding="utf-8")
hurt = victim.replace(
    "<button id=\"starturlsave\" data-str=\"pwSaveBtn\">Save</button>",
    "<button id=\"starturlsave\" data-str=\"pwSaveBtn\">Save</button>"
    "<button id=\"nothingwiredhere\">Do a thing</button>", 1)
check("the injection landed", hurt != victim)
_ids, dead = orphans(hurt)
check("a button with no handler is found", dead == ["nothingwiredhere"],
      dead)
# and the two that are wired by concatenation are NOT reported, which
# is the false positive this file was nearly shipped with
check("...and the concatenated Save buttons are not false positives",
      "starturlsave" not in dead and "newtaburlsave" not in dead, dead)

print("\n%d checks failed" % len(fails))
for f in fails:
    print("  - " + f)
sys.exit(1 if fails else 0)
