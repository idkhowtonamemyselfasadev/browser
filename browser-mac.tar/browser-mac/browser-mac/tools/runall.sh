#!/bin/sh
# The whole offscreen suite, in one go, with a tail of each run.
#
# This is the Linux runner with test_mac.py on the end. It is run on
# the Linux box, against the generated tree, and that is the whole of
# what it proves: the shared code behaves the same here as it does
# there. What only a Mac can answer is in ../PORT.md and is not
# claimed by a green run of this.
# Everything here redirects its own data into scratch; nothing touches
# the vault or the config of the browser you actually use.
#
# The exit status has to come from python, not from tail. Piping a test
# straight into `tail` reports tail's status, which is always 0 -- so
# every failure, every crash and every timeout read as a pass, and the
# suite said "all green" while it was not. It is written out to a file
# and tailed afterwards for exactly that reason.
R=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$R" || exit 1
export QT_QPA_PLATFORM=offscreen

# Two things a stock Mac has not got, and this is the runner that is
# meant to be run on one (macselftest.sh step 3):
#
#   * `python` -- macOS ships python3 and no unversioned alias, so a
#     bare `python` is "command not found" and every test reads as a
#     failure. BROWSER_PYTHON is the same variable the .app's launcher
#     honours, so one setting covers the browser and its suite.
#   * `timeout` -- that is GNU coreutils. macOS has neither it nor
#     `gtimeout` unless somebody installed coreutils. Without a
#     fallback the whole suite is "command not found" ninety times.
PY="${BROWSER_PYTHON:-python3}"
command -v "$PY" >/dev/null 2>&1 || PY=python
if command -v timeout >/dev/null 2>&1; then
  TMO="timeout 900"
elif command -v gtimeout >/dev/null 2>&1; then
  TMO="gtimeout 900"
else
  # no timeout anywhere: run it straight. A hung test then hangs the
  # suite, which is worse than being killed but far better than every
  # test being reported as failed.
  TMO=""
  echo "note: no timeout(1) here -- tests run without a time limit"
  echo "      (brew install coreutils gives you gtimeout)"
fi
echo "python: $PY  ($("$PY" -V 2>&1))"
# no browser started in here goes looking for library updates: a real
# dnf per test would be slow, would depend on what the distribution is
# shipping this morning, and could raise a toast over a window another
# test is inspecting. test_libs drives that check by hand instead.
export BROWSER_NO_LIB_CHECK=1

OUT=$(mktemp -d)
trap 'rm -rf "$OUT"' EXIT
bad=""

run() {
  echo "=== $1 ==="
  $TMO "$PY" "$1" > "$OUT/log" 2>&1
  rc=$?
  tail -3 "$OUT/log"
  echo "exit=$rc"
  [ "$rc" -eq 0 ] || bad="$bad $2"
}

# The mac-only guards go in this list too. They were not in it, and a
# guard that only runs when somebody types its name is not in the
# suite: six of them -- every one written on bug-fix day plus four from
# the day before -- would have been skipped by the tester's
# macselftest.sh step 3, which runs exactly this script. Found while
# adding the seventh.
for t in test_page.py test_newtab.py test_panes.py test_paneload.py \
         test_vaultoff.py \
         test_theme.py test_trust.py test_vault.py test_vaultguard.py \
         test_master.py test_masterrace.py test_providers.py \
         test_async.py test_upgrade.py test_op_page.py test_toolbar.py \
         test_wizard.py test_contrast.py test_themefix.py \
         test_favorites.py test_favclip.py test_update.py \
         test_libs.py test_looks.py test_navguard.py test_external.py \
         test_lifecycle.py test_deadtab.py test_libguard.py test_clicks.py \
         test_bpgame.py test_permreload.py test_callguard.py test_agent.py \
         test_saveimage.py test_screenshare.py test_sitetheme_render.py \
         test_tabwork.py test_tabwork2.py test_bookmarks2.py \
         test_addressbar.py \
         test_pagetools.py test_media.py \
         test_capture.py test_privacy.py test_pageguard.py \
         test_privacy2.py test_desk.py test_reading2.py \
         test_media2.py test_games.py test_forms.py test_downloads.py \
         test_bar.py test_dev.py test_look2.py test_a11y.py test_nav2.py test_perf2.py test_capture2.py test_keys2.py test_agent2.py test_read3.py test_privacy3.py test_marks3.py test_tools3.py test_block3.py test_gaps3.py test_setpage.py test_gpu.py \
         test_devtools.py test_keyboard.py \
         test_agentops.py test_reading.py test_gaming.py test_files.py \
         test_perf.py test_sitelook.py test_winbranch.py test_macbranch.py test_mac.py \
         test_idn.py test_gpurow.py test_deadcontrols.py \
         test_panefree.py test_barmarks.py test_tooltint.py; do
  [ -f "$t" ] || continue
  run "$t" "$t"
done

# The dock's paint caches, at both scale factors -- the 2x pass is the
# Retina one and it has to be its own process, because QT_SCALE_FACTOR
# is read when the QApplication is built.
if [ -f test_macpaint.py ]; then
  for f in 1 2; do
    echo "=== test_macpaint.py (QT_SCALE_FACTOR=$f) ==="
    QT_SCALE_FACTOR=$f QT_ENABLE_HIGHDPI_SCALING=1 \
      $TMO "$PY" test_macpaint.py > "$OUT/log" 2>&1
    rc=$?
    tail -3 "$OUT/log"
    echo "exit=$rc"
    [ "$rc" -eq 0 ] || bad="$bad test_macpaint.py@${f}x"
  done
fi

cd "$R/tests" || exit 1
for t in test_twostep.py test_round3.py test_msaccounts.py test_identbox.py \
         test_subdomain.py test_acctpick.py test_private.py \
         test_masterlock.py test_masterwizard.py; do
  [ -f "$t" ] || continue
  run "$t" "tests/$t"
done

cd "$R" || exit 1
echo "=== invariants ==="
$TMO "$PY" .github/scripts/invariant_checks.py > "$OUT/log" 2>&1
rc=$?
tail -4 "$OUT/log"
echo "exit=$rc"
[ "$rc" -eq 0 ] || bad="$bad invariants"

if [ -n "$bad" ]; then
  echo "FAILED:$bad"
  exit 1
fi
echo "all green"
