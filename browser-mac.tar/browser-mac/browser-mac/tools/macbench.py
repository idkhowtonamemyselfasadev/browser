#!/usr/bin/env python3
"""What this browser costs, measured rather than described.

The owner asked for a macOS edition that is quick. Nobody can measure
on a machine that does not exist, so this harness exists to do two
separate jobs and to keep them apart:

  * **give the Linux box a baseline column** for everything whose cost
    is the same work on any platform -- the CPython compiler, the
    per-paint arithmetic in the Qt layer, the algorithmic cost of the
    hot paths -- so the macOS numbers, when somebody finally takes
    them, have something to be compared against;
  * **be the thing that is run on the Mac**, once, by a person who is
    not a developer: `sh macselftest.sh` calls it and prints a table.

The macOS column is empty here and is labelled `unmeasured`. It is not
estimated, scaled from the Linux number or guessed at. An adjective is
not a measurement.

Usage
-----

    python3 tools/macbench.py                 # everything it can
    python3 tools/macbench.py --only compile,paint
    python3 tools/macbench.py --list
    python3 tools/macbench.py --json out.json
    python3 tools/macbench.py --quick         # skip the slow ones

Everything runs offscreen against a throwaway profile. It never
touches the browser you actually use: BROWSER_HOME is pointed at a
temporary folder before browser.py is imported, which moves the
config, the history, the vault, the cookie jars and the caches
together.
"""
import argparse
import json
import os
import platform
import shutil
import statistics
import subprocess
import sys
import tempfile
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
APP = HERE.parent
LAGTEST = HERE / "lagtest.html"

#: every bench, in the order they are run. name -> (what it measures,
#: whether it needs the engine, whether it is slow)
BENCHES = {}


def bench(name, about, needs_engine=False, slow=False):
    def keep(fn):
        BENCHES[name] = (fn, about, needs_engine, slow)
        return fn
    return keep


# ---------------------------------------------------------------------
# the scratch profile, and the engine, set up once and only if asked
# ---------------------------------------------------------------------
SCRATCH = None
_QT = {}


def scratch():
    global SCRATCH
    if SCRATCH is None:
        SCRATCH = Path(tempfile.mkdtemp(prefix="macbench-"))
        os.environ["BROWSER_HOME"] = str(SCRATCH / "home")
        os.environ["XDG_CACHE_HOME"] = str(SCRATCH / "cache")
        os.environ["QT_QPA_PLATFORM"] = os.environ.get(
            "QT_QPA_PLATFORM", "offscreen")
        # a browser booted for a measurement does not go looking for
        # library updates, and does not ask about a graphics card
        os.environ["BROWSER_NO_LIB_CHECK"] = "1"
        os.environ["BROWSER_NO_GPU_ASK"] = "1"
    return SCRATCH


def engine():
    """The browser module, the application object and a window.

    Built once, lazily, because half the benches here need no engine
    at all and starting one costs a second."""
    if _QT:
        return _QT
    scratch()
    sys.path.insert(0, str(APP))
    # a bench that ran earlier may already have imported it, and then
    # this is not a measurement of anything -- say so rather than
    # reporting the 0.0 that a second import takes
    fresh = "browser" not in sys.modules
    t0 = time.perf_counter()
    import browser as B                                  # noqa: E402
    t_import = (time.perf_counter() - t0) if fresh else None
    from PyQt6.QtWidgets import QApplication             # noqa: E402
    app = QApplication.instance() or QApplication(sys.argv[:1])
    t1 = time.perf_counter()
    win = B.Browser()
    t_build = time.perf_counter() - t1
    win.resize(1440, 900)
    win.show()
    app.processEvents()
    _QT.update(B=B, app=app, win=win, t_import=t_import, t_build=t_build)
    return _QT


def settle(ms=400):
    """Let the event loop run for a while without blocking it.

    A real QEventLoop quit by a timer, not a `while processEvents()`
    spin. That matters here and not only for tidiness: a spin is
    itself processor time inside the process being measured, and the
    idle-CPU bench reported the harness rather than the browser (4.4%
    of a core, all of it this function).
    """
    from PyQt6.QtCore import QEventLoop, QTimer
    loop = QEventLoop()
    QTimer.singleShot(max(1, int(ms)), loop.quit)
    loop.exec()


def rows_of(**kw):
    """One bench's answer: numbers with their units, nothing else."""
    return kw


# ---------------------------------------------------------------------
@bench("compile", "CPython turning browser.py into bytecode")
def bench_compile():
    """The cost a launch pays when it cannot cache its bytecode.

    Platform-independent: this is the compiler, not the operating
    system. It matters on macOS because an .app bundle under
    /Applications is root-owned, and one Gatekeeper has translocated
    is on a read-only image -- in both cases __pycache__ beside the
    source cannot be written, so this is paid on every launch.
    """
    import marshal
    src = APP / "browser.py"
    text = src.read_text(encoding="utf-8")

    def best(fn, n=5):
        runs = []
        for _ in range(n):
            t = time.perf_counter()
            fn()
            runs.append((time.perf_counter() - t) * 1000.0)
        return min(runs)

    compile_ms = best(lambda: compile(text, str(src), "exec"))
    blob = marshal.dumps(compile(text, str(src), "exec"))
    load_ms = best(lambda: marshal.loads(blob), 10)
    whole = 0.0
    for f in sorted(APP.glob("*.py")):
        if f.name.startswith(("test_", "_")):
            continue
        t = time.perf_counter()
        compile(f.read_text(encoding="utf-8"), str(f), "exec")
        whole += (time.perf_counter() - t) * 1000.0
    return rows_of(
        source_mb=round(len(text) / 1e6, 2),
        lines=text.count("\n") + 1,
        compile_ms=round(compile_ms, 1),
        load_cached_ms=round(load_ms, 1),
        penalty_per_launch_ms=round(compile_ms - load_ms, 1),
        whole_app_compile_ms=round(whole, 1),
        python=platform.python_version())


# ---------------------------------------------------------------------
@bench("codecs", "which codecs this engine build actually has",
       needs_engine=True)
def bench_codecs():
    """What the engine will play, asked of the engine.

    This is §5h's real question and it has nothing to do with the
    hardware: VideoToolbox is automatic on macOS and there is no flag
    to add, but a decoder the engine was **built without** is a
    decoder no amount of silicon provides.

    Measured here, on the Linux x86_64 wheel 6.11.0: **no H.264, no
    HEVC, no AAC.** VP8, VP9, AV1, Opus, Vorbis, MP3 and FLAC are all
    there. That is the ordinary outcome for a redistributable build --
    `ffmpeg_branding=Chromium` leaves the patent-encumbered decoders
    out -- and it is why `pip install PyQt6-WebEngine` cannot play a
    Twitch stream, an .mp4 off the disk, or the German broadcasters'
    HEVC feeds.

    Homebrew's `qtwebengine` formula builds with
    `-DFEATURE_webengine_proprietary_codecs=ON` (checked in the
    formula source, 2026-10-26), so `brew install pyqt` gives an
    engine that has them. Which of the two is on the machine is what
    this bench answers, wherever it is run.
    """
    win = _QT["win"]
    view = win.current()
    from PyQt6.QtCore import QUrl
    view.setUrl(QUrl("about:blank"))
    settle(700)
    want = [
        ('video/mp4; codecs="avc1.42E01E"', "h264_baseline"),
        ('video/mp4; codecs="avc1.640028"', "h264_high"),
        ('video/mp4; codecs="hev1.1.6.L93.B0"', "hevc"),
        ('video/mp4; codecs="av01.0.05M.08"', "av1"),
        ('video/webm; codecs="vp8"', "vp8"),
        ('video/webm; codecs="vp9"', "vp9"),
        ('audio/mp4; codecs="mp4a.40.2"', "aac"),
        ('audio/mpeg', "mp3"),
        ('audio/webm; codecs="opus"', "opus"),
        ('audio/ogg; codecs="vorbis"', "vorbis"),
        ('audio/flac', "flac"),
    ]
    probe = """(function (list) {
      var video = document.createElement('video');
      var audio = document.createElement('audio');
      var out = {};
      for (var i = 0; i < list.length; i++) {
        var mime = list[i][0];
        var el = mime.indexOf('audio') === 0 ? audio : video;
        out[list[i][1]] = el.canPlayType(mime) || 'no';
      }
      out.mse_h264 = window.MediaSource
        ? String(MediaSource.isTypeSupported(list[0][0]))
        : 'no MSE';
      return JSON.stringify(out);
    })(%s)"""
    js = probe % json.dumps(want)
    answer = {}
    view.page().runJavaScript(js, lambda s: answer.update(json.loads(s or "{}")))
    settle(1500)
    if not answer:
        return rows_of(error="the page did not answer")
    out = dict(answer)
    lib = ""
    try:
        import PyQt6.QtWebEngineCore as core
        lib = str(Path(core.__file__).resolve())
    except ImportError:
        pass
    out["engine_from"] = ("a pip wheel" if "site-packages" in lib
                          else "not a wheel (a system or Homebrew build)")
    has_h264 = answer.get("h264_baseline", "no") != "no"
    out["verdict"] = (
        "H.264/AAC present: Twitch, .mp4 files and AAC audio will play"
        if has_h264 else
        "NO H.264 and NO AAC: YouTube works (VP9/AV1+Opus) but Twitch, "
        ".mp4 files and AAC audio do NOT. `brew install pyqt` gives a "
        "build that has them (-DFEATURE_webengine_proprietary_codecs=ON)")
    return out


# ---------------------------------------------------------------------
#: The paint bench's child. Run in its own process per scale factor,
#: because QT_SCALE_FACTOR is read once when the QApplication is built
#: and the thing being measured is what a 2x backing store costs.
PAINT_DRIVER = r"""
import json, os, statistics, sys, tempfile, time
os.environ["QT_QPA_PLATFORM"] = "offscreen"
os.environ["BROWSER_HOME"] = tempfile.mkdtemp(prefix="macbench-paint-")
os.environ["BROWSER_NO_LIB_CHECK"] = "1"
os.environ["BROWSER_NO_GPU_ASK"] = "1"
sys.path.insert(0, sys.argv[1])
import browser as B
from PyQt6.QtWidgets import QApplication
from PyQt6.QtGui import QPainter, QPixmap
from PyQt6.QtCore import Qt

app = QApplication(sys.argv[:1])
win = B.Browser()
win.resize(1440, 900)
win.show()
app.processEvents()
pins = win.pins() or []
if len(pins) < 10:
    pins = (list(pins) + [{"url": "https://example.com/%d" % i,
                           "name": "site %d" % i, "icon": ""}
                          for i in range(10)])[:10]
dock = B.Dock(win)
dock.set_pins(pins)
dock.resize(*dock._wanted())
dock._focus = dock.width() // 2
dock._reach = 0.6
# the ratio the widget really has, which is what _glass() and
# _icon_at() ask for -- not one this script invents
ratio = float(dock.devicePixelRatioF() or 1.0)
surface = QPixmap(int(round(dock.width() * ratio)),
                  int(round(dock.height() * ratio)))
surface.setDevicePixelRatio(ratio)


def one(cold):
    surface.fill(Qt.GlobalColor.transparent)
    painter = QPainter(surface)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
    if cold:
        # what it used to do: the island from scratch and every icon
        # rescaled, on every single frame
        dock._glass_cache = None
        dock._icon_cache = {}
        dock._paint_glass(painter)
        for rect, _pin, pixmap in dock.item_rects():
            if not pixmap.isNull():
                painter.drawPixmap(rect, pixmap)
    else:
        painter.drawPixmap(0, 0, dock._glass())
        for rect, _pin, pixmap in dock.item_rects():
            if not pixmap.isNull():
                painter.drawPixmap(rect.topLeft(),
                                   dock._icon_at(pixmap, rect.width()))
    painter.end()


def timed(cold, n=40):
    one(cold)
    runs = []
    for i in range(n):
        dock._reach = 0.3 + (i % 10) * 0.07     # a bulge that moves
        start = time.perf_counter()
        one(cold)
        runs.append((time.perf_counter() - start) * 1000.0)
    return round(statistics.median(runs), 3)


print(json.dumps({"ratio": ratio, "every_frame_ms": timed(True),
                  "cached_ms": timed(False), "pins": len(pins),
                  "dock_px": "%dx%d" % (dock.width(), dock.height()),
                  "surface_px": "%dx%d" % (surface.width(),
                                           surface.height())}))
"""


@bench("paint", "what the Qt layer draws by hand, at 1x and at 2x",
       slow=True)
def bench_paint():
    """The dock's own painting, timed, cached and uncached, at both
    scale factors.

    This is the one Retina question a Linux box can answer: everything
    the browser paints *itself* costs four times as much on a 2x
    framebuffer, and a QWidget is painted on the CPU. The dock is
    where that lives -- twelve overlapping antialiased rounded
    rectangles for the island's shadow, and up to ten icons smoothly
    rescaled by the magnification, on every frame of the ease.

    **Each ratio is a separate process.** QT_SCALE_FACTOR is read when
    the QApplication is built, and the thing being measured is what a
    real 2x backing store costs. Painting into a pixmap whose ratio
    this script set by hand does not do it: `_glass()` and `_icon_at()`
    ask the *widget* for its devicePixelRatioF, so a faked 2x surface
    gets a 1x island blitted up to fit -- which is both cheaper and
    blurrier than the thing being claimed. That was the first version
    of this bench and it overstated the 2x saving.
    """
    driver = scratch() / "paint_driver.py"
    driver.write_text(PAINT_DRIVER, encoding="utf-8")
    out = {}
    for factor in ("1", "2"):
        env = dict(os.environ)
        env["QT_SCALE_FACTOR"] = factor
        env["QT_ENABLE_HIGHDPI_SCALING"] = "1"
        env["QT_QPA_PLATFORM"] = "offscreen"
        got = subprocess.run([sys.executable, str(driver), str(APP)],
                             capture_output=True, text=True, timeout=600,
                             env=env)
        line = [l for l in got.stdout.splitlines() if l.startswith("{")]
        if not line:
            return rows_of(error="the %sx child said nothing: %s"
                                 % (factor, got.stderr.strip()[-200:]))
        answer = json.loads(line[-1])
        tag = "%gx" % answer["ratio"]
        if answer["ratio"] != float(factor):
            tag = "%sx_asked_%gx_got" % (factor, answer["ratio"])
        was, now = answer["every_frame_ms"], answer["cached_ms"]
        out["every_frame_" + tag + "_ms"] = was
        out["cached_" + tag + "_ms"] = now
        out["saved_" + tag + "_pct"] = round(100.0 * (was - now) / was, 1) \
            if was else 0.0
        # against one frame of a 120 Hz screen, which is 8.33 ms
        out["share_of_120hz_frame_" + tag] = (
            "%.0f%% -> %.0f%%" % (100.0 * was / 8.333, 100.0 * now / 8.333))
        out["surface_" + tag] = answer["surface_px"]
        out["pins_drawn"] = answer["pins"]
        out["dock_px"] = answer["dock_px"]
    return out


# ---------------------------------------------------------------------
@bench("startup", "import, build, first paint", needs_engine=True)
def bench_startup():
    """Where the time before the first window goes.

    `python+qt` is everything before browser.py's first line, which on
    a cold bundle is the compile measured above. The steps come from
    the browser's own instrumentation (startup_report), so this
    reports what it reports rather than a second opinion.
    """
    win = _QT["win"]
    steps = {}
    for row in win.startup_report() or []:
        steps[row["step"]] = row["ms"]
    got = _QT["t_import"]
    return rows_of(import_ms=round(got * 1000.0, 1) if got is not None
                   else "not measured (already imported by an earlier bench)",
                   build_window_ms=round(_QT["t_build"] * 1000.0, 1),
                   steps=steps)


# ---------------------------------------------------------------------
@bench("coldwarm", "a whole process, with and without a bytecode cache",
       slow=True)
def bench_coldwarm():
    """Two real launches: one that may cache its bytecode and one that
    may not.

    This is the §5b claim, end to end, in separate processes -- not
    the compiler timed in isolation. The child imports the browser,
    builds nothing and exits, so the difference between the two runs
    is the compiler and the loader and nothing else.
    """
    base = scratch()
    driver = base / "import_only.py"
    driver.write_text(
        "import sys, time, os\n"
        "t0 = time.perf_counter()\n"
        "sys.path.insert(0, %r)\n"
        "import browser\n"
        "print('%%.1f' %% ((time.perf_counter() - t0) * 1000.0))\n"
        % str(APP), encoding="utf-8")

    def run(prefix):
        """One child, with that cache prefix.

        A prefix is the whole of it, in both directions: with
        PYTHONPYCACHEPREFIX set, CPython reads AND writes only there
        and ignores any `__pycache__` beside the source. So the cold
        run points at a directory that exists and cannot be written to
        -- which is exactly the bundle-under-/Applications case -- and
        every launch then compiles from source. PYTHONDONTWRITEBYTECODE
        alone is not enough and was the first version of this bench's
        mistake: it stops the write and happily reads the cache that
        is already there."""
        env = dict(os.environ)
        env["QT_QPA_PLATFORM"] = "offscreen"
        env["BROWSER_NO_LIB_CHECK"] = "1"
        env.pop("PYTHONDONTWRITEBYTECODE", None)
        env["PYTHONPYCACHEPREFIX"] = str(prefix)
        best = []
        for _ in range(3):
            t = time.perf_counter()
            out = subprocess.run([sys.executable, str(driver)], env=env,
                                 capture_output=True, text=True, timeout=300)
            best.append((time.perf_counter() - t) * 1000.0)
            if out.returncode != 0:
                return None, out.stderr.strip()[-200:]
        return round(min(best), 1), ""

    warm_dir = base / "pyc-warm"
    cold_dir = base / "pyc-readonly"
    warm_dir.mkdir(parents=True, exist_ok=True)
    cold_dir.mkdir(parents=True, exist_ok=True)
    warm, err1 = run(warm_dir)          # the first run fills it
    warm, err1 = run(warm_dir)          # ...and this one uses it
    cold_dir.chmod(0o500)               # there, but not writable
    try:
        cold, err2 = run(cold_dir)
    finally:
        cold_dir.chmod(0o700)
    if warm is None or cold is None:
        return rows_of(error=(err1 or err2))
    return rows_of(with_cache_ms=warm, without_cache_ms=cold,
                   penalty_ms=round(cold - warm, 1),
                   note="whole process, import only, best of three; "
                        "the cold run's cache directory is real and "
                        "read-only, which is the /Applications case")


# ---------------------------------------------------------------------
@bench("scroll", "frames a second over a page built to be heavy",
       needs_engine=True, slow=True)
def bench_scroll():
    """The engine's own frame rate, counted in the page.

    requestAnimationFrame is the only honest place to count frames
    from: it is the compositor saying it drew. The page is
    tools/lagtest.html, which repaints the whole viewport for ever.

    On this Linux box the platform is `offscreen` and the raster is
    software, so the absolute number means little -- what it is for is
    the comparison with the same measurement on a Mac, where the same
    page goes through Metal.
    """
    B = _QT["B"]
    win = _QT["win"]
    if not LAGTEST.exists():
        return rows_of(error="tools/lagtest.html is missing")
    view = win.current()
    from PyQt6.QtCore import QUrl
    view.setUrl(QUrl.fromLocalFile(str(LAGTEST)))
    settle(2500)
    answer = {}

    def took(value):
        answer["fps"] = value

    count = """
      (function () {
        window.__fps = 0;
        var seen = 0, start = performance.now();
        function tick() {
          seen += 1;
          if (performance.now() - start < 2000) { requestAnimationFrame(tick); }
          else { window.__fps = seen / ((performance.now() - start) / 1000); }
        }
        requestAnimationFrame(tick);
        return 'counting';
      })()
    """
    view.page().runJavaScript(count)
    # and scroll it while that counts, which is the thing being asked
    for _ in range(40):
        view.page().runJavaScript("window.scrollBy(0, 40)")
        settle(60)
    settle(600)
    view.page().runJavaScript("window.__fps || 0", took)
    settle(1200)
    fps = answer.get("fps") or 0.0
    return rows_of(fps=round(float(fps), 1),
                   surface=os.environ.get("QT_QPA_PLATFORM", "native"),
                   page="tools/lagtest.html",
                   note="offscreen software raster on this box"
                   if os.environ.get("QT_QPA_PLATFORM") == "offscreen"
                   else "")


# ---------------------------------------------------------------------
@bench("video", "a 1080p60 file, frames decoded and frames dropped",
       needs_engine=True, slow=True)
def bench_video():
    """A local 1080p60 clip, played, with the engine's own counters.

    webkitDecodedFrameCount and webkitDroppedFrameCount are what the
    media element will say about itself. The clip is made here with
    ffmpeg if there is one, so this needs nothing off the network; no
    ffmpeg means no measurement and the row says so rather than
    skipping quietly.

    On a Mac this is the VideoToolbox question in §5h, and whether the
    PyQt6 wheel's engine was built with the codec at all.
    """
    if not shutil.which("ffmpeg"):
        return rows_of(error="no ffmpeg here: cannot make a clip to play")
    clip = scratch() / "clip1080p60.mp4"
    if not clip.exists():
        make = subprocess.run(
            ["ffmpeg", "-y", "-v", "error",
             "-f", "lavfi", "-i", "testsrc2=size=1920x1080:rate=60",
             "-t", "6", "-c:v", "libx264", "-preset", "ultrafast",
             "-pix_fmt", "yuv420p", str(clip)],
            capture_output=True, text=True, timeout=300)
        if make.returncode != 0 or not clip.exists():
            return rows_of(error="ffmpeg could not make the clip: "
                                 + make.stderr.strip()[-160:])
    # served over HTTP on loopback, not loaded off the disk: a file://
    # page fetching a file:// media URL is a cross-origin fetch as far
    # as Chromium is concerned, and the element fires `error` with
    # nothing playing. It is also closer to the thing being asked
    # about, which is a stream.
    import functools
    import http.server
    import threading
    page = scratch() / "video.html"
    page.write_text(
        '<!doctype html><meta charset="utf-8"><body style="margin:0">'
        '<video id="v" src="%s" autoplay muted playsinline '
        'style="width:100%%"></video>' % clip.name, encoding="utf-8")
    handler = functools.partial(http.server.SimpleHTTPRequestHandler,
                                directory=str(scratch()))
    handler.log_message = lambda *a, **k: None
    httpd = http.server.ThreadingHTTPServer(("127.0.0.1", 0), handler)
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    port = httpd.server_address[1]
    win = _QT["win"]
    view = win.current()
    from PyQt6.QtCore import QUrl
    view.setUrl(QUrl("http://127.0.0.1:%d/video.html" % port))
    settle(5000)
    answer = {}
    view.page().runJavaScript(
        "(function(){var v=document.getElementById('v');"
        "return JSON.stringify({t:v?v.currentTime:0,"
        "decoded:v?(v.webkitDecodedFrameCount||0):0,"
        "dropped:v?(v.webkitDroppedFrameCount||0):0,"
        "w:v?v.videoWidth:0,h:v?v.videoHeight:0});})()",
        lambda s: answer.update(json.loads(s or "{}")))
    settle(1500)
    httpd.shutdown()
    played = float(answer.get("t") or 0.0)
    decoded = int(answer.get("decoded") or 0)
    dropped = int(answer.get("dropped") or 0)
    if not played:
        return rows_of(error="nothing played -- see the `codecs` bench: "
                             "a wheel-built engine has no H.264 at all, "
                             "which is the usual reason")
    return rows_of(resolution="%sx%s" % (answer.get("w"), answer.get("h")),
                   seconds_played=round(played, 2),
                   decoded_frames=decoded, dropped_frames=dropped,
                   effective_fps=round(decoded / played, 1) if played else 0,
                   dropped_pct=round(100.0 * dropped / decoded, 2)
                   if decoded else 0.0)


# ---------------------------------------------------------------------
@bench("tabs", "ten tabs: memory each, and what the browser costs idle",
       needs_engine=True, slow=True)
def bench_tabs():
    """Ten tabs open, then left alone.

    Two numbers: the resident memory of each renderer (which is where
    the batched `ps` of §5j is exercised on a Mac -- one process
    instead of ten), and the browser's own processor time while
    nothing is happening, which is the number App Nap and the timer
    work in §5g are about.
    """
    win = _QT["win"]
    from PyQt6.QtCore import QUrl
    page = scratch() / "quiet.html"
    page.write_text('<!doctype html><meta charset="utf-8">'
                    '<title>quiet</title><p>nothing happens here.',
                    encoding="utf-8")
    url = QUrl.fromLocalFile(str(page))
    while win.tabs.count() < 10:
        win.new_tab(url, switch=False)
    settle(4000)

    def cpu_now():
        try:
            if sys.platform == "darwin":
                out = subprocess.run(["ps", "-o", "time=", "-p",
                                      str(os.getpid())],
                                     capture_output=True, text=True,
                                     timeout=5).stdout.strip()
                bits = [float(p) for p in out.split(":")]
                total = 0.0
                for bit in bits:
                    total = total * 60 + bit
                return total
            with open("/proc/self/stat") as fh:
                fields = fh.read().rsplit(") ", 1)[-1].split()
            ticks = int(fields[11]) + int(fields[12])
            return ticks / (os.sysconf("SC_CLK_TCK") or 100)
        except (OSError, ValueError, IndexError):
            return 0.0

    before, wall = cpu_now(), time.perf_counter()
    settle(10000)
    used = cpu_now() - before
    gap = time.perf_counter() - wall
    costs = []
    try:
        costs = win.tab_costs()
    except Exception as exc:            # pragma: no cover - engine shapes
        costs = []
        idle_err = str(exc)[:120]
    rss = [row["bytes"] for row in costs if row.get("bytes")]
    return rows_of(tabs=win.tabs.count(),
                   idle_cpu_pct=round(100.0 * used / gap, 2) if gap else 0.0,
                   idle_window_s=round(gap, 1),
                   renderers_measured=len(rss),
                   rss_median_mb=round(statistics.median(rss) / 1e6, 1)
                   if rss else 0.0,
                   rss_total_mb=round(sum(rss) / 1e6, 1) if rss else 0.0,
                   note="ui-process cpu only, over a real idle event "
                        "loop; renderer memory from "
                        + ("ps (one call for all of them)"
                           if sys.platform == "darwin" else "/proc"))


# ---------------------------------------------------------------------
@bench("timers", "how the housekeeping chores are spread")
def bench_timers():
    """Not a timing, an arithmetic check with a number attached.

    Four chores wanted thirty seconds and were built microseconds
    apart, so they fired in one iteration of the event loop. This
    reports the slot each one now starts in, and how many of them land
    together -- which on macOS is also what App Nap releases at once.
    """
    sys.path.insert(0, str(APP))
    import browser as B
    every = 30000
    slots = {name: B.housekeep_offset(name, every) for name in B.HOUSEKEEPING}
    together = len(B.HOUSEKEEPING) - len(set(slots.values()))
    return rows_of(chores=len(B.HOUSEKEEPING), offsets_ms=slots,
                   landing_together=together,
                   coarse_on="darwin only (VeryCoarseTimer)")


# ---------------------------------------------------------------------
def table(results, machine):
    """The whole thing as something a person can read."""
    width = 74
    out = ["", "=" * width,
           "browser benchmark  --  %s" % machine["label"], "=" * width, ""]
    for name, (_fn, about, _e, _s) in BENCHES.items():
        got = results.get(name)
        out.append("%-10s %s" % (name, about))
        if got is None:
            out.append("           not run")
            out.append("")
            continue
        if "error" in got:
            out.append("           SKIPPED: %s" % got["error"])
            out.append("")
            continue
        for key, value in got.items():
            if isinstance(value, dict):
                out.append("           %-26s %s"
                           % (key, ", ".join("%s=%s" % kv
                                             for kv in value.items())))
            else:
                out.append("           %-26s %s" % (key, value))
        out.append("")
    out.append("-" * width)
    out.append("macOS column: UNMEASURED. No Mac has ever run this.")
    out.append("Run `sh macselftest.sh` on one and it fills itself in.")
    out.append("-" * width)
    return "\n".join(out)


def machine_label():
    bits = [platform.system(), platform.release().split("-")[0],
            platform.machine()]
    if sys.platform == "darwin":
        try:
            silicon = subprocess.run(["sysctl", "-n", "hw.optional.arm64"],
                                     capture_output=True, text=True,
                                     timeout=5).stdout.strip()
            translated = subprocess.run(
                ["sysctl", "-n", "sysctl.proc_translated"],
                capture_output=True, text=True, timeout=5).stdout.strip()
        except (OSError, subprocess.SubprocessError):
            silicon = translated = ""
        if silicon == "1":
            bits.append("Apple Silicon")
        if translated == "1":
            bits.append("*** RUNNING UNDER ROSETTA ***")
    bits.append("python " + platform.python_version())
    try:
        from PyQt6.QtCore import QT_VERSION_STR
        bits.append("Qt " + QT_VERSION_STR)
    except ImportError:
        pass
    try:
        from PyQt6.QtWebEngineCore import qWebEngineChromiumVersion
        bits.append("Chromium " + qWebEngineChromiumVersion())
    except ImportError:
        pass
    return {"label": "  |  ".join(bits), "platform": sys.platform,
            "machine": platform.machine(),
            "python": platform.python_version()}


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--only", default="",
                    help="comma-separated bench names")
    ap.add_argument("--json", default="",
                    help="write the numbers here as well")
    ap.add_argument("--quick", action="store_true",
                    help="skip the benches that take minutes")
    ap.add_argument("--list", action="store_true")
    args = ap.parse_args(argv)
    if args.list:
        for name, (_fn, about, needs, slow) in BENCHES.items():
            print("%-10s %-52s %s%s" % (name, about,
                                        "engine " if needs else "",
                                        "slow" if slow else ""))
        return 0
    asked = [n.strip() for n in args.only.split(",") if n.strip()]
    # always in the order they are declared, whatever order they were
    # typed in: `startup` reports the import that `engine()` timed, so
    # a bench that imports the browser first would make it read 0.0
    wanted = [n for n in BENCHES if n in asked] if asked else list(BENCHES)
    wanted += [n for n in asked if n not in BENCHES]
    unknown = [n for n in wanted if n not in BENCHES]
    if unknown:
        print("no such bench: %s" % ", ".join(unknown), file=sys.stderr)
        return 2
    machine = machine_label()
    print(machine["label"])
    results = {}
    for name in wanted:
        fn, about, needs, slow = BENCHES[name]
        if slow and args.quick:
            print("  .. %-10s skipped (--quick)" % name)
            continue
        print("  .. %-10s %s" % (name, about), flush=True)
        try:
            if needs:
                engine()
            results[name] = fn()
        except Exception as exc:
            results[name] = {"error": "%s: %s" % (type(exc).__name__,
                                                  str(exc)[:200])}
    print(table(results, machine))
    blob = {"machine": machine, "when": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "results": results,
            "macos": "unmeasured -- no Mac has run this"}
    if args.json:
        Path(args.json).write_text(json.dumps(blob, indent=2) + "\n",
                                   encoding="utf-8")
        print("numbers written to %s" % args.json)
    if SCRATCH is not None:
        shutil.rmtree(SCRATCH, ignore_errors=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
