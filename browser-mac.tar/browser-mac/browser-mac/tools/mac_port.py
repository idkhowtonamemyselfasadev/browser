#!/usr/bin/env python3
"""Regenerate the macOS edition from the Linux one.

The Mac browser is not a fork. Every feature is written in ~/browser
and arrives here; the only things that are ours are the handful of
regions listed in mac_port.json. This is the Windows port's script
(tools/win_port.py in browser-windows) with one thing added, and the
two are deliberately the same shape: three editions kept in step by
two scripts that disagree about how is one edition too many.

  * browser.py is a three-way merge -- base is the Linux commit this
    tree was last generated from (mac_port.json: "ported_from"), ours
    is the checked-in Mac file, theirs is the Linux commit being
    ported. Our regions are on our side of the merge, so they survive
    without anyone having to remember them.
  * the HTML pages are copied straight across, because nothing in them
    is ours except the font stack.
  * the substitutions in mac_port.json are then applied to everything,
    which is what catches a *new* Linux theme arriving with a font
    stack macOS cannot serve.
  * finally every marker in mac_port.json must still be true, or this
    refuses to finish and leaves nothing half-written.

The one thing added: `--to worktree`. The Windows port never needed it
because the Linux features were always committed first. This edition
was generated the first time out of a working tree that had the darwin
branches in it and no commit.

That costs something and the cost is paid here rather than hidden. A
three-way merge needs a base, and "the working tree as it was at the
last port" is not a commit -- there is nothing to ask git for. Taking
the recorded commit instead is not a near-enough answer: it does not
contain what was ported, so the merge sees our substitutions on one
side and the ported branches on the other and conflicts on every one
of them. That really happened, on the second worktree port, five
conflicts in browser.py.

So a worktree port writes the source it ported into tools/_base/<name>.gz
and the next one merges against that. Gzipped because browser.py is
four megabytes and this is a file that gets rewritten every time. A
normal `--to <commit>` port throws the snapshots away again, because
from then on `ported_from` is the whole truth and git has the base.

The same gap makes the hand-edit check (below) unable to tell a change
made HERE from a change made in the working tree over there, so after a
worktree port it accepts either and says so, rather than crying wolf on
every file the working tree touched.

Usage:
    tools/mac_port.py --to <linux-commit>      # generate
    tools/mac_port.py --to worktree            # ...including uncommitted
    tools/mac_port.py --to <commit> --dry-run  # report, write nothing
    tools/mac_port.py --check                  # verify the tree as it is

Nothing is written until every file has been generated and every marker
has passed, so a failed port leaves the working tree untouched.
"""

import argparse
import ast
import fnmatch
import gzip
import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parent
MANIFEST = HERE / "mac_port.json"
#: where a worktree port leaves the source it ported, so the next one
#: has a base to merge against. See the module docstring.
BASES = HERE / "_base"
WORKTREE = "worktree"


def saved_base(name):
    """The source as of the last worktree port, or None."""
    p = BASES / (name + ".gz")
    try:
        return gzip.decompress(p.read_bytes())
    except (OSError, ValueError):
        return None


def save_base(name, data):
    p = BASES / (name + ".gz")
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(gzip.compress(data, 6))


#: what the last port actually wrote, file by file. The hand-edit
#: check below wants to know "has this file changed since the port
#: wrote it", and that question has an exact answer that costs eight
#: kilobytes -- far better than the one git can give, which is "does
#: it match some commit plus substitutions" and which goes wrong the
#: moment the Linux side moves (a worktree port, or the owner committing
#: between ports). Hashes, not contents: this is not a backup.
WRITTEN = BASES / "written.json"


def digest(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def load_written():
    try:
        return json.loads(WRITTEN.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def save_written(files):
    WRITTEN.parent.mkdir(parents=True, exist_ok=True)
    WRITTEN.write_text(
        json.dumps({k: digest(v) for k, v in sorted(files.items())},
                   indent=1) + "\n", encoding="utf-8")


def drop_bases():
    """A commit port makes them a lie: ported_from is the truth again."""
    gone = 0
    if BASES.is_dir():
        for p in sorted(BASES.rglob("*.gz")):
            p.unlink()
            gone += 1
    return gone


class PortError(Exception):
    pass


def load_manifest():
    return json.loads(MANIFEST.read_text(encoding="utf-8"))


def git(repo, *args):
    out = subprocess.run(["git", "-C", str(repo), *args],
                         capture_output=True, text=True)
    if out.returncode != 0:
        raise PortError("git %s failed in %s:\n%s"
                        % (" ".join(args), repo, out.stderr.strip()))
    return out.stdout


def show(repo, rev, path):
    """A file as of a commit. Returns None if it did not exist then.

    rev == "worktree" reads the file off the disk instead, which is how
    a port can carry work that is not committed yet -- see the module
    docstring for why that is a thing this script is allowed to do and
    win_port.py is not."""
    if rev == WORKTREE:
        p = Path(repo) / path
        try:
            return p.read_bytes()
        except OSError:
            return None
    out = subprocess.run(["git", "-C", str(repo), "show", "%s:%s" % (rev, path)],
                         capture_output=True)
    if out.returncode != 0:
        return None
    return out.stdout


def matches(name, patterns):
    return any(fnmatch.fnmatch(name, p) for p in patterns)


def names(seq):
    """The file lists carry inline commentary -- entries starting with a
    '#' are prose, not paths. JSON has no comments, and a list of a
    hundred file names with no explanation is how the next person
    guesses wrong. A '#' cannot be the first character of a file in
    this tree."""
    return [n for n in seq if not n.startswith("#")]


def apply_substitutions(files, rules):
    """Returns (files, per-rule hit counts). Idempotent by construction:
    each replacement no longer matches its own pattern."""
    counts = []
    for rule in rules:
        hits = 0
        for name, text in files.items():
            if not matches(name, rule["files"]):
                continue
            n = text.count(rule["find"])
            if n:
                files[name] = text.replace(rule["find"], rule["replace"])
                hits += n
        counts.append(hits)
    return files, counts


def check_markers(files, markers):
    """Every marker must hold. Returns a list of failure strings."""
    bad = []
    for m in markers:
        targets = [n for n in files if matches(n, [m["file"]])]
        if not targets:
            bad.append("%s: no file matches %r" % (m["name"], m["file"]))
            continue
        rx = re.compile(m["pattern"], re.MULTILINE)
        total = sum(len(rx.findall(files[n])) for n in targets)
        want = m.get("count")
        if want is not None and total != want:
            bad.append("%s (%s): found %d, expected %d"
                       % (m["name"], m["file"], total, want))
        elif want is None and total < m.get("min", 1):
            bad.append("%s (%s): found %d, expected at least %d"
                       % (m["name"], m["file"], total, m.get("min", 1)))
    return bad


def three_way(base, ours, theirs, label):
    """git merge-file on three blobs. Raises if it conflicts -- a
    conflict means Linux edited a line one of our regions sits on, and
    that is a decision for a person, not for this script."""
    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        (tmp / "ours").write_bytes(ours)
        (tmp / "base").write_bytes(base)
        (tmp / "theirs").write_bytes(theirs)
        out = subprocess.run(
            ["git", "merge-file", "--diff3",
             "-L", "mac", "-L", "base (linux)", "-L", "linux",
             str(tmp / "ours"), str(tmp / "base"), str(tmp / "theirs")],
            capture_output=True, text=True)
        merged = (tmp / "ours").read_bytes()
    if out.returncode < 0:
        raise PortError("merge-file died on %s: %s" % (label, out.stderr))
    if out.returncode > 0:
        raise PortError(
            "%s: %d conflict(s). Linux changed a line a Mac region sits "
            "on. Resolve it by hand in browser-mac, commit, and re-run."
            % (label, out.returncode))
    return merged


def generate(manifest, to_rev, verbose=True):
    """Build the whole tree in memory. Returns {name: text}."""
    # MAC_PORT_LINUX_REPO points the port at another checkout for one
    # run. The manifest names ~/browser; a second clone is a reason to
    # override it, not a reason to edit it.
    linux = Path(os.environ.get("MAC_PORT_LINUX_REPO")
                 or manifest["linux_repo"]).expanduser()
    base_rev = manifest["ported_from"]
    if not linux.is_dir():
        raise PortError("linux_repo %s is not there" % linux)

    base_sha = git(linux, "rev-parse", base_rev).strip()
    to_sha = (WORKTREE if to_rev == WORKTREE
              else git(linux, "rev-parse", to_rev).strip())
    if verbose:
        print("  linux repo   %s" % linux)
        print("  base         %s  (%s)" % (base_sha[:9], base_rev))
        if to_sha == WORKTREE:
            dirty = git(linux, "status", "--porcelain").strip().splitlines()
            print("  porting to   the working tree as it is "
                  "(%d file(s) not committed)" % len(dirty))
        else:
            print("  porting to   %s  (%s)" % (to_sha[:9], to_rev))
            n = git(linux, "rev-list", "--count",
                    "%s..%s" % (base_sha, to_sha)).strip()
            print("  commits      %s" % n)
        print()

    files = {}

    worktree_base = bool(manifest.get("ported_from_worktree"))
    for name in names(manifest["merge_files"]):
        # the snapshot the last worktree port left is the real common
        # ancestor; the commit is only right when the last port was one
        base = (saved_base(name) if worktree_base else None) \
            or show(linux, base_sha, name)
        theirs = show(linux, to_sha, name)
        if theirs is None:
            raise PortError("%s missing from the linux repo" % name)
        here = REPO / name
        if not here.exists():
            # newly listed as a merge file, or arriving for the first
            # time: there is nothing of ours to preserve yet
            files[name] = theirs.decode("utf-8")
            if verbose:
                print("  new     %-16s (nothing here to merge with)" % name)
            continue
        ours = here.read_bytes()
        if base is None:
            # it did not exist at the base commit, so there is no common
            # ancestor to merge against; ours is whatever we already have
            base = ours
        merged = three_way(base, ours, theirs, name)
        files[name] = merged.decode("utf-8")
        if verbose:
            print("  merged  %-16s %d -> %d lines"
                  % (name, ours.decode().count("\n"), files[name].count("\n")))

    copied = 0
    for name in names(manifest["copy_files"]):
        theirs = show(linux, to_sha, name)
        if theirs is None:
            raise PortError("%s missing from the linux repo" % name)
        files[name] = theirs.decode("utf-8")
        copied += 1
    if verbose:
        print("  copied  %d files" % copied)

    # A copied file is only safe to copy if the checked-in one really was
    # the Linux one plus substitutions. If somebody hand-edited it here,
    # copying would throw that away silently, so say so instead.
    drift = []
    written = load_written()
    for name in names(manifest["copy_files"]):
        have = (REPO / name).read_text(encoding="utf-8") \
            if (REPO / name).exists() else None
        if have is None:
            continue
        # what the last port would have produced. After a worktree port
        # that is not recoverable from git, so the working tree counts
        # as an answer too -- otherwise every file the tree has touched
        # since the recorded commit reads as a hand-edit here.
        sources = [show(linux, base_sha, name)]
        if worktree_base:
            sources.append(saved_base(name))
            sources.append(show(linux, WORKTREE, name))
        # what this port wrote last time is the exact answer, when
        # there is one; the git ones are the fallback for a tree whose
        # first port predates this record
        if written.get(name) == digest(have):
            continue
        if written and name in written:
            drift.append(name)
            continue
        ok = False
        for was in sources:
            if was is None:
                continue
            expect, _ = apply_substitutions(
                {name: was.decode("utf-8")}, manifest["substitutions"])
            if have == expect[name]:
                ok = True
                break
        if not ok and sources[0] is not None:
            drift.append(name)
    if drift:
        raise PortError(
            "these were edited by hand here and copying would lose it: %s\n"
            "Move the change into ~/browser, or add it to mac_port.json."
            % ", ".join(drift))

    files, counts = apply_substitutions(files, manifest["substitutions"])
    if verbose:
        print()
        for rule, hit in zip(manifest["substitutions"], counts):
            print("  subst   %-4d %s" % (hit, rule["find"][:58]))
    for rule, hit in zip(manifest["substitutions"], counts):
        if hit < rule.get("min", 1):
            raise PortError(
                "substitution %r matched %d time(s), expected at least %d.\n"
                "Linux probably renamed it -- update mac_port.json."
                % (rule["find"], hit, rule.get("min", 1)))

    return files, to_sha


def verify(files, manifest, verbose=True):
    bad = check_markers(files, manifest["markers"])
    for name, text in files.items():
        if name.endswith(".py"):
            try:
                ast.parse(text)
            except SyntaxError as exc:
                bad.append("%s does not parse: %s" % (name, exc))
    if bad:
        raise PortError("the port dropped something:\n  - "
                        + "\n  - ".join(bad))
    if verbose:
        print("\n  %d markers pass, every .py parses" % len(manifest["markers"]))


def main():
    ap = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--to", default="main",
                    help="Linux commit to port, or 'worktree' "
                         "(default: main)")
    ap.add_argument("--dry-run", action="store_true",
                    help="report what would happen, write nothing")
    ap.add_argument("--check", action="store_true",
                    help="only verify the tree as it stands")
    args = ap.parse_args()

    manifest = load_manifest()

    if args.check:
        files = {}
        for name in names(manifest["merge_files"] + manifest["copy_files"]):
            p = REPO / name
            if not p.exists():
                print("MISSING %s" % name, file=sys.stderr)
                return 1
            files[name] = p.read_text(encoding="utf-8")
        try:
            verify(files, manifest)
        except PortError as exc:
            print("\n%s" % exc, file=sys.stderr)
            return 1
        print("  tree is a valid macOS edition of linux %s%s"
              % (manifest["ported_from"][:9],
                 " plus uncommitted work" if manifest.get(
                     "ported_from_worktree") else ""))
        return 0

    print("Regenerating the macOS edition\n")
    try:
        files, to_sha = generate(manifest, args.to)
        verify(files, manifest)
    except PortError as exc:
        print("\nSTOPPED. Nothing was written.\n\n%s" % exc, file=sys.stderr)
        return 1

    if args.dry_run:
        changed = []
        for name, text in files.items():
            p = REPO / name
            if not p.exists() or p.read_text(encoding="utf-8") != text:
                changed.append(name)
        print("\n  would change: %s" % (", ".join(changed) or "nothing"))
        print("  dry run, nothing written")
        return 0

    for name, text in files.items():
        p = REPO / name
        # a new suite arriving brings its directory with it
        p.parent.mkdir(parents=True, exist_ok=True)
        mode = p.stat().st_mode if p.exists() else None
        p.write_text(text, encoding="utf-8")
        if mode is not None:
            os.chmod(p, mode)
        elif text.startswith("#!"):
            # tools/mock-op is run as a program, not imported
            os.chmod(p, 0o755)

    # what this port wrote, so the next one can tell a hand-edit here
    # from the Linux side having moved
    save_written(files)

    raw = MANIFEST.read_text(encoding="utf-8")
    if to_sha == WORKTREE:
        linux = Path(os.environ.get("MAC_PORT_LINUX_REPO")
                     or manifest["linux_repo"]).expanduser()
        kept = 0
        for name in names(manifest["merge_files"]):
            theirs = show(linux, WORKTREE, name)
            if theirs is not None:
                save_base(name, theirs)
                kept += 1
        print("\n  kept %d base snapshot(s) in tools/_base, so the next "
              "port has something to merge against" % kept)
        # the base stays the commit the tree is a descendant of; the flag
        # is what says the port carried more than that commit, so nobody
        # reads "ported_from" as the whole truth
        raw = re.sub(r'("ported_from_worktree":\s*)(?:true|false)',
                     lambda m: "%strue" % m.group(1), raw, count=1)
        print("\n  written. ported_from is still %s, plus the working tree"
              % manifest["ported_from"][:9])
    else:
        raw = re.sub(r'("ported_from":\s*)"[^"]*"',
                     lambda m: '%s"%s"' % (m.group(1), to_sha), raw, count=1)
        raw = re.sub(r'("ported_from_worktree":\s*)(?:true|false)',
                     lambda m: "%sfalse" % m.group(1), raw, count=1)
        gone = drop_bases()
        print("\n  written. ported_from is now %s" % to_sha[:9])
        if gone:
            print("  dropped %d base snapshot(s): the commit is the base "
                  "again" % gone)
    MANIFEST.write_text(raw, encoding="utf-8")

    print("  review with: git -C %s diff" % REPO)
    return 0


if __name__ == "__main__":
    sys.exit(main())
