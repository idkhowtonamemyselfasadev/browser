#!/usr/bin/env python3
"""This tree, checked as a macOS edition.

test_macbranch.py (ported from the Linux repository, and run by this
suite too) holds the darwin *branches* of browser.py to what they
claim. This one is about the *edition*: the things that are true of
this folder and of no other, and that a port could quietly drop.

  * every font stack reaches a face a Mac really has,
  * every settings row that named a Linux program now names the macOS
    one, in both languages,
  * Info.plist has the keys without which the app is killed rather
    than refused,
  * icon.icns is a real .icns and not a renamed PNG,
  * install-mac.sh builds the bundle shape macOS requires, puts the
    browser in it and the suite outside it, and refuses to run for
    real anywhere but a Mac,
  * and what deliberately did not come across really is not here.

There is no Mac on this machine. Nothing in this file pretends there
is: it reads files and runs a shell script's dry run. What needs a
real Mac is written down in ../PORT.md.
"""
import ast
import json
import plistlib
import re
import struct
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
fails = []


def check(name, cond, detail=""):
    print(("  ok   " if cond else "  FAIL ") + name
          + (("  " + str(detail)) if detail and not cond else ""))
    if not cond:
        fails.append(name)


def read(name):
    return (HERE / name).read_text(encoding="utf-8")


# ---------------------------------------------------------------------
print("(1) the port's own answer")
port = subprocess.run([sys.executable, str(HERE / "tools/mac_port.py"),
                       "--check"], capture_output=True, text=True)
check("mac_port.py --check passes", port.returncode == 0,
      (port.stdout + port.stderr).strip()[-400:])
manifest = json.loads(read("tools/mac_port.json"))
check("the manifest still parses and names this edition's files",
      manifest["linux_repo"] == "~/browser"
      and "icon.icns" in manifest["mac_only_files"])
check("there are no hand-kept regions to rot",
      manifest["hand_regions"] == [], manifest["hand_regions"])
check("and every mac-only file is really here",
      all((HERE / n).exists() for n in manifest["mac_only_files"]
          if not n.startswith(".")),
      [n for n in manifest["mac_only_files"] if not (HERE / n).exists()])

# ---------------------------------------------------------------------
print("\n(2) fonts a Mac has")
MAC_MONO = ('"SF Mono", "Menlo", "Monaco"')
hit = 0
for path in sorted(HERE.glob("*.html")) + [HERE / "browser.py",
                                           HERE / "theme_web.py"]:
    text = path.read_text(encoding="utf-8")
    left = re.findall(r'JetBrainsMono Nerd Font", (?!"SF )', text)
    check("%s: every stack has a macOS face after the Nerd Font"
          % path.name, not left, len(left))
    hit += text.count('"SF ')
check("...and that really did something", hit >= 10, hit)
mono = read("theme_web.py")
check("the theme's monospace stack reaches Menlo",
      MAC_MONO in mono, mono[mono.find("MONO = "):][:160])
check("the serif one already reached a Mac face and was left alone",
      "Charter" in mono and "SF Pro" not in mono.split("SERIF = ")[1][:200])
check("Inter is still asked for first, for a Mac that has it",
      '"JetBrainsMono Nerd Font", "SF Pro Text", "Helvetica Neue", "Inter"'
      in read("settings.html"))

# ---------------------------------------------------------------------
print("\n(3) the settings rows, in both languages")
src = read("browser.py")
# the ROWS, not the file: the Linux branch of keep_awake is still in
# the shared code here and must be, so a bare "systemd-inhibit" not in
# src would be asserting the wrong thing entirely
for pattern, where in (
        (r'"awake(Hint|No)":"[^"]*systemd-inhibit',
         "the screen-awake rows"),
        (r'"sayMissing":"[^"]*\(spd-say\)',
         "the reader's missing-program line"),
        (r'"mprisMissing":"mpris\.py', "the media-keys line"),
        (r'"desktopNotifyHint":"(Through|\\u00dcber) notify-send',
         "the notifications hint, in either language")):
    found = re.findall(pattern, src)
    check("%s no longer names a program a Mac has not got" % where,
          not found, found)
check("...while the Linux branch of the code itself is untouched",
      'shutil.which("systemd-inhibit")' in src)
for want, what in (('"awakeHint":"Only while something is actually playing '
                    'in the tab in front. macOS', "English awake hint"),
                   ('"awakeHint":"Nur solange im vorderen Tab wirklich '
                    'etwas l\\u00e4uft. macOS', "German awake hint"),
                   ('"awakeNo":"caffeinate is not here', "English awake-no"),
                   ('"awakeNo":"caffeinate ist nicht da', "German awake-no"),
                   ('"sayMissing":"No speech program installed (say)."',
                    "English reader line"),
                   ('"sayMissing":"Kein Sprachprogramm installiert (say)."',
                    "German reader line"),
                   ('"desktopNotifyHint":"Through the Notification Center',
                    "English notifications hint"),
                   ('"desktopNotifyHint":"\\u00dcber die '
                    'Mitteilungszentrale', "German notifications hint"),
                   ('"mprisMissing":"The media keys are a Linux desktop',
                    "English media-keys line"),
                   ('"mprisMissing":"Die Medientasten sind ein '
                    'Linux-Desktop-Protokoll', "German media-keys line")):
    check("%s says what this machine really does" % what, want in src)
check("no row sends him looking for a program in /opt or /usr that a "
      "Mac has not got",
      "notify-send" not in src.split('"desktopNotifyHint"')[1][:400])

# ---------------------------------------------------------------------
print("\n(4) Info.plist, where a missing key is a crash and not a refusal")
plist = plistlib.loads((HERE / "Info.plist").read_bytes())
check("it parses as a plist", isinstance(plist, dict))
for key in ("NSCameraUsageDescription", "NSMicrophoneUsageDescription"):
    check("%s is there, so getUserMedia asks instead of killing us" % key,
          plist.get(key, "").strip(), plist.get(key))
check("NSDownloadsFolderUsageDescription too",
      plist.get("NSDownloadsFolderUsageDescription", "").strip())
check("the screens this was worth doing for are drawn at their own size",
      plist.get("NSHighResolutionCapable") is True)
check("the executable named is the one the installer writes",
      plist.get("CFBundleExecutable") == "browser")
check("the icon named is the file that is here",
      plist.get("CFBundleIconFile") == "icon"
      and (HERE / "icon.icns").exists())
check("it has an identifier of its own, not Qt's default",
      plist.get("CFBundleIdentifier") == "org.browser.browser")
check("it is a bundled application, not a plugin",
      plist.get("CFBundlePackageType") == "APPL")
check("it refuses a macOS too old for Qt 6.8 up front",
      tuple(int(p) for p in plist["LSMinimumSystemVersion"].split("."))
      >= (12, 0), plist.get("LSMinimumSystemVersion"))
schemes = plist["CFBundleURLTypes"][0]["CFBundleURLSchemes"]
check("it can be made the default browser", set(schemes) == {"http", "https"},
      schemes)
check("and a .html file can be opened with it",
      "public.html" in plist["CFBundleDocumentTypes"][0]["LSItemContentTypes"])
check("a browser is allowed to load plain http",
      plist["NSAppTransportSecurity"]["NSAllowsArbitraryLoads"] is True)
check("nothing claims a Screen Recording key, because macOS has none",
      not any("ScreenCapture" in k or "ScreenRecording" in k for k in plist))

# ---------------------------------------------------------------------
print("\n(5) icon.icns is really an .icns")
raw = (HERE / "icon.icns").read_bytes()
check("the magic is right", raw[:4] == b"icns", raw[:4])
check("the length in the header is the length of the file",
      struct.unpack(">I", raw[4:8])[0] == len(raw),
      (struct.unpack(">I", raw[4:8])[0], len(raw)))
slots, off, bad = {}, 8, []
while off < len(raw):
    kind = raw[off:off + 4].decode("ascii", "replace")
    length = struct.unpack(">I", raw[off + 4:off + 8])[0]
    if length < 8 or off + length > len(raw):
        bad.append((kind, length))
        break
    data = raw[off + 8:off + length]
    if data[:8] != b"\x89PNG\r\n\x1a\n":
        bad.append((kind, "not a PNG"))
    else:
        slots[kind] = struct.unpack(">II", data[16:24])
    off += length
check("every slot walks cleanly to the end", not bad and off == len(raw),
      bad or off)
check("each slot really holds a PNG", len(slots) >= 10, sorted(slots))
for kind, size in (("ic07", 128), ("ic08", 256), ("ic09", 512),
                   ("ic10", 1024), ("ic13", 256), ("ic14", 512)):
    check("%s is a %dx%d image" % (kind, size, size),
          slots.get(kind) == (size, size), slots.get(kind))
check("the Dock's retina sizes are there, so it is not scaled up",
      {"ic11", "ic12", "ic13", "ic14"} <= set(slots), sorted(slots))
check("and the small ones, for the window menu and the Finder",
      {"icp4", "icp5"} <= set(slots), sorted(slots))
check("it is not a renamed PNG", raw[:8] != b"\x89PNG\r\n\x1a\n")

# ---------------------------------------------------------------------
print("\n(6) install-mac.sh builds the shape macOS requires")
sh = read("install-mac.sh")
check("it is valid shell",
      subprocess.run(["sh", "-n", str(HERE / "install-mac.sh")]).returncode
      == 0)
check("it refuses to install for real anywhere but a Mac",
      'if [ "$(uname -s)" != "Darwin" ]' in sh and "exit 1" in sh)
dry = subprocess.run(["sh", str(HERE / "install-mac.sh"), "--dry-run",
                      "--to", "/tmp/not-really"],
                     capture_output=True, text=True)
check("...but says what it would do anywhere", dry.returncode == 0,
      dry.stderr.strip()[-300:])
out = dry.stdout
check("nothing was actually written",
      not Path("/tmp/not-really/browser.app").exists())
for want in ("Contents/Info.plist", "Contents/Resources/icon.icns",
             "Contents/PkgInfo", "Contents/MacOS/browser",
             "Resources/app/browser.py", "Resources/app/settings.html",
             "Resources/app/theme_web.py", "Resources/app/words-de.txt"):
    check("it puts %s in the bundle" % want, want in out, )
check("the start page's pictures come along",
      "Resources/app/backgrounds" in out)
check("the suite stays outside the application",
      "test_page.py" not in out and "test_mac.py" not in out
      and "_boot.py" not in out)
check("and so does the port tooling",
      "mac_port" not in out and "runall.sh" not in out)
check("the launcher execs python on browser.py, and does not sit around",
      'exec "${BROWSER_PYTHON:-python3}" "$DIR/browser.py" "$@"' in sh)
check("an ad-hoc signature is asked for, so the camera is not re-asked "
      "after every rebuild", "codesign --force --deep --sign -" in sh)
check("the quarantine flag is cleared if this came from a download",
      "xattr -dr com.apple.quarantine" in sh)
check("it says out loud that Screen Recording cannot be asked for in-app",
      "Screen Recording" in sh)
check("it checks PyQt6 is there before building anything",
      "import PyQt6.QtWebEngineWidgets" in sh)

# ---------------------------------------------------------------------
print("\n(6b) the rows that name this machine's own habits")
check("the phone-receiver row warns about the macOS firewall",
      "accept incoming connections" in src)
check("...and says what happens if he says no",
      "nothing ever arrives" in src)
check("in German too", "eingehende Verbindungen" in src)
check("a call that cannot share a screen says why, in macOS's terms",
      '"callNoScreenPerm"' in src and "Screen Recording" in src
      and "Bildschirmaufnahme" in src)
check("and Wayland's reason is not offered to a Mac",
      "quartz" in read("calls.py"))
check("the engine is found through dyld, where there is no /proc",
      "_dyld_get_image_name" in read("calls.py"))
# the graphics-card row. gpu_cards() answers [] on darwin, so Settings
# shows the "nothing to choose" line -- and on Linux that line says
# "only one graphics card here", which is the wrong reason on a Mac
# (and plainly false on one with an eGPU). The reason there is that
# Metal hands a program its card and macOS keeps the choice nowhere a
# program may reach.
check("the graphics-card row gives the macOS reason",
      "macOS hands a program its graphics card itself (Metal)" in src
      and "no window at start-up asking" in src)
check("...in German too",
      "macOS gibt einem Programm die Grafikkarte selbst" in src)
check("...and Linux's reason is not left on a Mac",
      "Only one graphics card here" not in src
      and "nur eine Grafikkarte" not in src)
check("the picker really cannot open there either",
      'if sys.platform in ("win32", "darwin"):\n        # there is nothing '
      'this window could do there' in src)
# the experimental engine pane is not a dead switch: it is a shortcut
# bound only when the module imports, and engine_pane.py does not come
# across. Nothing in Settings, nothing in the README's key table.
check("the engine pane leaves no dead switch behind",
      not (HERE / "engine_pane.py").exists()
      and "if HAVE_ENGINE_PANE:" in src
      and "`Ctrl+Shift+E`" not in read("README.md")   # not Shift+Esc
      and "enginePane" not in read("settings.html"))
check("the screen permission is asked without prompting him",
      "CGPreflightScreenCaptureAccess" in read("calls.py"))

# ---------------------------------------------------------------------
print("\n(6c) the installer refuses Rosetta, and loudly")
# A Rosetta-translated Chromium is the biggest source of lag available
# on an Apple Silicon Mac, and the worst kind: it starts, it runs, and
# it feels broken with nothing saying why. So this is a refusal and
# not a warning.
check("the machine is asked of sysctl, not of uname",
      "sysctl -n hw.optional.arm64" in sh)
check("...because uname tells a translated shell x86_64, which is true "
      "of the process and says nothing about the machine",
      "a shell running under Rosetta is" in sh
      and "told x86_64 by uname" in sh)
check("whether this very shell is translated is printed too",
      "sysctl.proc_translated" in sh)
check("the Python's own architecture is asked and printed",
      "platform.machine()" in sh and 'say "python:    $PY ($PYARCH)"' in sh)
check("and the PyQt6 wheel's Mach-O is read for its architecture",
      "PyQt6.QtCore as m" in sh and "arm64|x86_64" in sh)
check("an x86_64 Python on Apple Silicon is refused outright",
      "REFUSING: this is an Apple Silicon Mac" in sh
      and 'if [ "$SILICON" = "1" ] && [ "$PYARCH" = "x86_64" ]' in sh)
check("...and an x86_64 Qt wheel is refused too",
      "not arm64" in sh)
check("the refusal says the three commands that fix it",
      "arch -arm64" in sh and "pip install PyQt6" in sh
      and "BROWSER_PYTHON=" in sh)
check("--force is there for somebody who means it",
      "--force)   FORCE=" in sh and '[ -n "$FORCE" ] || exit 1' in sh)
check("and --force is in the usage text",
      "--force         -> install even on a translated python" in sh)

# ---------------------------------------------------------------------
print("\n(6d) somewhere to keep the bytecode")
# browser.py is 3.2 MB. Compiling it costs ~470 ms (measured on the
# Linux box, tools/macbench.py --only compile) against ~11 ms to load
# the cached form -- and a bundle in /Applications is root-owned while
# a quarantined one runs off a read-only image, so without this the
# half second is paid on every single launch.
check("the launcher points the cache somewhere always writable",
      'PYTHONPYCACHEPREFIX="$HOME/Library/Caches/browser/pycache"' in sh)
check("...and exports it, so the engine's own children inherit it",
      "export PYTHONPYCACHEPREFIX" in sh)
check("...and unsets it if that cannot be made: slow beats not starting",
      "unset PYTHONPYCACHEPREFIX" in sh)
check("the install warms the cache, so the FIRST launch is fast too",
      "-m compileall" in sh and 'PYTHONPYCACHEPREFIX="$PYC"' in sh)
check("...against the files at the path they will be read from",
      '"$C/Resources/app"' in sh and "keyed on the absolute path" in sh)
check("--dry-run says it would compile and compiles nothing",
      "would: compile the bundle's python" in out)
check("the quarantine strip explains app translocation, which is the "
      "reason the cache would miss every launch otherwise",
      "translocated" in sh and "/private/var/folders" in sh)
check("and browser.py carries the same fallback for its siblings",
      "_mac_pycache()" in src
      and 'base / "Library/Caches/browser/pycache"' in src)

# ---------------------------------------------------------------------
print("\n(6e) the benchmark harness, and what it refuses to claim")
bench = read("tools/macbench.py")
check("it ships in the edition", (HERE / "tools/macbench.py").exists())
check("...with the page built to be measured",
      (HERE / "tools/lagtest.html").exists()
      and "endless animations" in read("tools/lagtest.html"))
listed = subprocess.run([sys.executable, str(HERE / "tools/macbench.py"),
                         "--list"], capture_output=True, text=True)
check("it runs and lists its benches", listed.returncode == 0,
      listed.stderr.strip()[-200:])
names = [line.split()[0] for line in listed.stdout.splitlines() if line.strip()]
for want in ("compile", "codecs", "paint", "startup", "coldwarm",
             "scroll", "video", "tabs", "timers"):
    check("it measures %s" % want, want in names, names)
check("every bench the brief asked for is there: cold and warm start, "
      "time to first paint, fps over a scroll, fps on a video, idle "
      "cpu with ten tabs, rss per tab -- plus the codec question, "
      "which turned out to matter more than any of them",
      len(names) == 9, names)
check("the macOS column says unmeasured, in those words",
      "unmeasured" in bench)
check("...and it is never estimated from the Linux number",
      "not estimated" in bench or "not estimated" in read("../PORT.md"))
check("it runs against a throwaway profile, never his own",
      'os.environ["BROWSER_HOME"]' in bench and "mkdtemp" in bench)
check("and it says plainly that an offscreen fps is not a Mac fps",
      "offscreen software raster" in bench)

# ---------------------------------------------------------------------
print("\n(6e2) the suite runner, on a machine that is not this one")
# This is the runner macselftest.sh step 3 calls, so it is run on the
# Mac -- and a stock Mac has neither of the two programs it used.
runall = read("tools/runall.sh")
check("it is valid shell",
      subprocess.run(["sh", "-n", str(HERE / "tools/runall.sh")]).returncode
      == 0)
check("it does not call a bare `python`, which macOS has not got",
      ' python "$1"' not in runall and "timeout 900 python" not in runall)
check("...it honours BROWSER_PYTHON, the same variable the .app uses",
      'PY="${BROWSER_PYTHON:-python3}"' in runall
      and 'BROWSER_PYTHON:-python3' in read("install-mac.sh"))
check("timeout(1) is GNU coreutils, so there is a fallback",
      'command -v timeout' in runall and "gtimeout" in runall)
check("...and no timeout at all still runs the tests rather than "
      "reporting ninety command-not-founds", 'TMO=""' in runall)
check("it says which python it used, so a wrong one is visible",
      'echo "python: $PY' in runall)
# A guard that only runs when somebody types its name is not in the
# suite. On 2026-10-29 six mac-only guards were on disk and none of
# them was in this list, so the tester's macselftest.sh step 3 -- which
# runs exactly this script -- would have skipped every one. Read off
# mac_port.json rather than hand-listed, so the next one cannot be
# forgotten quietly.
import json as _json
_cfg = _json.loads(read("tools/mac_port.json"))
_guards = sorted(f for f in _cfg["mac_only_files"]
                 if f.startswith("test_") and f.endswith(".py"))
_missing = [f for f in _guards if f not in runall]
check("every mac-only guard is named in the runner, not just on disk",
      not _missing, _missing or "all %d of them" % len(_guards))

# ---------------------------------------------------------------------
print("\n(6f) one command for the person who finally has a Mac")
selftest = (HERE.parent / "macselftest.sh")
check("macselftest.sh is next to the edition", selftest.exists())
sst = selftest.read_text(encoding="utf-8")
check("it is valid shell",
      subprocess.run(["sh", "-n", str(selftest)]).returncode == 0)
sheet = subprocess.run(["sh", str(selftest), "--sheet"],
                       capture_output=True, text=True)
check("--sheet prints the questions and asks nothing",
      sheet.returncode == 0 and "MAC-01-01" in sheet.stdout
      and "    do:   " in sheet.stdout and "   > " not in sheet.stdout,
      sheet.stderr.strip()[-200:])
asked = sheet.stdout.count("    ask:  ")
check("every open question is in it: PORT.md's twenty-four plus the "
      "QA plan's", asked >= 35, asked)
# The sheet is split in two: the ten minutes that can only be answered
# on real hardware, and the rest. Both have to be there -- a tier-1
# list on its own would be the old "24 questions we thought of first"
# with a new name on it.
check("...in two tiers, so ten minutes buys the blocked sections first",
      "TIER 1" in sheet.stdout and "TIER 2" in sheet.stdout)
tier1 = sheet.stdout[sheet.stdout.index("TIER 1"):
                     sheet.stdout.index("TIER 2")]
check("...and tier 1 is a tester's ten minutes, not all of it",
      8 <= tier1.count("    ask:  ") <= 16, tier1.count("    ask:  "))
# The questions carry the QA plan's own Test IDs and areas now, so an
# answer drops into that report's test log instead of being translated
# into it by hand.
for area in ("1 install", "2 UI", "6 media", "12 perf", "13 a11y",
             "16 stability", "18 update", "18 uninstall", "10 privacy"):
    check("the sheet covers QA area [%s]" % area,
          "[%s]" % area in sheet.stdout)
# PORT.md's open questions, by TOPIC rather than by number: the
# numbering went when the questions were regrouped under the plan's
# sections, and a check keyed to "\n 1. " would have passed on a sheet
# that had quietly lost half of them. Each entry is a word that only
# that question would put on the page.
PORT_TOPICS = {
    1: ("it starts at all",), 2: ("Notifications",),
    3: ("awake",), 4: ("Cmd+Alt+V",), 5: ("Netflix",),
    6: ("Dock next to Safari",), 7: ("Cmd+T",), 8: ("menu bar",),
    9: ("closing last window",), 10: ("Screen Recording",),
    11: ("off the phone",), 12: ("call panel",),
    13: ("Retina",), 14: ("arm64",), 15: ("launch",),
    16: ("magnification",), 17: ("1080p60",), 18: ("ten tabs",),
    19: ("behind another app",), 20: ("external monitor",),
    21: ("ZDF",), 22: ("see-through",), 23: ("Downloads",),
    24: ("codecs",),
}
# 14 and 15 are answered by MEASUREMENT now rather than by asking, so
# they are looked for in the script, not only in the sheet.
MEASURED = (14, 15)
for n, words in sorted(PORT_TOPICS.items()):
    where = sst if n in MEASURED else sheet.stdout
    check("PORT.md question %d is still covered (%s)" % (n, words[0]),
          any(w in where for w in words))
check("it checks the architecture first of all",
      "hw.optional.arm64" in sst and "RUNNING UNDER ROSETTA" in
      read("tools/macbench.py"))
check("...then installs, then runs the suite, then the benchmark, "
      "then times the launches, then asks",
      sst.index("2. the install") < sst.index("3. the suite")
      < sst.index("4. the benchmark") < sst.index("5. the launches")
      < sst.index("6. the questions"))
# The answers come back as ONE block the tester copies out of the
# terminal, not as 24 prompts and not as a file he has to go and find.
# Both scissor lines, and one "Qn label :" slot per question, or the
# thing he pastes back is not a thing a session can read.
check("the answers come back as one copy-paste block",
      "COPY FROM HERE" in sst and "COPY TO HERE" in sst)
check("...with one fill-in line per question, keyed by Test ID",
      "%-11s %-24s : " in sst)
check("...and the block says the build was never run on a Mac",
      "UNVERIFIED BUILD" in sst)
# The interactive path is opt-in, and when it is used it must read the
# PERSON, not the pipe feeding it questions. A bare `read` inside
# `questions | while read` consumes the next question instead, which
# silently recorded every answer as "(not answered)".
check("--ask reads the terminal, not the question pipe",
      "/dev/tty" in sst and "<&3" in sst)
# Said twice on purpose and asserted twice: once where the suite
# result is printed, and once at the very bottom under the block. A
# tester who is told the suite passed and nothing else reports "it
# works", which is the one answer that teaches us nothing.
check("and it says a green suite is not the same as working",
      "It proves nothing" in sst
      and "about any of the questions below" in sst)
check("...and says so again at the bottom, under the block",
      "Nothing is verified until that block comes back" in sst)

print("\n(7) what came across, and what did not")
for gone, why in (("mpris.py", "MPRIS is D-Bus"),
                  ("engine_pane.py", "web_engine.so has no Mac build"),
                  ("install.sh", "the Linux installer"),
                  ("icon.ico", "the Windows icon"),
                  ("web_engine.so", "a Linux binary")):
    check("%s is not here (%s)" % (gone, why), not (HERE / gone).exists())
for want, why in (("phone.py", "the ear for the Android app"),
                  ("calls.py", "what a call needs, and what this engine is"),
                  ("test_phone.py", "and the suites for both"),
                  ("test_calls.py", "ditto"),
                  ("test_daystep.py", "the clock-change helpers"),
                  ("agent.py", "AF_UNIX is a thing macOS has"),
                  ("agent_bridge.py", "the other half of that socket"),
                  ("test_agentops.py", "and the suite that tests it"),
                  ("test_macbranch.py", "the darwin branches"),
                  ("theme_web.py", "the site theming"),
                  ("tests/harness.py", "the suite's own helper")):
    check("%s is here (%s)" % (want, why), (HERE / want).exists())
check("browser.py parses", ast.parse(src) is not None)
check("...and it is the whole file, not a truncated port",
      len(src) > 900000, len(src))
check("the Linux data folder is still in it for a developer here",
      'else Path.home() / ".local/share/browser"' in src)
check("and the Mac one is what it uses there",
      'Path.home() / "Library/Application Support/browser"' in src)

print("\n%d checks failed" % len(fails))
if fails:
    for f in fails:
        print("  - " + f)
sys.exit(1 if fails else 0)
