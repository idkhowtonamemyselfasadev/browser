#!/usr/bin/env python3
"""A day is not 86400 seconds, twice a year — and the streak knew it.

Found on the morning of 2026-10-26, a few hours after the European
clocks went back: test_bookmarks2's "the streak is every day the site
was visited" started failing on its own, with streak 1 for a site
visited on two days running. Nothing in the test was wrong. 2026-10-25
was 25 hours long, so stepping back 86400 seconds from this morning's
midnight lands at 01:00 on the 25th, which is no day's *start* — the
walk misses, and the streak stops at 1.

That is every user's streak reset to 1 on the morning after every
clock change, twice a year, and the per-day chart putting a day's
pages into a bucket nobody looks in. So the clock is pinned here
rather than waited for: Europe/Berlin, and "now" set to the small
hours of 2026-10-26, which is the exact case that broke. It also
checks the spring change, where a day is 23 hours and the arithmetic
drifts the other way.

Offscreen, scratch data, no window: the two methods are called unbound
with a stand-in holding a history, the way test_winbranch does, so
this is about the counting and nothing else.
"""
import os
import sys
import time
from pathlib import Path

# before browser.py is imported, so every localtime() in here agrees
os.environ["TZ"] = "Europe/Berlin"
time.tzset()
os.environ["QT_QPA_PLATFORM"] = "offscreen"
os.environ["BROWSER_NO_LIB_CHECK"] = "1"
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE / "tests"))

import harness as H  # noqa: E402
B = H.boot()

fails = []


def check(what, ok, detail=""):
    print(("  ok   " if ok else "  FAIL ") + what
          + (("  <" + str(detail) + ">") if detail != "" else ""))
    if not ok:
        fails.append(what)


def at(y, m, d, hh=12, mm=0):
    """A local timestamp, with the library deciding the offset."""
    return int(time.mktime((y, m, d, hh, mm, 0, 0, 0, -1)))


class Clock:
    """The real time module with one answer replaced."""

    def __init__(self, now):
        self._now = now

    def time(self):
        return self._now

    def __getattr__(self, name):
        return getattr(time, name)


class Site:
    """Just enough of a browser to be asked about a history."""

    def __init__(self, rows):
        self.history = rows


# the clocks went back in the night of 2026-10-25 (that day: 25 hours)
# and forward in the night of 2026-03-29 (that day: 23 hours)
AUTUMN = at(2026, 10, 25)
SPRING = at(2026, 3, 29)

print("=== the library agrees that those days are not 24 hours ===")
back = B._day_start(at(2026, 10, 26)) - B._day_start(AUTUMN)
fwd = B._day_start(at(2026, 3, 30)) - B._day_start(SPRING)
check("the day the clocks go back is 25 hours", back == 90000, back)
check("the day they go forward is 23 hours", fwd == 82800, fwd)

print()
print("=== one calendar day back, and forward ===")
oct26 = B._day_start(at(2026, 10, 26))
oct25 = B._day_start(AUTUMN)
oct24 = B._day_start(at(2026, 10, 24))
check("the day before the 26th is the 25th",
      B._day_before(oct26) == oct25,
      "%s vs %s" % (B._day_before(oct26), oct25))
check("the old arithmetic would have missed it",
      oct26 - 86400 != oct25)
check("...and two days back is the 24th",
      B._day_before(B._day_before(oct26)) == oct24)
mar30 = B._day_start(at(2026, 3, 30))
mar29 = B._day_start(SPRING)
check("the day before the 30th of March is the 29th",
      B._day_before(mar30) == mar29)
check("the old arithmetic would have overshot it",
      mar30 - 86400 != mar29)
check("forward over the autumn change", B._day_after(oct25) == oct26)
check("forward over the spring change", B._day_after(mar29) == mar30)
check("an ordinary day still works both ways",
      B._day_before(B._day_start(at(2026, 6, 10)))
      == B._day_start(at(2026, 6, 9))
      and B._day_after(B._day_start(at(2026, 6, 9)))
      == B._day_start(at(2026, 6, 10)))
check("every step lands on a real midnight",
      all(time.localtime(d).tm_hour == 0
          for d in (B._day_before(oct26), B._day_before(mar30),
                    B._day_after(oct25), B._day_after(mar29))))

print()
print("=== the streak, on the morning after the clocks changed ===")
real_time = B.time
try:
    B.time = Clock(at(2026, 10, 26, 0, 40))     # 00:40, as it was
    rows = [{"url": "https://mcpvp.com/a", "t": at(2026, 10, 24, 20)},
            {"url": "https://mcpvp.com/b", "t": at(2026, 10, 25, 14)},
            {"url": "https://mcpvp.com/c", "t": at(2026, 10, 25, 23)},
            {"url": "https://mcpvp.com/d", "t": at(2026, 10, 26, 0, 10)}]
    got = B.Browser.site_streak(Site(rows), "mcpvp.com")
    check("three days running are a streak of three",
          got["streak"] == 3, got)
    check("...and every visit is still counted", got["visits"] == 4, got)
    check("...on three distinct days", got["days"] == 3, got)

    # and the shape test_bookmarks2 uses: visited yesterday and today
    B.time = Clock(at(2026, 10, 26, 2, 0))
    rows = [{"url": "https://mcpvp.com/a", "t": at(2026, 10, 25, 22)},
            {"url": "https://mcpvp.com/b", "t": at(2026, 10, 26, 1)}]
    got = B.Browser.site_streak(Site(rows), "mcpvp.com")
    check("yesterday and today are a streak of two",
          got["streak"] == 2, got)

    # the same day, before the site has been visited today at all
    B.time = Clock(at(2026, 10, 26, 9, 0))
    rows = [{"url": "https://mcpvp.com/a", "t": at(2026, 10, 24, 20)},
            {"url": "https://mcpvp.com/b", "t": at(2026, 10, 25, 20)}]
    got = B.Browser.site_streak(Site(rows), "mcpvp.com")
    check("a streak that ran up to yesterday still counts",
          got["streak"] == 2, got)

    # the spring change, where a day is 23 hours
    B.time = Clock(at(2026, 3, 30, 8, 0))
    rows = [{"url": "https://mcpvp.com/a", "t": at(2026, 3, 28, 20)},
            {"url": "https://mcpvp.com/b", "t": at(2026, 3, 29, 20)},
            {"url": "https://mcpvp.com/c", "t": at(2026, 3, 30, 7)}]
    got = B.Browser.site_streak(Site(rows), "mcpvp.com")
    check("a 23-hour day does not break it either",
          got["streak"] == 3, got)

    # a gap is still a gap: the fix must not invent days
    B.time = Clock(at(2026, 10, 26, 9, 0))
    rows = [{"url": "https://mcpvp.com/a", "t": at(2026, 10, 22, 20)},
            {"url": "https://mcpvp.com/b", "t": at(2026, 10, 25, 20)}]
    got = B.Browser.site_streak(Site(rows), "mcpvp.com")
    check("a day missed still ends the streak", got["streak"] == 1, got)
    check("...and the older day is still one of the days",
          got["days"] == 2, got)
    rows = [{"url": "https://mcpvp.com/a", "t": at(2026, 10, 20, 20)}]
    got = B.Browser.site_streak(Site(rows), "mcpvp.com")
    check("a site not seen for days has no streak", got["streak"] == 0, got)

    print()
    print("=== the per-day chart over the same night ===")
    B.time = Clock(at(2026, 10, 26, 9, 0))
    rows = [{"url": "https://mcpvp.com/a", "t": at(2026, 10, 24, 20)},
            {"url": "https://mcpvp.com/b", "t": at(2026, 10, 25, 14)},
            {"url": "https://mcpvp.com/c", "t": at(2026, 10, 25, 23)},
            {"url": "https://mcpvp.com/d", "t": at(2026, 10, 26, 8)}]
    stats = B.Browser.browsing_stats(Site(rows), days=3)
    edges = [row["t"] for row in stats["days"]]
    check("the three buckets are the three real midnights",
          edges == [oct24, oct25, oct26], edges)
    check("...each of them really a midnight",
          all(time.localtime(e).tm_hour == 0 for e in edges))
    check("and every page landed in its own day",
          [row["pages"] for row in stats["days"]] == [1, 2, 1],
          stats["days"])
    check("nothing was lost on the way", stats["pages"] == 4, stats["pages"])
    week = B.Browser.browsing_stats(Site(rows), days=7)
    check("a week is seven days, with no repeats",
          len(week["days"]) == 7
          and len({row["t"] for row in week["days"]}) == 7)
    check("...and they are consecutive calendar days",
          all(B._day_after(week["days"][i]["t"]) == week["days"][i + 1]["t"]
              for i in range(6)))

    print()
    print("=== reopening a 25-hour day ===")
    rows = [{"url": "https://mcpvp.com/early", "t": at(2026, 10, 25, 1)},
            {"url": "https://mcpvp.com/late", "t": at(2026, 10, 25, 23, 30)},
            {"url": "https://mcpvp.com/next", "t": at(2026, 10, 26, 1)}]
    span = B.Browser.restore_day
    check("the day's end is the next midnight, 25 hours on",
          B._day_after(oct25) - oct25 == 90000)
    check("...which the old default would have fallen an hour short of",
          oct25 + 86400 < B._day_after(oct25))
    assert span is not None
finally:
    B.time = real_time

print()
if fails:
    print("FAILED %d" % len(fails))
    for row in fails:
        print("  - " + row)
    sys.exit(1)
print("all good")
