#!/usr/bin/env python3
"""The address bar may not show letters that are lying.

Punycode is why muenchen.de can be xn--mnchen-3ya.de and be shown back
with its umlaut. It is also how xn--pypal-4ve.com is shown as
"paypal.com" whose "a" is Cyrillic U+0430, which no font and no reader
can tell from the real one. A browser's address bar is the only place a
person can check who they are talking to, so what it shows has to be
the truth rather than the prettier of two options.

What was here before was dead code with an inverted comment:

    # the host in its own letters: QUrl keeps punycode in
    # toString, and the point of showing it decoded is that
    # xn--pple-43d.com is not apple.com
    host = url.host()
    if host.startswith("xn--") or ".xn--" in host:
        ...decode...

Two things wrong with it. QUrl.host() has ALREADY decoded the IDN, so
it never begins with "xn--" and that branch never ran once -- the
decoding was Qt's doing all along. And the reasoning is backwards:
decoded, xn--pple-43d.com reads as apple.com with a Cyrillic a, which
is the attack succeeding. Punycode is what WARNS.

So the test is a table, and it has to hold at both ends: every attack
shows as punycode, and every legitimate internationalised domain still
shows in its own letters. A fix that broke muenchen.de would be worse
than the bug, because it would be turned off.

Found on bug-fix day while working QA plan section 4 ("unicode/IDN,
homograph protection"), 2026-10-29. Static apart from importing
browser.py for Qt; opens no window, writes nothing. mac-only until
upstream takes it.
"""
import os
import sys
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
os.environ.setdefault("BROWSER_NO_LIB_CHECK", "1")
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import browser as B  # noqa: E402

fails = []


def check(what, ok, detail=""):
    print(("  ok   " if ok else "  FAIL ") + what
          + (("  <" + str(detail) + ">") if detail != "" else ""))
    if not ok:
        fails.append(what)


# (url, what it is, must the address bar show the punycode?)
ATTACKS = [
    ("https://xn--pypal-4ve.com/", "paypal.com, Latin p + Cyrillic a"),
    ("https://xn--pple-43d.com/", "apple.com, Cyrillic a + Latin pple"),
    ("https://xn--gogle-3nd.com/", "google.com with a Cyrillic o"),
]
LEGITIMATE = [
    ("https://xn--mnchen-3ya.de/", "münchen.de", "German umlaut"),
    ("https://xn--bcher-kva.de/", "bücher.de", "German umlaut"),
    ("https://xn--fiqs8s.cn/", "中国.cn", "pure Chinese"),
    ("https://xn--d1acpjx3f.xn--p1ai/",
     "яндекс.рф",
     "pure Russian, Russian TLD"),
]

print("(1) a host whose letters mix alphabets is shown as punycode")
for url, what in ATTACKS:
    shown = B.pretty_url(url)
    ace = url.split("//")[1].rstrip("/")
    check("%s -> punycode" % what, ace in shown, shown)

print("\n(2) ...and a real internationalised domain still reads properly")
for url, want, what in LEGITIMATE:
    shown = B.pretty_url(url)
    check("%s (%s) still shown in its own letters" % (want, what),
          want in shown, shown)

print("\n(3) plain names are untouched")
for url, want in (("https://example.com/", "example.com"),
                  ("https://sub.example.co.uk/a?b=1", "sub.example.co.uk")):
    check("%s" % want, want in B.pretty_url(url), B.pretty_url(url))

print("\n(4) the rule itself, directly")
check("a single-script label is safe", B.idn_safe_to_show("яндекс.рф"))
check("a mixed-script label is not",
      not B.idn_safe_to_show("pаypal.com"))
check("digits and hyphens carry no script",
      B.idn_safe_to_show("my-site-2024.com"))
check("...so they cannot make a pure label look mixed",
      B.idn_safe_to_show("блог-2024.рф"))

print("\n(5) the gap that is still open, pinned so it cannot be forgotten")
# A label that is confusable while being entirely ONE script. Five
# Cyrillic letters that read as "apple" mix nothing, so the rule above
# cannot see it. Catching it is the "whole-script confusable" rule and
# it needs to know which alphabets the user actually reads -- a policy
# for all four editions, not a default to invent in one function.
#
# Asserted as STILL BROKEN on purpose, the way test_bridgecalls pins
# its known gaps: the day somebody fixes it, this check fails and says
# so, instead of the fix landing with nobody noticing the pin is stale.
whole = "https://xn--80ak6aa92e.com/"
shown = B.pretty_url(whole)
check("whole-script confusables are NOT caught yet (known, open; "
      "if this FAILS somebody fixed it -- move it up to section 1)",
      "xn--80ak6aa92e" not in shown)
check("...and this is what the user is shown today",
      "аррӏе" in shown, shown)

print("\n(6) ...and turning address decoding OFF must not turn it off")
# `decode` is a preference in Settings (barDecode): whether he wants to
# read %20 as a space and an umlaut as an umlaut. The homograph guard is
# not a preference. bar_text_for hands pretty_url url.toString(), which
# Qt has already turned into Unicode, so before this the CAUTIOUS
# setting was the one that left "p<cyrillic a>ypal.com" on screen.
for url, what in ATTACKS:
    ace = url.split("//")[1].rstrip("/")
    for dec in (True, False):
        shown = B.pretty_url(url, decode=dec)
        check("%s -> punycode with decode=%s" % (what, dec),
              ace in shown, shown)
# and the already-Unicode form, which is how it actually arrives
uni = "https://p\u0430ypal.com/"
for dec in (True, False):
    check("a host that arrives already decoded is re-encoded "
          "(decode=%s)" % dec,
          "xn--pypal-4ve.com" in B.pretty_url(uni, decode=dec),
          B.pretty_url(uni, decode=dec))
# the preference itself still works for the thing it IS for
check("decode=True still turns %20 into a space",
      " " in B.pretty_url("https://example.com/a%20b"),
      B.pretty_url("https://example.com/a%20b"))
check("...and decode=False leaves it alone",
      "%20" in B.pretty_url("https://example.com/a%20b", decode=False),
      B.pretty_url("https://example.com/a%20b", decode=False))

print("\n%d checks failed" % len(fails))
for f in fails:
    print("  - " + f)
sys.exit(1 if fails else 0)
