"""Taking a page off the phone: the other end of "Send to the desktop".

The Android edition of this browser has a menu entry that hands the page
you are looking at to the desktop one -- you find something on the sofa
and read it at the desk. That half has been finished for a while. This
is the half that was missing: until now the desktop browser had no ear
on the network at all. The agent bridge is a local pipe (QLocalSocket)
that nothing off this machine can reach, and the bridge's http mirror
binds 127.0.0.1, which is exactly right for a shell on this box and no
use whatever to a tablet in the next room.

So this is a small and deliberately dull listener, and the list of what
it will not do is the whole design:

* It is off until he switches it on. Switching it on is the only thing
  in the browser that opens a port.
* It answers two requests and no others: `POST /open?url=...`, which is
  what the Android edition sends, and `GET /ping`, so he can tell from
  the phone (or with curl) that the ear is open. Anything else is a
  404. None of the agent bridge's ops can be reached through here -- a
  phone on the network may ask for a tab, and that is all it may ask.
* Only `http` and `https` addresses are taken. A `file://` or a
  `javascript:` URL dropped in from the network would be worth the
  whole machine, so those are refused by their scheme rather than by
  cleverness later on.
* Only his own network may ask: loopback and the private ranges. If the
  port is ever forwarded by accident, the internet still gets a 403.
* Twelve pages a minute, then 429, so a loose script in the house
  cannot bury him in tabs.
* The URL is never opened by the thread that heard it. The browser is
  not thread-safe, and a tab opened from a request handler is a crash
  waiting for a busy moment. Arrivals go into a list, and the window's
  own timer takes them from it (`take`) on the Qt thread -- which is
  also what makes every rule above testable without a window, a port or
  a browser.

Nothing here reaches out. It listens, and the only thing it ever does
with what it hears is put a URL in a list.
"""

import hmac
import ipaddress
import json
import re
import threading
import time
from collections import deque
from urllib.parse import parse_qs, unquote, urlsplit

#: the port the Android edition posts to (Send.kt: "<host>:8766/open").
#: Changing it here means changing it on the phone too, which is why it
#: is also a config key rather than only this number.
PORT = 8766

#: the only two schemes a page from the network may name. See the
#: module docstring: this is a refusal by scheme, on purpose.
SCHEMES = ("http", "https")

#: caps. A URL longer than this is not a URL anybody sent from a phone,
#: and reading an unbounded body from a stranger is how a listener gets
#: used as a memory bomb.
URL_MAX = 4096
BODY_MAX = 16384

#: how many pages a minute are taken before the rest get a 429.
RATE = 12
RATE_WINDOW = 60.0

#: how many arrivals are remembered for the "what came in" list. Only
#: for showing him; nothing is written to disk from here.
LOG_MAX = 40

#: what a bare host looks like, for the one kindness this takes: an
#: address typed without a scheme ("example.com/x") is read as https.
#: Anything with a colon before the first slash that is not http or
#: https never gets here -- urlsplit has already called it a scheme.
_BARE = re.compile(r"^[A-Za-z0-9]([A-Za-z0-9.\-]*[A-Za-z0-9])?"
                   r"(:\d{1,5})?(/.*)?$")


def clean_url(raw):
    """The one address this listener will accept, or "" for no.

    Everything a stranger sends is suspect, so this says yes to very
    little: an http or https URL with a host in it, nothing longer than
    URL_MAX, and no control characters (a newline in a URL is how a
    header or a log line gets forged further down). A host typed with
    no scheme is read as https, because that is what a human means when
    they type one and it cannot smuggle a scheme past the check -- a
    colon before the first slash is a scheme as far as urlsplit is
    concerned, and only two of those are allowed."""
    text = str(raw or "").strip()
    if not text or len(text) > URL_MAX:
        return ""
    if any(ord(ch) < 0x20 or ord(ch) == 0x7F for ch in text):
        return ""
    parts = urlsplit(text)
    if not parts.scheme:
        if not _BARE.match(text):
            return ""
        text = "https://" + text
        parts = urlsplit(text)
    if parts.scheme.lower() not in SCHEMES:
        return ""
    if not parts.hostname:
        return ""
    return text


def is_home(addr):
    """Whether this address is on his own network.

    Loopback and the private ranges, which is what a phone on the house
    wifi has. A public address means the port has been forwarded by
    accident (or the browser is on a machine with a public address), and
    then the honest answer to the internet is no. An address that is not
    an address at all is also no."""
    text = str(addr or "")
    if text.startswith("::ffff:"):
        # a v4 phone arriving on a v6 socket
        text = text[7:]
    if "%" in text:
        text = text.split("%", 1)[0]   # the interface a link-local names
    try:
        ip = ipaddress.ip_address(text)
    except ValueError:
        return False
    return bool(ip.is_loopback or ip.is_private or ip.is_link_local)


class Drop:
    """The listener itself: a port, a list of arrivals and nothing else.

    `offer` is the whole of it. The http handler is a shell around that
    call, which is why the rules can be tested without a socket, and
    `take` is the only thing the Qt thread touches."""

    def __init__(self, port=PORT, token="", rate=RATE):
        # 0 is "any free port the kernel likes", which is how this is
        # tested, so it cannot go through `port or PORT` -- that reads a
        # deliberate 0 as "nothing was said". A missing or unreadable
        # config value is what falls back to 8766.
        try:
            self.port = PORT if port is None or port == "" else int(port)
        except (TypeError, ValueError):
            self.port = PORT
        self.token = str(token or "")
        self.rate = int(rate or RATE)
        self.server = None
        self.thread = None
        #: addresses heard and not yet opened. A deque because two
        #: threads touch it and append/popleft are atomic under the
        #: lock the interpreter already holds.
        self.waiting = deque()
        #: the last few arrivals, refusals included, for the window to
        #: show him. (when, who, what, verdict)
        self.log = deque(maxlen=LOG_MAX)
        self.taken = 0
        self.refused = 0
        self._stamps = deque()
        self._lock = threading.Lock()

    # ---- the rules ----

    def allowed(self, token, query=None):
        """Whether this request carries the right token, if one is set.

        No token set means no token asked for: the Android edition does
        not send one yet, and a feature that cannot be used is not a
        feature. With one set, it must match -- compared the slow way
        so the comparison does not leak the answer a character at a
        time."""
        if not self.token:
            return True
        given = str(token or "")
        if not given and query:
            given = str((query.get("token") or [""])[0])
        return hmac.compare_digest(given, self.token)

    def under_rate(self):
        """True if this one is inside the dozen a minute, and counts it."""
        now = time.monotonic()
        with self._lock:
            while self._stamps and now - self._stamps[0] > RATE_WINDOW:
                self._stamps.popleft()
            if len(self._stamps) >= self.rate:
                return False
            self._stamps.append(now)
            return True

    def offer(self, addr, raw, token="", query=None, from_page=False):
        """A phone offers a page. Returns (http code, answer dict).

        Everything the listener decides, it decides here: who asked,
        whether the token is right, whether the address is one of the
        two schemes, and whether he is being flooded. A yes puts the URL
        on `waiting` and opens nothing: that is the window's job, on the
        window's thread."""
        if from_page:
            # a website, not a phone. See _from_page in the handler:
            # the peer address of a page's own fetch() is 127.0.0.1,
            # which would otherwise walk straight through the check
            # below and hand any site an unlimited supply of tabs.
            return self._no(addr, raw, "from-a-page", 403)
        if not is_home(addr):
            return self._no(addr, raw, "not-home", 403)
        if not self.allowed(token, query):
            return self._no(addr, raw, "bad-token", 403)
        url = clean_url(raw)
        if not url:
            return self._no(addr, raw, "bad-url", 400)
        if not self.under_rate():
            return self._no(addr, url, "too-many", 429)
        self.waiting.append(url)
        self.taken += 1
        self.log.append((time.time(), str(addr or ""), url, "ok"))
        return 200, {"ok": True, "url": url}

    def _no(self, addr, raw, why, code):
        self.refused += 1
        self.log.append((time.time(), str(addr or ""),
                         str(raw or "")[:URL_MAX], why))
        return code, {"ok": False, "error": why}

    # ---- what the window asks ----

    def take(self):
        """Every address that has arrived since the last ask, in order.

        Called from the Qt thread by the window's timer. Draining it in
        one go rather than one per tick means a handful sent at once
        open together, and an empty list is the normal answer."""
        out = []
        while self.waiting:
            try:
                out.append(self.waiting.popleft())
            except IndexError:      # emptied under us; nothing to do
                break
        return out

    def status(self):
        """What state this is in, in one dict -- which is also how it is
        tested on a machine where no port may be opened."""
        return {"running": self.server is not None,
                "port": self.port,
                "token": bool(self.token),
                "waiting": len(self.waiting),
                "taken": self.taken,
                "refused": self.refused,
                "log": [{"t": t, "from": who, "url": url, "verdict": verdict}
                        for t, who, url, verdict in list(self.log)]}

    # ---- the port ----

    def start(self):
        """Open the port. Raises OSError if it is taken -- the caller
        says so in the window rather than failing the browser."""
        import http.server
        if self.server is not None:
            return True
        drop = self

        class Handler(http.server.BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.0"

            def _answer(self, code, payload):
                raw = json.dumps(payload).encode()
                self.send_response(code)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(raw)))
                self.end_headers()
                self.wfile.write(raw)

            def _who(self):
                return (self.client_address or ("", 0))[0]

            def _from_page(self):
                """Whether a website made this request rather than a phone.

                This is the one hole an ear on 127.0.0.1 has that an ear
                on the network does not: a page open in this very
                browser can fetch() the port, and its peer address is
                loopback, so "only his own network" says yes to it. What
                it would get is not the machine -- only http and https
                still, and only a background tab -- but a site able to
                open tabs whenever it likes has walked around the popup
                blocker, and that is not a thing to hand out.

                Every engine marks its own requests: a cross-origin
                fetch carries `Origin`, and Chromium sends the
                `Sec-Fetch-*` set on all of them. Neither is something
                HttpURLConnection on the phone sends, so refusing both
                costs the phone nothing and closes the hole."""
                if self.headers.get("Origin"):
                    return True
                return any(str(name).lower().startswith("sec-fetch-")
                           for name in self.headers.keys())

            def do_POST(self):
                path = urlsplit(self.path)
                if path.path.rstrip("/") not in ("/open", ""):
                    self._answer(404, {"ok": False, "error": "no-such-thing"})
                    return
                query = parse_qs(path.query)
                raw = (query.get("url") or [""])[0]
                length = int(self.headers.get("Content-Length") or 0)
                body = b""
                if 0 < length <= BODY_MAX:
                    body = self.rfile.read(length)
                elif length > BODY_MAX:
                    self._answer(413, {"ok": False, "error": "too-big"})
                    return
                if not raw and body:
                    # the Android edition sends the URL both ways: in the
                    # query and as the body. Either is enough.
                    try:
                        raw = unquote(body.decode("utf-8", "strict")).strip()
                    except UnicodeDecodeError:
                        raw = ""
                code, payload = drop.offer(self._who(), raw,
                                           self.headers.get("X-Token"), query,
                                           self._from_page())
                self._answer(code, payload)

            def do_GET(self):
                path = urlsplit(self.path)
                if path.path.rstrip("/") != "/ping":
                    self._answer(404, {"ok": False, "error": "no-such-thing"})
                    return
                if self._from_page():
                    # a page may not use this to find out that the
                    # browser is the thing on the other end of the port
                    self._answer(403, {"ok": False, "error": "from-a-page"})
                    return
                if not is_home(self._who()):
                    self._answer(403, {"ok": False, "error": "not-home"})
                    return
                if not drop.allowed(self.headers.get("X-Token"),
                                    parse_qs(path.query)):
                    self._answer(403, {"ok": False, "error": "bad-token"})
                    return
                # nothing about this machine in the answer: a scanner
                # that reaches the port learns that something answered
                # and not what it is a version of
                self._answer(200, {"ok": True, "app": "browser"})

            def log_message(self, *args):
                pass

        # "" is every interface, which is the point: a tablet in the
        # next room is not on 127.0.0.1. This line is why the whole
        # thing is off by default.
        self.server = http.server.ThreadingHTTPServer(("", self.port),
                                                      Handler)
        self.server.daemon_threads = True
        # port 0 means "any free one", which is how this is tested
        # without fighting whatever else is on the box for 8766. Take
        # the number back off the socket so `status` and the window's
        # message say the port that is really open.
        self.port = int(self.server.server_address[1])
        self.thread = threading.Thread(target=self.server.serve_forever,
                                       name="phone-drop", daemon=True)
        self.thread.start()
        return True

    def stop(self):
        server, self.server = self.server, None
        if server is not None:
            server.shutdown()
            server.server_close()
        self.thread = None
        return True
