# Changelog — the macOS edition

This edition is generated from the Linux one
(`idkhowtonamemyselfasadev/browser`) by `tools/mac_port.py`. Features
are written there and arrive here; this file records what happened to
*this* edition, not what the browser gained.

## 1.0 — 2026-10-26

The first one. Generated from the Linux working tree at `28a6995`
plus the darwin branches that are still waiting in a patch to be
merged there (`mac_port.json: ported_from_worktree`).

What this edition is, over the shared file:

- **Where things live.** `~/Library/Application Support/browser`, the
  folder macOS keeps a program's own data in.
- **The PATH.** An app started from the Dock is handed
  `/usr/bin:/bin:/usr/sbin:/sbin` and nothing else — no shell profile
  runs — so `shutil.which` would have found no mpv, no ffmpeg, no git
  and no yt-dlp, and every one of those features would have reported
  "not installed on this machine" on a machine that has them.
  Homebrew's two prefixes and `~/.local/bin` are put back, after what
  PATH already says.
- **The screen stays awake** through `caffeinate -d -i -m -s -w <pid>`
  instead of `systemd-inhibit`. Tied to this process, so a browser
  that is killed outright cannot leave a Mac unable to sleep.
- **Notifications** through the Notification Center. The text and the
  title are handed to `osascript` as arguments (`on run argv`), never
  built into the AppleScript — a page title with a quote in it is an
  injection otherwise, not a notification.
- **Reading aloud** through `say`, with a voice picked from what
  `say -v ?` really lists rather than a guessed name, and the text fed
  to its input so a paragraph that starts with a dash is not read as a
  flag.
- **What a tab costs** out of `ps -o rss=,time=`; there is no `/proc`.
- **DRM.** Chrome's CDM on a Mac is always behind a path with a space
  in it, and Qt splits `QTWEBENGINE_CHROMIUM_FLAGS` on spaces, so the
  engine could never be told about it. It is linked into
  `~/Library/Caches/browser`, remade on every start, never copied.
- **No VA-API flags** (that is Linux's hardware decode; macOS decodes
  through VideoToolbox without being asked) and no GPU picker: Metal
  hands a process its card and macOS keeps that choice nowhere a
  program may write.
- **Glass** sits on the theme's solid base, as it does on Windows:
  Quartz blurs what is behind a window only through an
  NSVisualEffectView, which Qt gives a QMainWindow no way to ask for.
- **Fusion**, so a dark theme keeps dark scroll bars and dark popups.
- **Fonts**: SF Mono / Menlo / Monaco and SF Pro Text / Helvetica Neue
  after the Nerd Font in every stack, so a stack cannot run out and
  land on Times and Courier.
- **`open`** for an address another application owns, and VLC, IINA or
  mpv found inside their `.app` bundles, which no PATH would have.
- **An application bundle**: `install-mac.sh` builds `browser.app`
  with an `Info.plist` that lets a page ask for the camera and the
  microphone. Without those two keys macOS does not refuse — it kills
  the process the moment `getUserMedia` is called.
- **An `.icns`** made from the browser's own `icon.svg`, fitted to the
  rounded square every Mac icon is, at eleven sizes.

What is deliberately not here: `mpris.py` (MPRIS is a D-Bus protocol
of the Linux desktop), `engine_pane.py` (its `web_engine.so` has no
Mac build), `install.sh`, `icon.ico`. `agent.py` and `agent_bridge.py`
**are** here, unlike in the Windows edition: AF_UNIX is a thing macOS
has.

Not run on a Mac. See `../PORT.md` for exactly what that leaves
unproven.

## 1.1 — 2026-10-26

Two modules arrived from the Linux side while 1.0 was being built, and
both needed a darwin half before they told the truth here.

- **`calls.py` would have said screen sharing was fine.** Its reasoning
  is Linux's — no PipeWire, no ScreenCast portal, Wayland, black
  rectangle — and a Mac has none of those, so the panel fell through to
  "Sharing a screen can work here" on a machine where macOS has almost
  certainly never been asked for Screen Recording. It does not refuse
  that: it hands the page the desktop picture with no windows on it,
  which looks like a working share until the other side says they
  cannot see anything. Now the engine is found through dyld's own list
  (there is no `/proc`), the session is `quartz`, and the verdict comes
  from `CGPreflightScreenCaptureAccess`, which reports without
  prompting. Two new rows, English and German, naming where the tick
  box is.
- **`phone.py` binds all interfaces**, as it has to, so macOS asks once
  whether the browser may accept incoming connections. A "Deny" leaves
  the switch on and the feature dead with nothing saying why, so the
  settings row says it beforehand.

The port itself learned two things: it keeps a base snapshot for
worktree ports (`tools/_base`), and it records a hash of every file it
writes, so "was this hand-edited here" has an exact answer instead of
one that goes wrong whenever the Linux side moves.
