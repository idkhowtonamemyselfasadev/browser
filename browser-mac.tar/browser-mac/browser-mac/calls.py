"""What a call needs, and what this engine actually has.

Discord and Teams in a browser tab are the one thing on this machine
that can fail for a reason the browser cannot fix and does not even
mention: the web engine's own build. Qt's WebEngine is Chromium with
the patented codecs left out, and the wheel this browser runs on is
built without PipeWire as well. The page sees none of that. It asks
for a camera, gets a track with no codec to put it in, and the call
goes quiet -- or it asks to share a screen and hands over a black
rectangle, because the only capture path compiled in is X11's and the
session is Wayland.

Finding that out halfway through a call is the worst time to find it
out. So this module asks the questions the engine can be asked before
anything is at stake, and the browser says plainly which of the three
things a call needs are missing on this machine and what would put
them back. It fixes nothing: a codec and a capture backend are
compile-time decisions and no setting, flag or script here can add
them. Saying so is the feature.

A sibling module like theme_web.py and phone.py, loaded the same safe
way. Nothing here touches the network, and nothing here holds a Qt
object: it reads the engine's own library off the disk and a couple of
environment variables, so it can be tested on its own.
"""

import os
import sys
from pathlib import Path

#: the markers looked for in the engine's library. Chromium names its
#: capture backends and its portal interfaces in plain strings, so
#: their presence is the honest answer to "was this built with it" --
#: far more honest than a version number, because a distro can patch
#: either in or out and keep the version.
MARKERS = {
    "pipewire": (b"pipewire", b"PipeWire"),
    "portal": (b"org.freedesktop.portal.ScreenCast",),
}

#: read in pieces, with an overlap, because the library is 200 MB and
#: reading all of it into memory to answer one question is not
#: something a browser should do while he is using it.
CHUNK = 4 << 20

_CACHE = None


def mac_images(lister=None):
    """Every library this process has loaded, on macOS.

    There is no /proc there, and dyld keeps the list instead: the two
    calls are _dyld_image_count() and _dyld_get_image_name(i), both in
    libSystem, which is already in this process. That is the same
    answer /proc/self/maps gives on Linux -- what really got loaded,
    not what is installed -- and it is the answer this module needs,
    because "which engine build is this" is the whole question.

    `lister` is for the suite, which has no dyld."""
    if lister is not None:
        return list(lister())
    try:
        import ctypes
        libc = ctypes.CDLL(None)
        libc._dyld_image_count.restype = ctypes.c_uint32
        libc._dyld_get_image_name.restype = ctypes.c_char_p
        libc._dyld_get_image_name.argtypes = [ctypes.c_uint32]
        return [libc._dyld_get_image_name(i).decode("utf-8", "replace")
                for i in range(libc._dyld_image_count())]
    except Exception:        # pragma: no cover - not macOS
        return []


def mac_screen_recording(check=None):
    """May this application record the screen? True, False, or None for
    "could not be read".

    The reason this is asked at all: macOS does not refuse a share it
    has not been permitted. getDisplayMedia hands the page a picture of
    the desktop picture with no windows on it -- which looks like a
    working screen share until the other side says they cannot see
    anything. There is no Info.plist key for it and no way for an app
    to prompt; it is ticked in System Settings or it is not.

    CGPreflightScreenCaptureAccess asks without prompting, which is
    what this module wants: it reports, it does not demand. `check` is
    for the suite, which has no CoreGraphics."""
    if check is not None:
        return check()
    try:
        import ctypes
        cg = ctypes.cdll.LoadLibrary(
            "/System/Library/Frameworks/CoreGraphics.framework/CoreGraphics")
        fn = cg.CGPreflightScreenCaptureAccess
        fn.restype = ctypes.c_bool
        fn.argtypes = []
        return bool(fn())
    except Exception:        # pragma: no cover - not macOS, or too old
        return None


def engine_lib(images=None):
    """The QtWebEngineCore this process actually loaded.

    Off the process map rather than off a guess at an install path:
    the browser may be running against a pip wheel, a distro package
    or something he built, and which one it is is exactly the question.
    Two ways of asking the same thing, because the two platforms keep
    the list in different places (see mac_images)."""
    if sys.platform == "darwin" or images is not None:
        for name in (mac_images() if images is None else images):
            # the framework's binary, QtWebEngineCore.framework/...
            if "QtWebEngineCore" in name:
                return Path(name)
        return None
    try:
        text = Path("/proc/self/maps").read_text()
    except OSError:          # not Linux, or no procfs
        return None
    for line in text.splitlines():
        at = line.find("libQt6WebEngineCore.so")
        if at >= 0:
            return Path(line[line.rfind(" ", 0, at) + 1:].strip())
    return None


def scan(path, needles, chunk=CHUNK):
    """Which of these byte strings are in that file.

    Chunked, with an overlap as long as the longest needle so a marker
    lying across a chunk boundary is still found, and it stops as soon
    as every needle has been seen."""
    found = set()
    wanted = [n for n in needles if n]
    if not wanted:
        return found
    over = max(len(n) for n in wanted) - 1
    try:
        with open(str(path), "rb") as fh:
            tail = b""
            while True:
                block = fh.read(chunk)
                if not block:
                    break
                blob = tail + block
                for needle in wanted:
                    if needle in blob:
                        found.add(needle)
                if len(found) == len(wanted):
                    break
                tail = blob[-over:] if over > 0 else b""
    except OSError:
        return found
    return found


def engine_facts(lib=None):
    """What the engine was built with, cached for the run.

    Nothing here changes without a new engine, and a new engine means a
    restart, so the file is read once."""
    global _CACHE
    if _CACHE is not None and lib is None:
        return dict(_CACHE)
    path = Path(lib) if lib is not None else engine_lib()
    out = {"lib": str(path) if path else "", "wheel": False,
           "pipewire": False, "portal": False}
    if path:
        out["wheel"] = "site-packages" in str(path)
    if path and sys.platform != "darwin":
        # Both markers are Linux desktop things. Reading two hundred
        # megabytes of a Mach-O to find out it contains neither is half
        # a second spent answering a question nobody asked: on macOS
        # the screen-sharing answer is a permission, not a build
        # (mac_screen_recording), and that is what verdicts() asks.
        needles = [n for group in MARKERS.values() for n in group]
        found = scan(path, needles)
        out["pipewire"] = any(n in found for n in MARKERS["pipewire"])
        out["portal"] = any(n in found for n in MARKERS["portal"])
    if lib is None:
        _CACHE = dict(out)
    return out


def session():
    """Wayland or X11, as the engine will see it.

    This is half the screen-sharing answer: an engine with only the
    X11 capture path compiled in can offer the windows XWayland knows
    about and nothing else, which on Hyprland is close to nothing."""
    if sys.platform == "darwin":
        # one window server, not optional, and nothing in the
        # environment to ask about it
        return "quartz"
    kind = os.environ.get("XDG_SESSION_TYPE", "")
    if os.environ.get("WAYLAND_DISPLAY"):
        kind = "wayland"
    elif not kind and os.environ.get("DISPLAY"):
        kind = "x11"
    return kind or "unknown"


def verdicts(page, facts=None, kind=None, screen=None):
    """What a call will and will not do here, as a list of findings.

    `page` is what the page itself answered (see mictest.html: whether
    getDisplayMedia exists, whether H.264 can be sent and received,
    whether an H.264 video and AAC audio can be played). Everything
    else comes from the engine's library and the session. Each finding
    is a level, the name of a UI string, and whatever belongs in it --
    the words live in the browser's own string tables so they are in
    his language, and this stays a function over dictionaries that a
    test can hold to its answers."""
    page = page if isinstance(page, dict) else {}
    facts = engine_facts() if facts is None else facts
    kind = session() if kind is None else kind
    # `screen` is the macOS permission, passed in by the suite; asked of
    # the system only when the branch that needs it is really taken
    out = []
    h264 = bool(page.get("h264send")) and bool(page.get("h264recv"))
    if h264:
        out.append(("ok", "callH264Ok", ""))
    else:
        # the big one. Teams will not carry video at all without it,
        # and a Discord call drops to VP8, which it can do -- so this
        # is bad news for one and a shrug for the other.
        out.append(("bad", "callNoH264",
                    "send" if page.get("h264recv") else ""))
    if not page.get("displayMedia"):
        out.append(("bad", "callNoDisplayMedia", ""))
    elif kind == "quartz":
        # not a build question there: the engine can capture, and
        # whether it is allowed to is a tick box in System Settings
        allowed = mac_screen_recording() if screen is None else screen
        if allowed is False:
            out.append(("bad", "callNoScreenPerm", ""))
        elif allowed is None:
            out.append(("warn", "callScreenUnknown", ""))
        else:
            out.append(("ok", "callShareOk", ""))
    elif kind == "wayland" and not (facts.get("pipewire")
                                    or facts.get("portal")):
        # an engine with no PipeWire and no ScreenCast portal on a
        # Wayland session: the picker comes up, and what it hands over
        # is whatever X11 can still see
        out.append(("bad", "callNoPipewire", ""))
    else:
        out.append(("ok", "callShareOk", ""))
    if not page.get("playH264") or not page.get("playAac"):
        out.append(("warn", "callNoMp4", ""))
    if facts.get("wheel") and not h264:
        # where the codecs would come from. Said as a fact, not run:
        # this module installs nothing.
        out.append(("note", "callWheelHint", ""))
    return out
