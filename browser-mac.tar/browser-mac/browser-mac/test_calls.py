#!/usr/bin/env python3
"""Why a call will or will not work here, said before the call.

Discord and Teams in a tab can fail for a reason no setting in this
browser can reach: the web engine's own build. The patented codecs are
left out of Qt's WebEngine, and the wheel this browser runs on has no
PipeWire capture either -- so Teams gets a call with no video and a
Wayland session gets a black screen share. calls.py asks the engine
those questions up front and the microphone-and-camera page says the
answer in plain words.

This holds the asking to its answers. The scanner is *calibrated* here
rather than trusted: a planted marker must be found, an absent one must
not be, and one lying across a chunk boundary must still be found --
otherwise "this engine has no PipeWire" would be a sentence the
browser says about every engine.

Offscreen, scratch data. Nothing here opens a page off this machine
and nothing is installed.
"""
import json
import os
import sys
import tempfile
from pathlib import Path

os.environ["QT_QPA_PLATFORM"] = "offscreen"
os.environ["BROWSER_NO_LIB_CHECK"] = "1"
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE / "tests"))

import harness as H  # noqa: E402
B = H.boot()
import calls  # noqa: E402

fails = []


def check(what, ok, detail=""):
    print(("  ok   " if ok else "  FAIL ") + what
          + (("  <" + str(detail) + ">") if detail != "" else ""))
    if not ok:
        fails.append(what)


print("=== the scanner, calibrated ===")
tmp = Path(tempfile.mkdtemp(prefix="callcheck-"))
planted = tmp / "with.so"
planted.write_bytes(b"\x00" * 300 + b"pipewire" + b"\x01" * 200
                    + b"org.freedesktop.portal.ScreenCast" + b"\x02" * 100)
bare = tmp / "without.so"
bare.write_bytes(b"\x03" * 4096)
split = tmp / "split.so"
split.write_bytes(b"a" * 30 + b"pipewire" + b"b" * 30)
check("a planted marker is found",
      calls.scan(planted, [b"pipewire"]) == {b"pipewire"})
check("an absent one is not", calls.scan(bare, [b"pipewire"]) == set())
check("one lying across a chunk boundary is still found",
      calls.scan(split, [b"pipewire"], chunk=32) == {b"pipewire"})
check("a file that is not there is no marker and no crash",
      calls.scan(tmp / "nope.so", [b"pipewire"]) == set())
facts = calls.engine_facts(lib=planted)
check("an engine with both reads as having both",
      (facts["pipewire"], facts["portal"]) == (True, True), facts)
facts = calls.engine_facts(lib=bare)
check("...and one with neither as having neither",
      (facts["pipewire"], facts["portal"]) == (False, False), facts)
check("the library it names is the one it read", facts["lib"] == str(bare))

print()
print("=== this engine, as it really is ===")
real = calls.engine_facts()
check("the loaded engine was found",
      "libQt6WebEngineCore" in real["lib"], real["lib"])
check("asking twice is free (it is cached)",
      calls.engine_facts() == real)
# measurements, not demands: a freeworld or self-built engine would
# answer differently and must not fail this suite for it
print("       this engine: %s" % real["lib"])
print("       from a wheel: %s   PipeWire: %s   ScreenCast portal: %s"
      % (real["wheel"], real["pipewire"], real["portal"]))

print()
print("=== which session the engine will see ===")
keep = {k: os.environ.get(k) for k in ("WAYLAND_DISPLAY", "XDG_SESSION_TYPE",
                                       "DISPLAY")}
try:
    for k in keep:
        os.environ.pop(k, None)
    check("with nothing set it says so", calls.session() == "unknown")
    os.environ["DISPLAY"] = ":0"
    check("a DISPLAY alone is X11", calls.session() == "x11")
    os.environ["XDG_SESSION_TYPE"] = "x11"
    check("...and it stays X11", calls.session() == "x11")
    os.environ["WAYLAND_DISPLAY"] = "wayland-1"
    check("a WAYLAND_DISPLAY wins over both", calls.session() == "wayland")
finally:
    for k, v in keep.items():
        if v is None:
            os.environ.pop(k, None)
        else:
            os.environ[k] = v

print()
print("=== what it concludes ===")
HAVE = {"wheel": False, "pipewire": True, "portal": True}
NONE = {"wheel": True, "pipewire": False, "portal": False}
GOOD_PAGE = {"displayMedia": True, "h264send": True, "h264recv": True,
             "playH264": "probably", "playAac": "probably"}
BARE_PAGE = {"displayMedia": True, "h264send": False, "h264recv": False,
             "playH264": "", "playAac": ""}


def keys(page, facts, kind):
    return [key for _level, key, _detail in calls.verdicts(page, facts, kind)]


check("a full engine on Wayland is good news both ways",
      keys(GOOD_PAGE, HAVE, "wayland") == ["callH264Ok", "callShareOk"],
      keys(GOOD_PAGE, HAVE, "wayland"))
got = keys(BARE_PAGE, NONE, "wayland")
check("no H.264 is named as missing", "callNoH264" in got, got)
check("no PipeWire on Wayland is named as missing",
      "callNoPipewire" in got, got)
check("...and the mp4 files are mentioned too", "callNoMp4" in got, got)
check("...and where the codecs would come from",
      "callWheelHint" in got, got)
check("the same engine on X11 does not blame PipeWire",
      "callNoPipewire" not in keys(BARE_PAGE, NONE, "x11"),
      keys(BARE_PAGE, NONE, "x11"))
check("an engine that knows the portal is fine on Wayland",
      "callNoPipewire" not in keys(BARE_PAGE,
                                   {"wheel": True, "pipewire": False,
                                    "portal": True}, "wayland"))
no_share = dict(GOOD_PAGE, displayMedia=False)
check("a page that cannot even ask is said so",
      "callNoDisplayMedia" in keys(no_share, HAVE, "wayland"),
      keys(no_share, HAVE, "wayland"))
check("good news is never dressed as bad",
      [lvl for lvl, _k, _d in calls.verdicts(GOOD_PAGE, HAVE, "x11")]
      == ["ok", "ok"])
check("bad news is never dressed as good",
      "ok" not in [lvl for lvl, _k, _d
                   in calls.verdicts(BARE_PAGE, NONE, "wayland")])
check("rubbish in is not a crash",
      isinstance(calls.verdicts(None, NONE, "wayland"), list))

print()
print("=== the browser's side ===")
app = H.app()
win = B.Browser()
win.resize(900, 700)
H.spin(200)
bridge = B.Bridge(win)
answer = json.loads(bridge.callCheck())
check("the page can ask the browser", isinstance(answer, dict), answer)
for key in ("lib", "wheel", "pipewire", "portal", "session"):
    check("...and is told “%s”" % key, key in answer, sorted(answer))
check("the answer matches the module",
      (answer["pipewire"], answer["portal"])
      == (real["pipewire"], real["portal"]))
check("nothing about the machine beyond the engine is handed over",
      set(answer) == {"lib", "wheel", "pipewire", "portal", "session"},
      sorted(answer))
# the verdict is reasoned once, in the module, and handed to the page
# already in his language -- so the page cannot hold a second, stale
# copy of the reasoning
win.config["translateLang"] = "en"
rows = json.loads(bridge.callVerdicts(json.dumps(BARE_PAGE)))
check("the page is handed finished lines", len(rows) >= 2, rows)
check("...each with a level, a name and words",
      all(set(row) == {"level", "key", "text", "detail"} for row in rows),
      rows)
check("...and the words are really words, not the key again",
      all(row["text"] and row["text"] != row["key"] for row in rows),
      [row["key"] for row in rows if row["text"] == row["key"]])
check("the no-H.264 line is among them",
      "callNoH264" in [row["key"] for row in rows])
win.config["translateLang"] = "de"
german = json.loads(bridge.callVerdicts(json.dumps(BARE_PAGE)))
check("and they come back in German when he asks in German",
      all(a["text"] != b["text"] for a, b in zip(rows, german)),
      [a["key"] for a, b in zip(rows, german) if a["text"] == b["text"]])
win.config["translateLang"] = "en"
check("rubbish from a page is an empty answer, not a crash",
      json.loads(bridge.callVerdicts("not json")) != [None])

print()
print("=== the words and the page ===")
need = ("callTitle", "callRun", "callChecking", "callH264Ok", "callNoH264",
        "callNoDisplayMedia", "callNoPipewire", "callShareOk", "callNoMp4",
        "callWheelHint", "callEngine", "callSession")
missing_en = [k for k in need if not B.UI_STRINGS["en"].get(k)]
missing_de = [k for k in need if not B.UI_STRINGS["de"].get(k)]
check("every new word has an English", missing_en == [], missing_en)
check("...and a German", missing_de == [], missing_de)
same = [k for k in need
        if B.UI_STRINGS["en"].get(k) == B.UI_STRINGS["de"].get(k)]
check("and they are really translated", same == [], same)
page = (HERE / "mictest.html").read_text()
for one in ("callpanel", "callrun", "callout"):
    check("“%s” is on the page" % one, 'id="%s"' % one in page)
check("the page asks the browser for the engine's half",
      "callCheck" in page)
check("the page asks the engine what it can send",
      "getCapabilities" in page)
check("the page asks the browser for the finished verdict",
      "callVerdicts" in page)
check("...and does not reason about it a second time itself",
      "pipewire" not in page.lower())
check("every verdict the module can give has words in both languages",
      all(B.UI_STRINGS["en"].get(key) and B.UI_STRINGS["de"].get(key)
          for key in ("callH264Ok", "callNoH264", "callNoPipewire",
                      "callShareOk", "callNoMp4", "callWheelHint",
                      "callNoDisplayMedia")))

print()
print("=== the panel, really drawn in a real page ===")
# the page is where this feature is seen, and a syntax error in its
# script would leave every check above green and the panel dead. So it
# is loaded for real and clicked for real.
view = win.open_mic_test()
H.wait_for(lambda: "mictest.html" in view.url().toString(), timeout=8000)
H.wait_for(lambda: H.js(view, "!!document.getElementById('callrun')")
           is True, timeout=8000)
check("the panel is on the page",
      H.js(view, "!!document.getElementById('callpanel')") is True)
H.wait_for(lambda: H.js(
    view, "document.getElementById('callrun').textContent")
    not in ("", None), timeout=8000)
label = H.js(view, "document.getElementById('callrun').textContent")
check("its button says what it does, in his language",
      label in (B.UI_STRINGS["en"]["callRun"], B.UI_STRINGS["de"]["callRun"]),
      label)
title = H.js(view, "document.getElementById('t_callTitle').textContent")
check("...and so does its heading",
      title in (B.UI_STRINGS["en"]["callTitle"],
                B.UI_STRINGS["de"]["callTitle"]), title)
H.js(view, "document.getElementById('callrun').click()")
H.wait_for(lambda: H.js(
    view, "document.getElementById('callout').children.length") or 0, 8000)
lines = H.js(view, "document.getElementById('callout').innerText") or ""
check("clicking it says something", len(lines.strip()) > 10, lines[:120])
check("...and the engine's own answer is in there",
      "VP8" in lines or "video/" in lines or "—" in lines, lines[:200])
# on this engine the H.264 line is the one that matters, and it must be
# the real sentence rather than a key or a blank
for lang in ("en", "de"):
    word = B.UI_STRINGS[lang]["callNoH264"].split(".")[0]
    if word in lines:
        check("the no-H.264 line reached the page (%s)" % lang, True)
        break
else:
    check("the no-H.264 line reached the page", "H.264" in lines, lines[:200])
check("no script error left the page half built",
      H.js(view, "document.getElementById('callout').children.length") >= 2,
      H.js(view, "document.getElementById('callout').innerHTML")[:200])

print()
if fails:
    print("FAILED %d" % len(fails))
    for row in fails:
        print("  - " + row)
    sys.exit(1)
print("all good")
