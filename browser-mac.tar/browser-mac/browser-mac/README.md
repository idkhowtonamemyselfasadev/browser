# browser — the macOS edition

A dark, keyboard-driven web browser built on Chromium. One readable Python
file, Qt WebEngine underneath, pitch black with Catppuccin Mocha text —
sharp corners, thin outlines, no clutter. Even Google is black.

**This is the Mac edition.** It is generated from the Linux one at
[idkhowtonamemyselfasadev/browser](https://github.com/idkhowtonamemyselfasadev/browser)
by `tools/mac_port.py`, so every feature is written there and arrives
here. What this edition is on its own — the application bundle, the
Notification Center, `caffeinate`, `say`, `open`, where your data lives —
is in `CHANGELOG.md`, and what nobody has been able to try on a real Mac
yet is in `PORT.md`.

![Start page](screenshots/start-page.png)

## Design principles

**Real web compatibility.** Chromium rendering through Qt WebEngine, with
persistent cookies and logins. Sites behave as they do everywhere else.

**Everything in one file.** The whole application is a single `browser.py`
you can read end to end. No build step, no plugin framework, no dependency
tree to audit.

**Dark by default, not by filter.** Sites that ship a dark theme are asked
for it. Light-only sites are darkened automatically. Sites that are already
dark are left alone, which keeps heavy pages fast.

**One palette drives everything.** A theme recolours the window, the tabs,
the menus and every page the browser brings with it — from one table of
colours, applied without a restart. It never touches a website.

**Nothing leaves the machine that you did not ask for.** No telemetry, no
account, no sync. Browsing data stays in `~/Library/Application Support/browser/`.

## Features

### Browsing

- **Tabs and tab groups** — Chrome-style group pills, collapsible, colour-coded
- **A side panel** (`Ctrl+Shift+Y`) that holds any site beside the page —
  Discord, Amazon Music, Claude, Twitch chat — as a real view on the same
  cookie jar, so it is already logged in
- **Game mode** (`Ctrl+Alt+G`) — every other tab asleep, everything muted,
  notification requests refused; again to wake exactly those tabs
- **Reader mode** (`Ctrl+Alt+R`), **link hints** (`Ctrl+Alt+K`), **read
  aloud** (`Ctrl+Alt+V`) and highlights that come back on the next visit
- **Screenshots** (`Ctrl+Shift+S`, whole page with `Ctrl+Alt+Shift+S`) with
  password fields blurred before the shutter
- **Minecraft server status** (`Ctrl+Alt+J`) — your servers, asked the same
  question the game's own server list asks
- **A command palette** (`Ctrl+Shift+K`) and a **cheat sheet** (`Ctrl+/`);
  every shortcut can be changed in Settings
- **Virtual browsers** — several independent sessions in one window, each with
  its own cookie jar and logins; sign in to the same site twice without
  signing out
- **The address bar answers questions** — `12*64+3`, `5 in to mm`, `200 c to f`,
  `4 gib to mb`, `time in tokyo`, `kw`, `days until 24.12.`, `#ff8800` — all
  worked out on this computer, with nothing sent anywhere. Enter copies the answer
- **Search keywords** — `yt cats`, `mr sodium`, `gh repo`, `amz ssd`, `w term`;
  your own in Settings as any URL with a `%s` in it
- **Suggestions from your own browser** — an open tab (Enter switches to it), a
  bookmark, or a page from your history matched on words in any order; an empty
  bar offers a link you just copied and your last searches
- **Copy clean address** — the same link without `utm_*`, `fbclid` and the rest
  of the tracking, also as a Markdown or HTML link, or "Title — address"
- **Find in page** (`Ctrl+F`) — match count, next/previous, match case
- **Save any image** — right-click → *Save image* works on whatever is drawn
  under the cursor: a picture under an overlay, a CSS background, a canvas,
  an inline SVG. `Shift` + right-click brings the menu up on sites that
  block it
- **Tab search** (`Ctrl+Shift+A`) — every open tab of every virtual browser in
  one filtered list
- **Reopen closed tab** (`Ctrl+Shift+T`) — restores its position and its group,
  and **Recently closed** in the tab menu lists the last 25, not only the last
- **The tab's own menu** — pin (it shrinks to its icon, keeps its place across
  restarts and can be held to its own site), mute (also `Ctrl+M`) or "play
  sound only here", lock so it asks before closing, rename it so the page
  cannot change the title, duplicate it (`Ctrl+Shift+D`), open it in another
  virtual browser or in a private tab, copy the addresses of one tab or of all
  of them (plain or Markdown), open every address in the clipboard, bookmark
  every tab into one folder, sort the tabs by site or title, group or close
  every tab of this site, close the others / to the right / to the left /
  the duplicates
- **Account chooser** (`Ctrl+Shift+M`, or the `@` in the address bar) — two
  accounts saved for a site means nothing is filled in until you say which
  one. The list of accounts is a panel of the browser's own; the page never
  sees it, and never learns what is on it
- **Private tab** (`Ctrl+Shift+N`) — an off-the-record tab that leaves nothing
  behind: no history, no saved password and none offered, no download record,
  no favicon kept, and no cookies or site storage once the last one closes.
  It is never saved as a tab and never comes back at the next start. Two
  private tabs share one place; a normal tab sees none of it
- **Page zoom from the keyboard** — `Ctrl` `+` / `Ctrl+-` / `Ctrl+0`, and
  `Ctrl`+wheel. Per tab, from 25% to 500%; `Ctrl+0` returns to the level in
  Settings. The browser's own pages are not zoomed a tab at a time — they
  follow the Page zoom slider, the way they always have
- **Favourites** (`Ctrl+Shift+F`, or the folder in the toolbar) — the whole
  bookmark collection in one panel, the way Edge's Favourites button works: a
  search box at the top and one list underneath, folders opening in place
  rather than flying out sideways as submenus. Folders go inside folders as
  deep as you like; a new one is named where you make it, renaming happens in
  the row itself, and every row carries its own `⋯` so nothing is hidden
  behind a right-click. Drag a row into a folder, out of one, or between two
  to reorder it — or use **Move to folder** on the `⋯` if dragging is not
  your friend. The bookmarks bar is off unless you ask for it
  (`Ctrl+Shift+B`); the bookmark manager is `Ctrl+Shift+O`
- **Smart address bar** — URLs, search, and live suggestions in one field
- **Fullscreen video**, background tabs, sleeping tabs restored on demand
- **A toolbar you pick** — right-click the row at the top, or Settings →
  Toolbar, to choose which buttons are up there and what order they come in.
  Back, forward, reload and the address bar stay; everything else is yours,
  and eight more buttons that were only ever keyboard shortcuts can join
  them. Taking a button away never touches its shortcut.

### Downloads and printing

- **Download manager** — a downloads page and a toolbar bar with progress,
  speed and time remaining; pause, resume, cancel; history that survives
  restarts
- **Print or save as PDF** (`Ctrl+P`) — the PDF lands in the downloads list
  alongside everything else

### Privacy and security

- **Vault Password** — the built-in password manager. Optional: setup asks
  whether you want it, and Settings → Plugins switches it on or off at any
  time. Off means off — the login watcher is never put into a page, so no
  form is looked at and nothing is ever written to the vault. Switching it
  off deletes nothing; your saved logins are still there when you switch it
  back on. When it is on it offers to save logins and fills them back in on
  a real click, and the saved password is withheld from page scripts until
  you actually interact with the form, so an injected script reads an empty
  field.
- **Per-site proxy routing** — send chosen sites through a proxy while
  everything else goes direct, or the reverse. Rules are enforced by a
  built-in local proxy and fail closed: a rule pointing at a dead proxy
  blocks the site rather than quietly going direct.
- **Site permissions** — microphone, camera and notification requests are
  asked per origin and remembered per origin, scheme and port.
- **History control** — pause it, search it, or clear it
- **Trust boundary** — the browser's own pages get a privileged bridge to the
  application; websites never do, and cannot reach it through the underlying
  channel

### Setup and configuration

- **Setup** — a seven-step first run: language, search engine, start page,
  site behaviour, privacy, quick links, summary. Re-runnable at any time.
- **Settings** — opens as a pane over the window rather than a page you
  navigate to, so it costs no tab and no history entry
- **Start page** — clock, search, editable quick links, background images
  (bundled or your own)
- **Userscripts** — Greasemonkey-style `*.user.js` files, per profile
- **Themes** — 115 of them (Settings → Theme), grouped Dark / Light / With
  character, searchable, each shown as a swatch of its own colours and
  applied on the spot. Most are credited palettes (Catppuccin, Gruvbox,
  Nord, Dracula, Solarized, Tokyo Night, Everforest, Rosé Pine, Kanagawa,
  Monokai, Ayu, Material, Oxocarbon, Nightfox, GitHub, VS Code…); a few
  bring a face and a texture of their own — Steampunk, Terminal Green,
  Amber CRT, Blueprint, Newspaper, Game Boy, Frutiger Aero. The default is
  unchanged.
- **Looks** (Settings → Look) — a theme is what colour the browser is; a
  look is what shape it is. Four of them, and every one works with every
  one of the 115 palettes, because a look owns geometry and never a
  colour:
  - **Classic** — the browser as it is drawn. The default, and nothing
    about it changes when the others exist.
  - **Taskbar** — a strip along the bottom with a start button, your
    pinned sites and a clock. The start button opens a search box over a
    grid of the pins.
  - **Dock** — a floating, rounded dock over the page with icon
    magnification, roomier and rounder chrome throughout, and a
    now-playing widget whose play, pause and skip work the transport of
    whatever page is making the sound.
  - **Circle** — the start page becomes a ring: the search box in the
    middle, the quick links orbiting it, the mouse wheel turning them.
    The caret still lands in the search box.

  **Pinned sites are the start page's quick links** — one list, not two.
  Pin from any page's right-click menu, from the `+` on the taskbar, or by
  adding a quick link on the start page; whichever you use, the other
  places show it at once. Clicking a pin brings its tab forward if it is
  already open instead of opening a second one.
- **Interface translations** — the UI follows the language you choose
- **Single instance** — links from other applications open as tabs in the
  running window; works as the system default browser
- **Built-in updates** — pulls the newest version from this repository

## Screenshots

![Automatic dark mode](screenshots/dark-mode.png)

*Wikipedia has no dark theme of its own — the browser darkens it. A site
that serves its own dark theme is left alone.*

| Favourites | Dragging one in |
|---|---|
| ![Favourites](screenshots/favorites-panel.png) | ![Dragging](screenshots/favorites-drag-into.png) |

*The folder in the toolbar opens the lot. Folders open where they are, the
box at the top narrows the list as you type, and a row dropped on a folder
goes into it — the box says so; a line between two rows would mean the
order instead.*

## Install

```sh
git clone https://github.com/idkhowtonamemyselfasadev/browser-mac.git
cd browser-mac
python3 -m pip install PyQt6 PyQt6-WebEngine
sh install-mac.sh
```

That builds `browser.app` in `~/Applications`. `--system` puts it in
`/Applications` instead and asks for your password; `--dry-run` prints
what it would do and writes nothing.

**Open it once from Finder with right-click → Open.** It is not
notarised, so a plain double-click is refused with no reason given —
once you have opened it that way, it opens normally from then on.

Two things macOS will not let the browser ask you for itself:

* **Default browser**: System Settings → Desktop & Dock → Default web
  browser.
* **Screen sharing in a call**: System Settings → Privacy & Security →
  Screen Recording, with *browser* ticked. There is no way for an app to
  prompt for that one, so nothing in the browser will.

The camera and the microphone *are* asked for the normal way, the first
time a page wants them.

To try it without building a bundle:

```sh
python3 browser.py
```

Started that way it is a plain Python program: no Dock icon of its own,
and it cannot be the default browser. Everything else works.

Requirements: macOS 12 or newer (Qt 6.8 and up will not launch below
that), Python 3 and PyQt6 WebEngine. Apple silicon and Intel both.

## Keyboard shortcuts

Shortcuts are handled by the browser itself, so they behave the same on any
desktop or window manager with no system configuration.

**On a Mac, read every `Ctrl` below as `⌘`.** Qt maps it to Command, which
is what the shortcuts for the same things are in every other Mac
application — so `Ctrl+T` in this table is ⌘T on the keyboard. Where a
shortcut really does mean the Control key, it says `Meta`.

| Key | Action |
|-----|--------|
| `Ctrl+T` | New tab |
| `Ctrl+Shift+N` | New private tab |
| `Ctrl+W` | Close tab (a pinned tab stays) |
| `Ctrl+Shift+T` | Reopen closed tab |
| `Ctrl+Shift+D` | Duplicate tab |
| `Ctrl+Shift+K` | Command palette — every action by name |
| `Ctrl+Shift+Y` | Side panel — any site beside the page |
| `Ctrl+Shift+Esc` | What the tabs are costing |
| `Ctrl+Alt+U` | Your own CSS for this site |
| `Ctrl+Alt+G` | Game mode |
| `Ctrl+Alt+J` | Minecraft server status |
| `Ctrl+Alt+Q` / `Ctrl+Alt+Y` | Discord mute / deafen |
| `Ctrl+Alt+R` | Reader mode |
| `Ctrl+Alt+K` | Link hints — a letter on every link |
| `Ctrl+Alt+V` | Read the selection aloud |
| `Ctrl+/` | The keyboard shortcuts, on one page |
| `Ctrl+Shift+S` | Screenshot of what is on screen |
| `Ctrl+Alt+P` | Panic: mute everything, blank every tab, lock the vault |
| `Ctrl+Alt+H` | Streamer mode: hide the address bar's text |
| `Ctrl+Alt+Shift+S` | Screenshot of the whole page |
| `Ctrl+Alt+Space` / `Ctrl+Alt+←→` | Play/pause / seek the page's video |
| `Ctrl+Shift+Space` | Pause every playing tab (again: resume) |
| Middle-click Back / Forward | That step, in a new tab |
| Hold Back / Forward | That tab's history, several steps at once |
| `Ctrl+M` | Mute / unmute this tab |
| `Ctrl+1` … `Ctrl+8` / `Ctrl+9` | Go to that tab / the last tab |
| `Ctrl+Shift+PgUp` / `PgDn` | Move this tab along the strip |
| `Ctrl+L` | Focus address bar |
| `Ctrl+K` | Address bar, ready for a search |
| `Alt+Enter` (in the bar) | Open what you typed in a new tab |
| `Ctrl+Enter` / `Ctrl+Shift+Enter` | Finish the name with `.com` / `.de` |
| `Shift+Delete` (in the bar) | Forget that suggestion |
| `Ctrl+F` | Find in page |
| `Ctrl+P` | Print or save as PDF |
| `Ctrl+Shift+A` | Search open tabs |
| `Ctrl+Tab` / `Ctrl+Shift+Tab` | Next / previous tab |
| `Shift+Tab` | Next virtual browser |
| `Ctrl+R` / `F5` | Reload |
| `Ctrl+H` | History |
| `Ctrl+J` | Downloads |
| `Ctrl+Shift+F` | Favourites — the whole bookmark tree in one panel |
| `Ctrl+Shift+O` | Bookmarks |
| `Ctrl+Shift+P` | Passwords (with Vault Password installed) |
| `Ctrl+Shift+G` | Copy a fresh password to the clipboard |
| `Ctrl+Shift+M` | Choose which saved account signs in here |
| `Ctrl+,` | Settings |
| `Ctrl+` `+` / `Ctrl+-` | Zoom the page in / out (also `Ctrl`+wheel) |
| `Ctrl+0` | Back to the zoom set in Settings |
| `F11` | Fullscreen |
| `F12` / `Ctrl+Shift+I` | Developer tools |
| `Ctrl+Q` | Quit |

Settings, History, Downloads, Bookmarks and Passwords are panes, not
tabs: they open over whatever you were looking at, `Esc` (or pressing
the same key again) closes them, and you are back on the page you came
from. They never appear in the tab strip or the address bar, and they
are never reopened as tabs when the browser starts.

## Configuration

Most settings live in the settings pane (`⌘,`), stored in
`~/Library/Application Support/browser/config.json`. The sources are short and meant to be
edited for anything beyond that:

| Path | Contents |
|------|----------|
| `browser.py` | Application code. Interface colours are in the `STYLE` string; sites that skip auto-darkening are listed in `NATIVE_DARK_SITES`. |
| `start.html` | Start page and first-run setup. |
| `settings.html` | Settings pane. |
| `history.html`, `downloads.html`, `bookmarks.html`, `passwords.html` | The other four panes. |
| `backgrounds/` | Bundled background images. |

The theme is pitch black (`#000000`) with
[Catppuccin Mocha](https://catppuccin.com/palette/) text colours.

User data — history, settings, saved logins, downloads and cookies — is
stored under `~/Library/Application Support/browser/`. Saved passwords are obfuscated with a
per-install key file; the security boundary is your operating system account,
not a master password.

## Driving the browser from a script (agent bridge)

The browser is also an automation target: while it runs it listens on a
second local socket, `$TMPDIR/browser-agent` — on a Mac `$TMPDIR` is
already a folder of your own, inside `/var/folders`, so the socket is not
somewhere another account could reach — and
`agent.py` is the terminal client. A script can open a background tab,
read a page, click, type, wait for a node and take a screenshot — all on
tabs that are not the visible one, without the window ever coming to the
front. It exists so an assistant on this machine (Claude Code) can look
things up and ask other sites questions without borrowing the screen.

```
python3 agent.py tabs                      # what is open
python3 agent.py open https://example.org  # background tab; prints its id
python3 agent.py text --tab 7              # the page as text
python3 agent.py click 'button.go' --tab 7
python3 agent.py type '#q' hello --enter --tab 7
python3 agent.py shot /tmp/page.png --tab 7
python3 agent.py chatgpt 'three names for a frost sword'
```

The socket is a Unix socket owned by your user; nothing off the machine
can reach it. Switch it off with `"agentBridge": false` in `config.json`
or `BROWSER_NO_AGENT=1`. `test_agent.py` is its offscreen test.

## Taking a page off the phone

The Android edition has a menu entry that hands the page you are looking
at to this one — you find something on the sofa and read it at the desk.
Its half has worked for a while and had nowhere to send to, because the
agent bridge above is a local pipe and its http mirror is bound to
127.0.0.1: nothing a tablet in the next room can reach.

Settings → Network has the ear that was missing. It is **off**, and
switching it on is the only thing in this browser that opens a port:

- it answers `POST /open?url=…` (what the phone sends) and `GET /ping`,
  and 404s everything else — none of the agent bridge's ops can be
  reached through it;
- only `http` and `https` addresses are taken, so a `file://` or a
  `javascript:` URL arriving from the network is refused by its scheme;
- only your own network may ask: loopback and the private ranges, so a
  port forwarded by accident still gives the internet a 403;
- a website open in this browser cannot use it either — a page's own
  `fetch()` comes from 127.0.0.1, so a request carrying `Origin` or
  `Sec-Fetch-*` is refused, and the phone sends neither;
- twelve pages a minute, then 429;
- every arrival is a **background** tab and one line in the corner: the
  window never jumps because a phone in another room said so.

`"phoneDrop": true`, `"phoneDropPort": 8766` and an optional
`"phoneDropToken"` are the config keys. Change the port here and change
it on the phone too. `test_phone.py` is its offscreen test, and
`phone.py` holds every rule with the long version of why.

## Will a call work here?

Discord and Teams in a tab can fail for a reason no setting in this
browser can reach: the web engine's own build. Qt's WebEngine is
Chromium with the patented codecs left out, and the pip wheel is built
without PipeWire capture as well — so a Teams call carries no video at
all, and a Wayland session hands over a black rectangle. Nothing in the
page says so, and halfway through a call is the worst time to find out.

The microphone-and-camera page has a **Calls and sharing a screen**
panel that asks the engine up front and says in plain words which of
the things a call needs are missing on this machine, and where they
would come from. It fixes nothing — a codec and a capture backend are
decided when the engine is built, and no flag or script here can add
one. Saying so is the point. `calls.py`, `test_calls.py`.

## Security updates

Most of what could go wrong in a browser goes wrong in the engine, and the
engine here is Chromium inside Qt WebEngine. So GitHub keeps an eye on it
for you. Nothing runs on your machine and nothing is sent anywhere.

**On the first of every month** (GitHub cannot say "every five weeks", so
this is the closest it gets) a job runs and asks:

- which Chromium this browser is built on, and how far behind Google's
  current Chrome that is
- whether any Chrome holes *known to be used against people in the wild*
  are newer than that engine — the short list CISA publishes, not the
  thousands of theoretical ones
- whether a newer PyQt6 or PyQt6-WebEngine has been released
- whether the browser's own security checks still pass

**If there is nothing to do, it says nothing.** No issue, no mail. That is
the normal outcome and it is deliberate: a check that pings you every month
is a check you learn to ignore. The full report is always written to the
run's summary page under the repository's Actions tab if you want to read
it anyway.

**If there is something to do, it opens one issue** called "Browser
security check" and keeps editing that same one — it never piles up
duplicates. When the problem is gone it comments and closes the issue by
itself.

### What to do when an issue appears

Read the first section. It is written in the same plain language as this
page and it says which of these it is:

- **"PyQt6-WebEngine x.y.z is out"** — this is the one that matters. Update
  the browser's engine on your machine (`sudo dnf upgrade
  python3-pyqt6-webengine`, or whatever your distribution calls it) and
  merge the Dependabot pull request that bumps the pinned version here.
- **"The browser's own security checks are failing"** — something in a
  recent change broke a protection that was already fixed once. The issue
  names the check. Run `python3 .github/scripts/invariant_checks.py` to see
  it locally.
- **"N Chrome holes known to be exploited are newer than this engine"** —
  worth knowing, usually nothing to install. Qt ships its own Chromium
  snapshot and backports security fixes into it, so it is always a few
  versions behind Chrome by design. Take the next engine update promptly
  and that is the whole answer.

To see which engine your own machine is running:

```sh
python3 -c "from PyQt6.QtWebEngineCore import qWebEngineChromiumVersion as v; print(v())"
```

### The rest of it

**Dependabot** opens a pull request when PyQt6, PyQt6-WebEngine or one of
the workflow actions has a new release. Merging it is the update.

**Every pull request** runs the security checks, so a change that breaks
one cannot merge without a red cross. They also run by hand:

```sh
python3 .github/scripts/invariant_checks.py
```

They start a headless browser against a throwaway profile — your real
history, logins and settings are never touched — and check that a website
cannot reach the browser's internal bridge, that the download and bookmark
controls refuse a page that does not hold this run's key, that a saved
password stays out of the page until a real click, that permissions are
remembered per site *and* port, and that a site routed through a proxy that
is down gets blocked rather than quietly connected.

One catch worth knowing: **GitHub switches scheduled jobs off on a
repository that has had no activity for 60 days**, and mails you when it
does. Any push turns it back on, as does pressing "Run workflow" on the
Actions tab.

## The other two editions

The same browser, same features, generated from the same file:

* **Linux** — [idkhowtonamemyselfasadev/browser](https://github.com/idkhowtonamemyselfasadev/browser),
  which is where every feature is written.
* **Windows** — [idkhowtonamemyselfasadev/browser-windows](https://github.com/idkhowtonamemyselfasadev/browser-windows).

Bookmarks, history and settings are the same JSON files in all three, so
a profile folder copied from one to another is read by the next.

## Uninstall

Drag `browser.app` to the Trash, or:

```sh
rm -rf ~/Applications/browser.app        # or /Applications/browser.app
```

Browsing data in `~/Library/Application Support/browser/` and the Widevine
link in `~/Library/Caches/browser/` can be removed separately. Delete the
cloned repository to finish.
