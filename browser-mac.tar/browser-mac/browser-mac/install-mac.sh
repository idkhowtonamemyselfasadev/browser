#!/bin/sh
# Build browser.app out of this folder and put it where macOS looks.
#
# The Linux edition's install.sh writes a .desktop file; there is no
# such thing here. A Mac application is a folder with a fixed shape,
# and three things in that shape are not cosmetic:
#
#   * Contents/Info.plist says the app may ask for the camera and the
#     microphone. Without it the system does not refuse politely, it
#     kills the process the moment a page calls getUserMedia.
#   * Contents/Resources/icon.icns is the Dock icon. Qt can render the
#     .svg, at one size, and the Dock draws it soft.
#   * the executable is a short shell script, because the program is
#     python and the bundle has to name something it can exec -- and
#     it is where PYTHONPYCACHEPREFIX is set, which is not cosmetic
#     either (see "the bytecode" below).
#
# Two things this script refuses to do quietly:
#
#   * install against an x86_64 Python on an Apple Silicon Mac. A
#     Rosetta-translated Chromium is the single largest source of lag
#     available on that machine and it looks like a broken browser,
#     not like a wrong install.
#   * leave the bytecode cache somewhere the bundle cannot write.
#     browser.py is 3.2 MB; compiling it is ~470 ms of CPython (timed
#     on the Linux box this was built on) against ~11 ms to load the
#     cached form. A root-owned bundle in /Applications, or a
#     quarantined one Gatekeeper has translocated onto a read-only
#     image, cannot write __pycache__ beside the source -- so that
#     half second is paid on every single launch, for ever.
#
# Nothing here needs an administrator unless you ask for /Applications,
# and nothing is downloaded.
#
# Usage:
#   sh install-mac.sh                 -> ~/Applications/browser.app
#   sh install-mac.sh --system        -> /Applications/browser.app (sudo)
#   sh install-mac.sh --dry-run       -> say what it would do, do nothing
#   sh install-mac.sh --to <folder>   -> somewhere else
#   sh install-mac.sh --force         -> install even on a translated python
#
# --dry-run works on any machine on purpose: it is how the suite on the
# Linux box checks this script without a Mac (test_mac.py).

set -e
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
DEST="$HOME/Applications"
DRY=""
SUDO=""
FORCE=""

while [ $# -gt 0 ]; do
  case "$1" in
    --dry-run) DRY="yes" ;;
    --system)  DEST="/Applications"; SUDO="sudo" ;;
    --force)   FORCE="yes" ;;
    # --to needs a real folder, and the value has to be checked for
    # two different reasons -- both observed, neither theoretical:
    #
    #   `--to` as the last argument: the shift fails, set -e is on, so
    #   the script exits 1 having printed absolutely nothing. The user
    #   is told neither what was wrong nor that anything went wrong.
    #
    #   `--to --dry-run`: far worse, because it does not fail at all.
    #   The next flag is taken as the folder, so DEST becomes
    #   "--dry-run", DRY is never set, and the installer WRITES -- it
    #   builds ./--dry-run/browser.app in whatever directory it was
    #   run from, while the user believed they had asked for a dry run
    #   and nothing to be touched.
    --to)      shift
               [ $# -ge 1 ] || { echo "--to needs a folder, e.g." \
                 "--to ~/Applications" >&2; exit 2; }
               case "$1" in
                 ""|-*) echo "--to needs a folder, not \"$1\"" >&2
                        exit 2 ;;
               esac
               DEST="$1" ;;
    -h|--help) sed -n '2,30p' "$0"; exit 0 ;;
    *) echo "unknown option: $1" >&2; exit 2 ;;
  esac
  shift
done

APP="$DEST/browser.app"
C="$APP/Contents"

say() { echo "  $*"; }
run() { if [ -n "$DRY" ]; then echo "  would: $*"; else $SUDO "$@"; fi }

echo "browser -> $APP"

# ---- is this even a Mac ----
if [ "$(uname -s)" != "Darwin" ]; then
  if [ -z "$DRY" ]; then
    echo "This builds a macOS application bundle and this is not a Mac." >&2
    echo "Run it on the Mac, or with --dry-run to see what it would do." >&2
    exit 1
  fi
  say "not a Mac: dry run only, nothing will be written"
fi

# ---- arm64 all the way down ----
# Rosetta 2 is good enough that a translated browser starts, runs and
# feels wrong, which is the worst of the three outcomes: nothing says
# why. So the architecture of the hardware, of the Python and of the
# Qt wheel are all printed, and a mismatch on Apple Silicon stops the
# install rather than producing a browser that will be blamed.
#
# Asked of sysctl, not of `uname -m`: a shell running under Rosetta is
# told x86_64 by uname, which is true of the process and says nothing
# about the machine. hw.optional.arm64 is the machine.
SILICON=$(sysctl -n hw.optional.arm64 2>/dev/null || echo 0)
TRANSLATED=$(sysctl -n sysctl.proc_translated 2>/dev/null || echo 0)
say "hardware:  $(uname -m)$([ "$SILICON" = "1" ] && echo " (Apple Silicon)")"
[ "$TRANSLATED" = "1" ] && say "this shell is itself running under Rosetta"

# ---- is there a python with Qt in it ----
PY=$(command -v python3 || true)
if [ -z "$PY" ]; then
  echo "No python3 on the PATH. Install it (python.org, or brew install python)." >&2
  [ -n "$DRY" ] || exit 1
fi
if [ -n "$PY" ] && ! "$PY" -c "import PyQt6.QtWebEngineWidgets" 2>/dev/null; then
  say "PyQt6 and the web engine are not installed for $PY."
  say "  brew install pyqt"
  say "  then: BROWSER_PYTHON=/opt/homebrew/bin/python3 sh install-mac.sh"
  say ""
  say "  pip install PyQt6 also works and is the wrong answer: that"
  say "  wheel has no H.264, no HEVC and no AAC (see 'codecs' below),"
  say "  so most video stays black and the self-test's video questions"
  say "  measure the engine instead of the port."
  [ -n "$DRY" ] || exit 1
fi

# ---- which engine build, and therefore which codecs ----
# Not a detail. The PyPI wheels are redistributable builds, which means
# ffmpeg_branding=Chromium, which means the patent-encumbered decoders
# are simply not in them. Measured on the Linux x86_64 wheel 6.11.0
# (tools/macbench.py --only codecs): no H.264, no HEVC, no AAC. VP8,
# VP9, AV1, Opus, Vorbis, MP3 and FLAC are all there.
#
# So on a pip install: YouTube plays (VP9/AV1 + Opus) and Twitch does
# not, an .mp4 off the disk does not, AAC audio does not, and the
# German broadcasters' HEVC live streams do not.
#
# Homebrew's qtwebengine formula is built with
# -DFEATURE_webengine_proprietary_codecs=ON (checked in the formula
# source, 2026-10-26), and `brew install pyqt` depends on it. That is
# the install to prefer on a Mac, and on Apple Silicon it is arm64
# native, which is the other thing this script cares about.
if [ -n "$PY" ]; then
  QTWHERE=$("$PY" -c 'import PyQt6.QtWebEngineCore as m; print(m.__file__)' \
            2>/dev/null || true)
  case "$QTWHERE" in
    *site-packages*)
      say "engine:    a pip wheel ($QTWHERE)"
      say ""
      say "  NOTE: a wheel-built QtWebEngine has NO H.264, NO HEVC and"
      say "  NO AAC -- they are left out of any build that may be"
      say "  redistributed. YouTube still works (VP9/AV1 + Opus), but"
      say "  Twitch, .mp4 files, AAC audio and the ARD/ZDF HEVC live"
      say "  streams will not play, on any hardware."
      say ""
      say "  For an engine that has them:"
      say "    brew install pyqt"
      say "    BROWSER_PYTHON=/opt/homebrew/bin/python3 sh install-mac.sh"
      say ""
      say "  Measure it either way:  python3 tools/macbench.py --only codecs"
      say "" ;;
    "") : ;;
    *)  say "engine:    $QTWHERE (not a wheel -- it may have H.264; the"
        say "           codecs bench is the way to know)" ;;
  esac
fi

# what that Python is built for, and what the wheel beside it is built
# for. They can differ: pip will happily put an x86_64 wheel under an
# x86_64 Python on a machine whose processor is arm64.
PYARCH=""
QTARCH=""
if [ -n "$PY" ]; then
  PYARCH=$("$PY" -c 'import platform; print(platform.machine())' 2>/dev/null \
           || echo "?")
  say "python:    $PY ($PYARCH)"
  QTLIB=$("$PY" -c 'import PyQt6.QtCore as m; print(m.__file__)' 2>/dev/null \
          || true)
  if [ -n "$QTLIB" ] && command -v file >/dev/null 2>&1; then
    # "Mach-O 64-bit dynamically linked shared library arm64", or a
    # universal binary listing both
    QTARCH=$(file -b "$QTLIB" 2>/dev/null | tr ',' '\n' \
             | grep -Eo 'arm64|x86_64' | sort -u | tr '\n' '+' \
             | sed 's/+$//')
    say "PyQt6:     ${QTARCH:-unreadable}"
  fi
fi

# the refusal. Loud, and only where it is certainly wrong: an Apple
# Silicon machine being handed an x86_64 Python.
if [ "$SILICON" = "1" ] && [ "$PYARCH" = "x86_64" ]; then
  echo >&2
  echo "REFUSING: this is an Apple Silicon Mac and $PY is an x86_64 build." >&2
  echo >&2
  echo "  Everything it loads is translated by Rosetta, Chromium included." >&2
  echo "  A browser like that starts and runs and simply feels broken:" >&2
  echo "  scrolling stutters, video drops frames, and nothing anywhere" >&2
  echo "  says why. It is not worth installing." >&2
  echo >&2
  echo "  Install an arm64 Python and use that one:" >&2
  echo "    arch -arm64 /bin/bash -c '/opt/homebrew/bin/brew install pyqt'" >&2
  echo "    BROWSER_PYTHON=/opt/homebrew/bin/python3 sh install-mac.sh" >&2
  echo >&2
  echo "  brew, not pip: the pip wheel is arm64 but its QtWebEngine has" >&2
  echo "  no H.264, no HEVC and no AAC, so most video stays black." >&2
  echo >&2
  echo "  (or python.org's universal2 installer, which is arm64 native)" >&2
  echo >&2
  echo "  --force installs it anyway, if you know what you are doing." >&2
  [ -n "$FORCE" ] || exit 1
  say "--force given: installing a translated browser anyway"
fi
if [ "$SILICON" = "1" ] && [ -n "$QTARCH" ] \
   && ! echo "$QTARCH" | grep -q arm64; then
  echo >&2
  echo "REFUSING: the PyQt6 wheel installed for $PY is $QTARCH, not arm64." >&2
  echo "  Qt and Chromium would both run translated. Get an arm64 Qt from" >&2
  echo "  Homebrew and point this script at its Python:" >&2
  echo "    arch -arm64 /bin/bash -c '/opt/homebrew/bin/brew install pyqt'" >&2
  echo "    BROWSER_PYTHON=/opt/homebrew/bin/python3 sh install-mac.sh" >&2
  echo >&2
  echo "  Not pip: a pip wheel would be arm64 and still have no H.264," >&2
  echo "  no HEVC and no AAC, so most video would stay black. Installing" >&2
  echo "  over that one makes three of the self-test questions report a" >&2
  echo "  broken port when what is broken is the engine." >&2
  [ -n "$FORCE" ] || exit 1
  say "--force given: installing a translated engine anyway"
fi

# ---- the bundle ----
run rm -rf "$APP"
run mkdir -p "$C/MacOS" "$C/Resources/app"
run cp "$HERE/Info.plist" "$C/Info.plist"
run cp "$HERE/icon.icns" "$C/Resources/icon.icns"

# PkgInfo is eight bytes and every native bundle has it; Launch
# Services reads the same thing out of Info.plist, but a bundle without
# it is the kind of thing the Finder quietly treats as a folder.
if [ -n "$DRY" ]; then
  echo "  would: write $C/PkgInfo"
else
  printf 'APPL????' > "$C/PkgInfo"
fi

# Everything the browser reads at run time, and nothing else. The
# suite, the port tooling, the git checkout and this script stay
# outside: they belong to the folder you cloned, not to the
# application, and ninety test files inside a bundle are ninety files
# that get signed, copied and backed up for no reason.
#
# The .html pages are not documentation -- settings.html, start.html
# and the rest ARE the browser's own pages, loaded from APP_DIR, so a
# bundle without them starts to a blank window.
for f in "$HERE"/*.py "$HERE"/*.html "$HERE"/words-*.txt \
         "$HERE/icon.svg" "$HERE/LICENSE"; do
  [ -e "$f" ] || continue
  name=$(basename "$f")
  case "$name" in
    test_*.py|_boot.py) continue ;;   # the suite, not the browser
  esac
  run cp "$f" "$C/Resources/app/$name"
done
# the start page's pictures
if [ -d "$HERE/backgrounds" ]; then
  run cp -R "$HERE/backgrounds" "$C/Resources/app/backgrounds"
fi

# ---- the thing the bundle execs ----
# exec, so the app really is this process and not a shell holding one:
# a wrapper that waits around is a second icon in the Dock and an app
# the system cannot ask to quit.
if [ -n "$DRY" ]; then
  echo "  would: write $C/MacOS/browser (the launcher) and chmod +x it"
else
  cat > "$C/MacOS/browser" <<'LAUNCH'
#!/bin/sh
# Started by the Dock, by Launch Services and by `open`.
DIR=$(CDPATH= cd -- "$(dirname -- "$0")/../Resources/app" && pwd)
# Somewhere to keep the bytecode that is ours whatever the bundle is.
# browser.py is 3.2 MB and compiling it is about half a second of
# CPython; loading the cached form is about ten milliseconds. This
# bundle may well be root-owned (/Applications) or sitting on the
# read-only image Gatekeeper translocates a quarantined app onto, and
# in either case __pycache__ beside the source cannot be written --
# so without this the half second is paid on every launch, for ever.
# install-mac.sh has already filled it, so even the first start is fast.
if [ -z "$PYTHONPYCACHEPREFIX" ]; then
  PYTHONPYCACHEPREFIX="$HOME/Library/Caches/browser/pycache"
fi
if mkdir -p "$PYTHONPYCACHEPREFIX" 2>/dev/null; then
  export PYTHONPYCACHEPREFIX
else
  # nowhere to put it: slow is better than refusing to start
  unset PYTHONPYCACHEPREFIX
fi
exec "${BROWSER_PYTHON:-python3}" "$DIR/browser.py" "$@"
LAUNCH
  chmod +x "$C/MacOS/browser"
fi

# ---- the bytecode, compiled now rather than on his first launch ----
# The cache is keyed on the absolute path of the source, which is why
# this is done here, against the files where they will actually be
# read from, and with the same prefix the launcher will use. Nothing
# here needs to write inside the bundle.
PYC="$HOME/Library/Caches/browser/pycache"
if [ -n "$DRY" ]; then
  echo "  would: compile the bundle's python into $PYC"
elif [ -n "$PY" ]; then
  say "compiling the bundle's python into $PYC"
  mkdir -p "$PYC" 2>/dev/null || true
  PYTHONPYCACHEPREFIX="$PYC" "$PY" -m compileall -q \
      "$C/Resources/app" >/dev/null 2>&1 \
    || say "  (compileall was not happy; the browser will compile as it goes)"
fi

# ---- things macOS wants doing to a bundle it did not install itself ----
# An ad-hoc signature is not security theatre here: the camera and the
# microphone are remembered against the signature, so an UNSIGNED app
# is asked about again every time the folder is rebuilt. Ad-hoc is free
# and makes the answer stick.
if command -v codesign >/dev/null 2>&1; then
  run codesign --force --deep --sign - "$APP"
else
  say "no codesign here: the camera and microphone will be asked about again after every rebuild"
fi
# and the quarantine flag, if this folder came out of a download.
# Two reasons, and the second is the one nobody expects: a quarantined
# bundle opened from the Finder is "app translocated" -- macOS copies
# it onto a read-only disk image under /private/var/folders with a
# fresh random path and runs it from there. The app then cannot write
# anything next to itself, its path is different on every launch (so
# the bytecode cache above misses every time), and the camera and
# microphone permissions are remembered against a path that will not
# exist again. Stripping the flag is what stops all of that.
if command -v xattr >/dev/null 2>&1; then
  run xattr -dr com.apple.quarantine "$APP" || true
fi

echo
echo "Done."
echo
# The closing message is where a first-time user actually is when
# Gatekeeper stops them, so all three escapes are printed here and not
# only in START-HERE.txt. It used to name right-click -> Open alone,
# which is the one path Apple removed in macOS 15 -- on a current Mac
# that advice sends somebody to a menu entry that is not there.
echo "+---------------------------------------------------------------+"
echo "|  OPENING IT THE FIRST TIME                                    |"
echo "+---------------------------------------------------------------+"
echo
echo "  Try a normal double-click in ~/Applications first. The install"
echo "  just signed it and cleared the download flag, so it often works."
echo
echo "  If macOS refuses it -- no reason given, or \"cannot be opened\" --"
echo "  that is Gatekeeper, not a broken browser. It is not notarised."
echo "  Use whichever matches your macOS:"
echo
echo "    macOS 15 (Sequoia) and newer  <- most Macs today"
echo "      System Settings -> Privacy & Security, scroll down to the"
echo "      line saying browser was blocked, click  Open Anyway ."
echo
echo "    macOS 12, 13, 14"
echo "      Right-click browser in Finder -> Open -> Open. Once only."
echo
echo "    Or from this Terminal, on any version:"
echo "      xattr -dr com.apple.quarantine \"$APP\""
echo
echo "  You only have to do this once."
echo
echo "  To make it the default browser: System Settings -> Desktop & Dock"
echo "  -> Default web browser."
echo
echo "  Screen sharing in a call needs System Settings -> Privacy & Security"
echo "  -> Screen Recording, with browser ticked. macOS has no way for an"
echo "  app to ask for that itself, so nothing in the browser can prompt you."
