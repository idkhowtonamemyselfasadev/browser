#!/usr/bin/env python3
"""The Graphics row has three cases, and it was written as two.

"This machine will not let a program pick its graphics card" is true on
Windows and on macOS alike, so one boolean carried both:

    "gpuChoose": sys.platform not in ("win32", "darwin")

and settings.html hung the Windows branch off it:

    note.hidden = choose          # "Settings -> System -> Display -> Graphics"
    open.hidden = choose          # a button calling openWindowsGraphics()

Only Windows has that page. On macOS this edition therefore told the
user to open a Settings app he does not have, under a button whose
handler is `if sys.platform != "win32": return False` -- dead on click,
like the Subtitles button, and advertised just as confidently. The
explanation that IS right for him was sitting in the same page:

    gpuNone: "macOS hands a program its graphics card itself (Metal)
              and keeps that choice nowhere a program may reach..."

...and `none.hidden = cards.length > 1 || !choose` hid it, because
!choose is true on a Mac. gpu_cards() even says in its own docstring
that an empty list is "what makes the Settings row say there is nothing
to choose". It did not. The code and the comment disagreed and the
comment was right.

Found on bug-fix day, 2026-10-29, while auditing every control on the
nine pages for the Subtitles shape: a control that is shown and cannot
work. This is the one that was wrong on THIS platform specifically,
which is why no shared suite caught it.

The fix is a third signal, gpuWindowsPage, true on win32 only. The
check below is a truth table over all three platforms, run in the real
page rather than read out of the source -- the bug was a live `hidden`
value, and reading the file is how it survived.

Offscreen, scratch data; the real config is never opened. mac-only.
"""
import json
import os
import re
import sys
from pathlib import Path

os.environ["QT_QPA_PLATFORM"] = "offscreen"
os.environ["BROWSER_NO_LIB_CHECK"] = "1"

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from _boot import B                      # noqa: E402
from tests.harness import app, spin      # noqa: E402
from PyQt6.QtCore import QEventLoop, QTimer  # noqa: E402

fails = []


def check(what, ok, detail=""):
    print(("  ok   " if ok else "  FAIL ") + what
          + (("  <" + str(detail) + ">") if detail != "" else ""))
    if not ok:
        fails.append(what)


def js(page, code):
    box = {}
    loop = QEventLoop()
    page.runJavaScript("(function(){" + code + "})()", B.MAIN_WORLD_ID,
                       lambda r: (box.update({"v": r}), loop.quit()))
    QTimer.singleShot(8000, loop.quit)
    loop.exec()
    return box.get("v")


# =====================================================================
print("(1) the payload tells the page which of the three cases it is")
# =====================================================================
SRC = (HERE / "browser.py").read_text(encoding="utf-8")
check("gpuWindowsPage is in the settings payload",
      '"gpuWindowsPage": sys.platform == "win32"' in SRC)
check("gpuChoose still excludes both win32 and darwin",
      '"gpuChoose": sys.platform not in ("win32", "darwin")' in SRC)
# the two together are what make three cases out of two booleans
check("...so the three platforms are three distinct pairs",
      len({(p not in ("win32", "darwin"), p == "win32")
           for p in ("linux", "win32", "darwin")}) == 3)

# the dead end behind the button, so the test says WHY it must be hidden
check("openWindowsGraphics does nothing off Windows",
      re.search(r"def openWindowsGraphics\(self\):(?:.*\n){0,20}?"
                r'\s*if sys\.platform != "win32":\n\s*return False', SRC)
      is not None)


# =====================================================================
print("\n(2) the row, live, on all three platforms")
# =====================================================================
qapp = app()
win = B.Browser()
win.show()
spin(800)
win.open_settings()
spin(4000)
page = win._panes["settings"].view.page()
check("the settings page finished loading",
      js(page, "return document.readyState;") == "complete")
check("fillGpu is reachable from the page",
      js(page, "return typeof fillGpu;") == "function")

# The card count is part of the truth table, not a constant: on Linux
# the hint means "only one card here, nothing to choose" and must come
# and go with the count, while on Windows and macOS it must not depend
# on it at all. Getting this wrong in the first draft of this file is
# why it is spelled out -- the expectation was the bug, not the code.
CARD = ('{slot: "0000:0%d:00.0", vendor: "10de", device: "0000",'
        ' name: "A graphics card", boot: %s}')


def cards(n):
    return "[" + ", ".join(CARD % (i + 1, "true" if i == 0 else "false")
                           for i in range(n)) + "]"


#   gpunone    "nothing to choose" (on this edition: the Metal reason)
#   gpuwindows "Windows decides... Settings -> System -> Display"
#   gpuopenwin the button that opens Windows' Graphics page
# hidden flags. False means the user sees it.
CASES = [
    # name                 choose  winpage  n   gpunone gpuwindows gpuopenwin
    ("linux, one card",    "true",  "false", 1, False,  True,      True),
    ("linux, two cards",   "true",  "false", 2, True,   True,      True),
    ("win32, one card",    "false", "true",  1, True,   False,     False),
    ("win32, two cards",   "false", "true",  2, True,   False,     False),
    # macOS: gpu_cards() returns [] there, but the row must be right
    # whatever it returns -- the count is not what makes the choice
    # impossible on a Mac, Metal is.
    ("darwin, no cards",   "false", "false", 0, False,  True,      True),
    ("darwin, two cards",  "false", "false", 2, False,  True,      True),
]

for name, choose, winpage, n, want_none, want_win, want_btn in CASES:
    want = {"gpunone": want_none, "gpuwindows": want_win,
            "gpuopenwin": want_btn}
    got = js(page,
             "fillGpu({gpuCards: " + cards(n) + ", gpuChoose: " + choose
             + ", gpuWindowsPage: " + winpage
             + ", gpuCard: '', gpuAsk: false});"
             "var o = {};"
             "for (const id of ['gpunone', 'gpuwindows', 'gpuopenwin']) {"
             "  const e = document.getElementById(id);"
             "  o[id] = e ? !!e.hidden : 'MISSING';"
             "}"
             "return JSON.stringify(o);")
    try:
        got = json.loads(got or "null")
    except (TypeError, ValueError):
        got = None
    check("%s: the right things are on screen" % name, got == want,
          "want %s got %s" % (want, got))

# And the other half of a fix: it has to not have changed the platforms
# that were already right. The old rule was
#   none.hidden = cards.length > 1 || !choose
#   note.hidden = open.hidden = choose
# so every Linux and Windows row above must still match it exactly, and
# only the macOS ones may differ.
print()
for name, choose, winpage, n, want_none, want_win, want_btn in CASES:
    was_none = (n > 1) or (choose != "true")
    was_rest = (choose == "true")
    same = (was_none, was_rest, was_rest) == (want_none, want_win, want_btn)
    if name.startswith("darwin"):
        check("%s: and this is the row the old rule got wrong" % name,
              not same,
              "old rule said %s" % ((was_none, was_rest, was_rest),))
    else:
        check("%s: unchanged from the old rule" % name, same,
              "old %s new %s" % ((was_none, was_rest, was_rest),
                                 (want_none, want_win, want_btn)))

print()
# and the part that is the actual user-visible defect, stated plainly
mac = js(page,
         "fillGpu({gpuCards: [], gpuChoose: false, gpuWindowsPage: false,"
         " gpuCard: '', gpuAsk: false});"
         "const n = document.getElementById('gpunone');"
         "const w = document.getElementById('gpuwindows');"
         "const b = document.getElementById('gpuopenwin');"
         "return JSON.stringify({hint: n && !n.hidden ? n.textContent : '',"
         " win: !!(w && !w.hidden), btn: !!(b && !b.hidden)});")
mac = json.loads(mac or "{}")
check("on a Mac he is told about Metal, not about Windows",
      "macOS" in (mac.get("hint") or ""), (mac.get("hint") or "")[:60])
check("...and is not shown a Windows path he cannot follow",
      mac.get("win") is False)
check("...nor a button that returns False and does nothing",
      mac.get("btn") is False)

print("\n%d checks failed" % len(fails))
for f in fails:
    print("  - " + f)
sys.stdout.flush()
os._exit(1 if fails else 0)
