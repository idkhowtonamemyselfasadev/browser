#!/usr/bin/env python3
"""The dock, drawn the cached way, must look like the old way.

The macOS look's dock used to repaint its whole island on every frame
of the magnification ease -- twelve overlapping antialiased rounded
rectangles for the soft shadow, a gradient over the lot, and up to ten
favicons rescaled smoothly to a different size each frame. On a 2x
Retina framebuffer every one of those fills covers four times the
pixels, and a QWidget is painted on the processor.

So the island is painted once into a pixmap and blitted (`Dock._glass`)
and each icon is scaled once per size it is drawn at (`Dock._icon_at`).
That is worth 84% of the paint at 2x -- and it would be worth nothing
at all if it drew something even slightly different. "Faster, and the
dock looks subtly wrong" is not a win.

This renders both paths into the same surface and differences them,
at the scale factor the process was started with. Run it twice:

    QT_SCALE_FACTOR=1 python3 test_macpaint.py
    QT_SCALE_FACTOR=2 python3 test_macpaint.py

tools/runall.sh does both. There is no Mac here and this does not
pretend there is: what it holds is that the caching is honest, on
whatever surface this box can make.

Offscreen, against a throwaway profile. It never touches the browser
you use.
"""
import os
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
os.environ["QT_QPA_PLATFORM"] = "offscreen"
os.environ.setdefault("BROWSER_HOME",
                      tempfile.mkdtemp(prefix="macpaint-"))
os.environ["BROWSER_NO_LIB_CHECK"] = "1"
os.environ["BROWSER_NO_GPU_ASK"] = "1"
sys.path.insert(0, str(HERE))

import browser as B                                       # noqa: E402
from PyQt6.QtCore import Qt                               # noqa: E402
from PyQt6.QtGui import QImage, QPainter, QPixmap         # noqa: E402
from PyQt6.QtWidgets import QApplication                  # noqa: E402

fails = []


def check(name, cond, detail=""):
    print(("  ok   " if cond else "  FAIL ") + name
          + (("  " + str(detail)) if detail and not cond else ""))
    if not cond:
        fails.append(name)


app = QApplication(sys.argv[:1])
win = B.Browser()
win.resize(1440, 900)
win.show()
app.processEvents()

pins = win.pins() or []
if len(pins) < 10:
    pins = (list(pins) + [{"url": "https://example.com/%d" % i,
                           "name": "site %d" % i, "icon": ""}
                          for i in range(10)])[:10]
dock = B.Dock(win)
dock.set_pins(pins)
dock.resize(*dock._wanted())
dock._focus = dock.width() // 2     # a bulge under the middle
dock._reach = 0.6

RATIO = float(dock.devicePixelRatioF() or 1.0)
print("(1) the surface this process really got")
print("    QT_SCALE_FACTOR=%s -> devicePixelRatioF %g, dock %dx%d"
      % (os.environ.get("QT_SCALE_FACTOR", "unset"), RATIO,
         dock.width(), dock.height()))
check("the dock has a real size to paint into",
      dock.width() > 100 and dock.height() > 40,
      (dock.width(), dock.height()))


def paint(cached):
    """One frame, by one of the two paths, into a surface the widget's
    own ratio decides -- never one invented here. _glass() and
    _icon_at() ask the *widget* for its devicePixelRatioF, so a faked
    ratio would get a 1x island blitted up to fit: blurrier and
    cheaper than the thing being measured."""
    surface = QPixmap(int(round(dock.width() * RATIO)),
                      int(round(dock.height() * RATIO)))
    surface.setDevicePixelRatio(RATIO)
    surface.fill(Qt.GlobalColor.transparent)
    painter = QPainter(surface)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
    if cached:
        painter.drawPixmap(0, 0, dock._glass())
        for rect, _pin, pixmap in dock.item_rects():
            if not pixmap.isNull():
                painter.drawPixmap(rect.topLeft(),
                                   dock._icon_at(pixmap, rect.width()))
    else:
        dock._glass_cache = None
        dock._icon_cache = {}
        dock._paint_glass(painter)
        for rect, _pin, pixmap in dock.item_rects():
            if not pixmap.isNull():
                painter.drawPixmap(rect, pixmap)
    painter.end()
    return surface.toImage().convertToFormat(QImage.Format.Format_ARGB32)


def diff(a, b):
    """(how many pixels differ, the worst single channel difference)."""
    bad = worst = 0
    for y in range(a.height()):
        for x in range(a.width()):
            pa, pb = a.pixel(x, y), b.pixel(x, y)
            if pa != pb:
                bad += 1
                for shift in (0, 8, 16, 24):
                    worst = max(worst, abs(((pa >> shift) & 255)
                                           - ((pb >> shift) & 255)))
    return bad, worst


print("\n(2) the two paths draw the same dock")
old = paint(False)
new = paint(True)
check("both paths produced the same size of image",
      old.size() == new.size(), (old.size(), new.size()))
bad, worst = diff(old, new)
total = old.width() * old.height()
print("    %d of %d pixels differ (%.3f%%), worst channel delta %d"
      % (bad, total, 100.0 * bad / total, worst))
# The island is blitted from a pixmap painted by the very same
# _paint_glass, so it is exact. The icons go through a different
# scaling call (pixmap.scaled once, against drawPixmap-into-a-rect
# every frame), and two smooth filters do not agree to the last bit.
check("nothing moved: the difference is filtering, not geometry",
      worst <= 8, worst)
check("and it is confined to the icons, not the whole island",
      bad < total * 0.12, "%d/%d" % (bad, total))

print("\n(3) the caches are caches, not a different drawing")
first = dock._glass()
again = dock._glass()
check("the island is handed back, not repainted",
      first is again)
check("...at the ratio this surface really has",
      abs(first.devicePixelRatio() - RATIO) < 1e-6,
      first.devicePixelRatio())
check("...and it is the size of the dock, in device pixels",
      first.width() == int(round(dock.width() * RATIO)),
      (first.width(), dock.width(), RATIO))
dock.resize(dock.width() + 40, dock.height())
check("a resize gets a new one rather than a stretched old one",
      dock._glass() is not first
      and dock._glass().width() == int(round(dock.width() * RATIO)))
dock.resize(dock.width() - 40, dock.height())

sizes = set()
for rect, _pin, pixmap in dock.item_rects():
    if not pixmap.isNull():
        sizes.add(rect.width())
        one = dock._icon_at(pixmap, rect.width())
        check("icon at %d px is handed back, not rescaled" % rect.width(),
              dock._icon_at(pixmap, rect.width()) is one)
        check("...at the surface's ratio",
              abs(one.devicePixelRatio() - RATIO) < 1e-6)
check("the magnification really is drawing several different sizes",
      len(sizes) > 1, sorted(sizes))
check("there cannot be more cached icons than sizes times pins",
      len(dock._icon_cache) <= len(pins) * (dock.ICON_MAX - dock.ICON + 1),
      len(dock._icon_cache))
dock.set_pins(pins)
check("a new set of pins drops the old scaled icons",
      dock._icon_cache == {})

print("\n(4) the frame the ease runs at")
check("60 Hz is still the 16 ms this was written with",
      B.Dock.frame_ms(60.0) == 16)
check("120 Hz ProMotion gets 8", B.Dock.frame_ms(120.0) == 8)
check("the dock took its interval from the screen, not from a literal",
      6 <= dock._ease.interval() <= 20, dock._ease.interval())
check("and the ease is not running while nothing is happening",
      not dock._ease.isActive())

print("\n%d checks failed" % len(fails))
if fails:
    for f in fails:
        print("  - " + f)
sys.exit(1 if fails else 0)
