#!/usr/bin/env python3
"""Does the dispatcher actually apply the theme, or only the snippet?

Linux's test_offpalette.py asks two questions about the page-side tools
-- are the colours in the snippet real tokens, and does tint_js move
them -- and it tints the snippets itself to find out. Neither question
is "does the code path that runs the snippet call tint_js", and on
2026-10-29 one of ten dispatchers did not.

`dev_tool` was the one. DEV_TOOLS.update(DEV_TOOLS_PAGE) at the bottom
of browser.py makes it the only route to five overlays, and it guards
the ARG swap with `if "ARG" in source:` instead of spelling
`source.replace("ARG"` like the other six -- so the sweep that wired
tint_js in did not match it. The off-palette commit therefore moved
those five onto real tokens and the swap was never applied: correct on
mocha, whose surface IS #0d0d12, and unchanged on all 28 light themes.
Found by the windows session by reading the computed background out of
the page. A static marker can say the call is present; only running it
can say the call is reached.

So this drives each dispatcher for real -- a loaded page, a live
QWebEnginePage, the engine's own runJavaScript spied on -- and asks
what bytes were handed to the page under mocha and under latte.

It also pins the gap that is still open, rather than leaving it to look
covered: three tables carry colours that are NOT theme tokens, and
their dispatchers do not tint. tint_js could not help them if it were
called, because it only moves a colour that some token owns. Choosing
which token a visited-link purple or a highlighter yellow should
become is a palette decision for all four editions, so it is recorded
here and asserted to be STILL BROKEN -- the day somebody normalises
them, section 3 fails and says so.

Offscreen, scratch data, one local server. Nothing reaches the network.
"""
import os
import re
import sys
from pathlib import Path

os.environ["QT_QPA_PLATFORM"] = "offscreen"
os.environ["BROWSER_NO_LIB_CHECK"] = "1"
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE / "tests"))

import harness as H  # noqa: E402
B = H.boot()

fails = []


def check(what, ok, detail=""):
    print(("  ok   " if ok else "  FAIL ") + what
          + (("  <" + str(detail) + ">") if detail != "" else ""))
    if not ok:
        fails.append(what)


HEX = re.compile(r"#[0-9a-fA-F]{3,6}\b")
TOKEN_HEX = {v.lower() for v in B.THEME_SOURCE.values()}

#: table -> (dispatcher, a key in it whose snippet paints a token)
ROUTES = (
    ("DESK_TOOLS", "desk_tool", "counter"),
    ("READ_TOOLS", "read_page_tool", "selbar"),
    ("MEDIA_TOOLS2", "media_tool2", "heldembeds"),
    ("PLAY_TOOLS", "play_tool", "fps"),
    ("DEV_TOOLS", "dev_tool", "hiddenfields"),
    ("PAGE_TOOLS", "page_tool", "edit"),
    ("MEDIA_TOOLS", "media_tool", "wheelvolume"),
)
#: READ_TOOLS (read_page_tool) and READER_TOOLS (read_tool) are two
#: different tables one letter apart, and the near-name is worth
#: naming: a sweep that reads "READ_TOOLS: tints" can be quoted as
#: "read_tool tints" and be wrong. read_tool does NOT tint, in this
#: tree or in linux's. Nothing in READER_TOOLS is a token, so the call
#: would change no pixel -- adding it is only worth doing together with
#: normalising `hints`, which is the palette decision below.
UNTINTED = ("READER_TOOLS",)

app = H.app()
srv = H.Server({"/p.html": "<title>p</title><input type=hidden name=x>"
                           "<p>something to look at</p>"})
win = B.Browser()
win.resize(1000, 700)
win.show()
H.spin(300)
view = win.new_tab(srv.url("/p.html"))
H.wait_for(lambda: "something to look at"
           in (H.js(view, "document.body.innerText") or ""), 8000)
win.tabs.setCurrentWidget(view)
H.spin(200)

LIGHT = [t["key"] for t in B.THEMES if t.get("group") == "light"][0]
DARK = B.DEFAULT_THEME

print("(1) the snippets these routes run do paint a token")
for table, _fn, key in ROUTES:
    tab = getattr(B, table, {})
    if key not in tab:
        check("%s.%s is in the tree" % (table, key), False, "missing")
        continue
    lits = {l.lower() for l in HEX.findall(tab[key])}
    check("%s.%s paints at least one token" % (table, key),
          bool(lits & TOKEN_HEX), sorted(lits) or "no colour at all")

print("\n(2) ...and the dispatcher hands the page the CURRENT theme")
# Asked as a property of the COLOURS, not of the whole string, and not
# against a named token. Both of those were wrong here first:
#
#   * naming a token failed three times over -- PLAY_TOOLS.fps carries
#     its surface as an rgba not a hex, the comma spelling survives
#     under mocha where tint_js returns the source untouched, and
#     PAGE_TOOLS.edit paints `bg` rather than `surface`. A check that
#     must know which token each snippet happens to use goes red every
#     time somebody picks a different one.
#   * comparing the whole string between two calls failed too, and for
#     a reason worth writing down: several of these tools TOGGLE. Call
#     one twice and the second call legitimately sends different code,
#     so "mocha's bytes != latte's bytes" was measuring the toggle, not
#     the theme. tint_js itself was clean for both -- checked directly.
#
# What holds for every route regardless: the set of colour literals the
# dispatcher sends must MOVE off the snippet's own set on a light
# theme, and must match it exactly under the default theme, where
# tint_js returns the source unchanged.
COLOUR = re.compile(r"#[0-9a-fA-F]{3,6}\b"
                    r"|rgba?\(\s*\d+\s*,[^)]*\)"
                    r"|rgb\(\s*\d+ \d+ \d+(?: / [^)]*)?\)")


def colours(text):
    return {c.lower().replace(" ", "") for c in COLOUR.findall(text)}


page = win._live_page(view)
real = page.runJavaScript
sent = []
page.runJavaScript = lambda code, *a, **kw: (sent.append(code),
                                             real(code, *a, **kw))[1]


def run(fn, key, theme):
    B._select_theme(theme)
    sent.clear()
    getattr(win, fn)(key, view=view)
    H.spin(250)
    return colours("\n".join(sent))


for table, fn, key in ROUTES:
    if key not in getattr(B, table, {}):
        continue
    raw = colours(getattr(B, table)[key])
    got_dark = run(fn, key, DARK)
    got_light = run(fn, key, LIGHT)
    check("%s sends %s in the default theme's own colours" % (fn, key),
          raw <= got_dark,
          "snippet has %s, page got %s" % (sorted(raw), sorted(got_dark)))
    # the detail reads the same whether this passes or fails, so it
    # says what was SEEN rather than what went wrong: a failure line
    # phrased as a diagnosis is a lie on every passing run
    check("...and %s swaps them on a light theme" % key,
          got_light != got_dark,
          "%s -> %s" % (sorted(got_dark), sorted(got_light)))
B._select_theme(DARK)

print("\n(3) what no theme can reach -- STILL BROKEN, pinned by (key, hex)")
# Each of these paints a colour no token owns, so tint_js returns it
# unchanged even where it is called. Which token a visited-link purple
# or a highlighter yellow should become is a palette decision for all
# four editions, not one to invent inside this one.
#
# Pinned as (key, literal) pairs rather than a count, because a count
# can stay right while the thing it counts moves. A pair that no longer
# matches is reported as STALE in its own right -- the day somebody
# normalises one, this says which, instead of a number being one lower.
#
# NOT on this list, deliberately: PAGE_TOOLS.totop's scrim. Linux
# measured it -- alpha .75 means _recolor leaves the fill, so only the
# ink can move, and bright ink on an unmoved scrim fails 4.5:1 on 30 of
# 116 themes. It is a non-token on purpose and normalising it would be
# a contrast regression dressed as a tidy-up. Its #fff ink is pinned;
# its rgba fill is left out of the hex sweep entirely.
PINNED = {
    "PAGE_TOOLS": {("visited", "#b48ead"), ("totop", "#fff")},
    "READER_TOOLS": {("hints", "#ffd866"), ("hints", "#000"),
                     ("hints", "#806000")},
}
for table, pins in sorted(PINNED.items()):
    tab = getattr(B, table, None)
    if tab is None:
        check("%s is in the tree" % table, False, "missing")
        continue
    live = {(k, l.lower()) for k, s in tab.items()
            for l in HEX.findall(s) if l.lower() not in TOKEN_HEX}
    check("%s: every pinned off-palette literal is still there" % table,
          pins <= live, "gone (fixed? then drop the pin): %s"
          % sorted(pins - live))
    check("...and nothing new has been added to %s" % table,
          live <= pins, "unpinned: %s" % sorted(live - pins))

# MEDIA_TOOLS was on this list an hour ago and is not any more: its two
# literals were the same #000/#fff, normalised to the tokens' own
# spelling. Asserted rather than deleted, so "it got fixed" and "the
# check stopped looking" cannot be confused.
check("MEDIA_TOOLS has no off-palette literal left at all",
      not {l.lower() for _k, s in B.MEDIA_TOOLS.items()
           for l in HEX.findall(s)} - TOKEN_HEX,
      sorted({l.lower() for _k, s in B.MEDIA_TOOLS.items()
              for l in HEX.findall(s)} - TOKEN_HEX))

print("\n%d check(s) failed" % len(fails))
for name in fails:
    print("  - " + name)
sys.stdout.flush()
os._exit(1 if fails else 0)
