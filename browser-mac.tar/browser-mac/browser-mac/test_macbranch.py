#!/usr/bin/env python3
"""The macOS branches of this file, checked on Linux.

browser.py is one file for every edition, and the Mac one is generated
from it (see tools/mac_port.json in browser-mac) exactly the way the
Windows one is. A branch that only a Mac takes is therefore written
here and runs nowhere, and test_winbranch.py exists because of what
that costs: `_write_atomic` called `_restrict_to_owner` for weeks with
no such name in this file, and nothing noticed, because on Linux the
branch is never taken.

So: every darwin branch in this file, exercised here. There is no Mac
on this machine and this file does not pretend there is -- what it
proves is that each branch does what it says with a `sys` of our
choosing, that the programs it reaches for are the ones that platform
actually has, and that the pure parts (ps output, `say -v ?` output,
the CDM paths, the spaces in them) really parse. What needs a Mac is
written down in mac/PORT.md and is not claimed here.

Nothing here writes outside a throwaway directory, and nothing here
needs the network or a window.
"""
import ast
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from _boot import B  # noqa: E402

SCRATCH = Path(tempfile.mkdtemp(prefix="macbranch-"))
SRC = (HERE / "browser.py").read_text(encoding="utf-8")
TREE = ast.parse(SRC)
fails = []


def check(name, cond, detail=""):
    print(("  ok   " if cond else "  FAIL ") + name
          + (("  " + str(detail)) if detail and not cond else ""))
    if not cond:
        fails.append(name)


def source_of(name):
    """One top-level def's source, by name."""
    for node in TREE.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) \
                and node.name == name:
            return ast.get_source_segment(SRC, node) or ""
    return ""


def source_of_file(module, name):
    """One function's source, out of a sibling module's own file."""
    text = Path(module.__file__).read_text(encoding="utf-8")
    for node in ast.parse(text).body:
        if isinstance(node, ast.FunctionDef) and node.name == name:
            return ast.get_source_segment(text, node) or ""
    return ""


def method_source(cls, name):
    for node in TREE.body:
        if isinstance(node, ast.ClassDef) and node.name == cls:
            for sub in node.body:
                if isinstance(sub, (ast.FunctionDef, ast.AsyncFunctionDef)) \
                        and sub.name == name:
                    return ast.get_source_segment(SRC, sub) or ""
    return ""


class Fake:
    pass


class Pretend:
    """`sys.platform` says what we want for as long as this is held.

    The module's own global is swapped, not the real sys: every branch
    in here reads the module-level name, and the standard library is
    still reading the real one (which is what makes importing with a
    faked sys.platform useless -- see test_winbranch)."""

    def __init__(self, platform):
        self.platform = platform

    def __enter__(self):
        self.real = B.sys
        fake = Fake()
        for attr in ("executable", "maxsize", "argv", "stderr", "stdout"):
            setattr(fake, attr, getattr(sys, attr))
        fake.platform = self.platform
        B.sys = fake
        return fake

    def __exit__(self, *_):
        B.sys = self.real


def only_which(found):
    """shutil.which, as the module sees it, answering from a dict."""
    real = B.shutil.which

    class Swap:
        def __enter__(self):
            self.looked = []
            B.shutil.which = lambda n: (self.looked.append(n),
                                        found.get(n, ""))[1]
            return self.looked

        def __exit__(self, *_):
            B.shutil.which = real
    return Swap()


# ---------------------------------------------------------------------
print("(1) where everything of his is kept on a Mac")
WANTED = {"BROWSER_HOME", "CONFIG_FILE"}


def assigns(node):
    out = set()
    for sub in ast.walk(node):
        if isinstance(sub, ast.Assign):
            for t in sub.targets:
                if isinstance(t, ast.Name):
                    out.add(t.id)
    return out


REGION = [n for n in TREE.body if assigns(n) & WANTED]


def build(platform, environ):
    """Run that region with a sys and an os of our choosing."""
    fake_sys, fake_os = Fake(), Fake()
    fake_sys.platform = platform
    fake_os.environ = environ
    ns = {"sys": fake_sys, "os": fake_os, "Path": Path, "QUrl": B.QUrl,
          "APP_DIR": HERE}
    exec(compile(ast.Module(body=REGION, type_ignores=[]),
                 "<browser-home region>", "exec"), ns)
    return {k: str(ns[k]) for k in WANTED if k in ns}


mac = build("darwin", {})
want = str(Path.home() / "Library/Application Support/browser")
check("on macOS it is ~/Library/Application Support/browser",
      mac["BROWSER_HOME"] == want, mac["BROWSER_HOME"])
check("config.json sits under it",
      mac["CONFIG_FILE"] == str(Path(want) / "config.json"),
      mac["CONFIG_FILE"])
check("nothing of his lands on a Linux path there",
      ".local/share" not in mac["BROWSER_HOME"], mac)
check("nor on the Windows one",
      "AppData" not in mac["BROWSER_HOME"], mac)
check("BROWSER_HOME still moves all of it at once",
      build("darwin", {"BROWSER_HOME": str(SCRATCH / "elsewhere")}
            )["CONFIG_FILE"] == str(SCRATCH / "elsewhere" / "config.json"))
check("and the two editions that were already here did not move",
      build("linux", {})["BROWSER_HOME"]
      == str(Path.home() / ".local/share/browser")
      and build("win32", {"LOCALAPPDATA": "/L"})["BROWSER_HOME"]
      == str(Path("/L") / "browser"))

# ---------------------------------------------------------------------
print("\n(2) the PATH an app started from the Dock is handed")
check("on this machine it does nothing at all",
      B._mac_path_fix() == "" and B._mac_path_fix({"PATH": "/x"}) == "")
env = {"PATH": "/usr/bin:/bin:/usr/sbin:/sbin"}
with Pretend("darwin"):
    # the directories it offers are asked of the real filesystem, and
    # /usr/local/bin is one this machine has too
    out = B._mac_path_fix(env)
check("on a Mac it adds to PATH", out and out != "/usr/bin:/bin:/usr/sbin:/sbin",
      out)
check("what was there already is still first",
      out.startswith("/usr/bin:/bin:/usr/sbin:/sbin"), out)
check("and only directories that are really there were added",
      all(os.path.isdir(p) for p in out.split(os.pathsep)), out)
check("it is the same list he would get from a shell",
      "/usr/local/bin" in out.split(os.pathsep), out)
with Pretend("darwin"):
    again = B._mac_path_fix(env)
check("running twice does not double anything",
      again == out and len(again.split(os.pathsep))
      == len(set(again.split(os.pathsep))), again)
src = source_of("_mac_path_fix")
check("Homebrew on Apple silicon is in the list",
      "/opt/homebrew/bin" in src)
check("and the Intel one too", "/usr/local/bin" in src)
check("it really is called at import time", "\n_mac_path_fix()\n" in SRC)

# ---------------------------------------------------------------------
print("\n(3) holding the screen awake while a video plays")
browser = B.Browser.__new__(B.Browser)
with Pretend("darwin"):
    with only_which({"caffeinate": "/usr/bin/caffeinate"}) as looked:
        argv = browser._awake_command("video")
check("it looks for caffeinate, not systemd-inhibit",
      looked == ["caffeinate"], looked)
check("and that is what it would run",
      argv and argv[0] == "/usr/bin/caffeinate", argv)
for flag, what in (("-d", "the display"), ("-i", "the idle timer"),
                   ("-m", "the disks"), ("-s", "sleep on mains")):
    check("%s is held (%s)" % (what, flag), flag in argv, argv)
check("it is tied to this very process, so a kill cannot leave a Mac "
      "unable to sleep",
      "-w" in argv and argv[argv.index("-w") + 1] == str(os.getpid()), argv)
check("no --why is invented for a platform that takes none",
      not any("why" in a for a in argv), argv)
with Pretend("darwin"):
    with only_which({}):
        check("with no caffeinate it says so rather than guessing",
              browser._awake_command() == [])
with Pretend("linux"):
    with only_which({"systemd-inhibit": "/usr/bin/systemd-inhibit"}):
        linux = browser._awake_command("video")
check("on Linux the very same method is unchanged",
      linux == ["/usr/bin/systemd-inhibit", "--what=idle:sleep",
                "--who=browser", "--why=video", "--mode=block",
                "sleep", "infinity"], linux)
check("and keep_awake really goes through it",
      "_awake_command(why)" in method_source("Browser", "keep_awake"))
check("letting go is still terminating our own child, on either",
      "held.terminate()" in method_source("Browser", "keep_awake"))

# ---------------------------------------------------------------------
print("\n(4) a notification, without an AppleScript injection")
with Pretend("darwin"):
    with only_which({"osascript": "/usr/bin/osascript"}):
        prog, args = browser._notify_command("done", "browser")
check("osascript is what it runs", prog == "/usr/bin/osascript", prog)
check("the script is handed in with -e", args.count("-e") == 3, args)
check("it is an `on run argv` script",
      "on run argv" in args and "end run" in args, args)
nasty = 'x" with title "pwned" & (do shell script "id") & "'
with Pretend("darwin"):
    with only_which({"osascript": "/usr/bin/osascript"}):
        prog, args = browser._notify_command(nasty, 'a" & "b')
script = " ".join(a for a in args if a.startswith(("on ", "display", "end ")))
check("a title with a quote in it never reaches the script text",
      "pwned" not in script and "do shell script" not in script, script)
check("it travels as an argument instead",
      nasty in args and 'a" & "b' in args, args)
check("and the text comes first, the title second",
      args.index(nasty) < args.index('a" & "b'), args)
check("the script reads them in that order",
      "item 1 of argv" in script and "item 2 of argv" in script
      and script.index("item 1") < script.index("item 2"), script)
with Pretend("darwin"):
    with only_which({}):
        prog, _ = browser._notify_command("x")
check("a Mac with nothing on the PATH still has /usr/bin/osascript",
      prog == "/usr/bin/osascript", prog)
with Pretend("linux"):
    with only_which({"notify-send": "/usr/bin/notify-send"}):
        prog, args = browser._notify_command("done", "browser")
check("on Linux it is notify-send with the same two strings",
      prog == "/usr/bin/notify-send"
      and args == ["-a", "browser", "browser", "done"], (prog, args))
with Pretend("linux"):
    with only_which({}):
        check("and a Linux without it shows nothing rather than failing",
              browser._notify_command("x")[0] == "")
check("notify_desktop really goes through it",
      "_notify_command(" in method_source("Browser", "notify_desktop"))

# ---------------------------------------------------------------------
print("\n(5) reading a page aloud with the voices a Mac has")
LISTING = """Albert              en_US    # Hello! My name is Albert.
Anna                de_DE    # Hallo, mein Name ist Anna.
Bad News            en_US    # Hello.
Markus              de_DE    # Hallo.
Zuzana              cs_CZ    # Dobry den.
"""
voices = B.Browser.mac_voices(LISTING)
check("every language in the listing is read", set(voices)
      == {"en", "de", "cs"}, voices)
check("the first voice for a language wins",
      voices["en"] == "Albert" and voices["de"] == "Anna", voices)
check("a voice whose name has a space in it is read whole",
      B.Browser.mac_voices("Bad News  en_US  # Hi.")["en"] == "Bad News")
check("junk is ignored rather than guessed at",
      B.Browser.mac_voices("") == {}
      and B.Browser.mac_voices("nonsense\n\n# comment") == {})
check("a comment with an underscore in it is not mistaken for a code",
      B.Browser.mac_voices("Anna de_DE # my_name is en_GB.")
      == {"de": "Anna"})
browser._mac_voices = voices
with Pretend("darwin"):
    prog, args, feed = browser._say_argv("hello there", "de", 0)
    none = browser.mac_voice("ja")
check("the German voice on this machine is asked for",
      "-v" in args and args[args.index("-v") + 1] == "Anna", args)
check("a language with no voice installed is left to the default",
      none == "", none)
with Pretend("darwin"):
    check("and then no -v is passed at all",
          "-v" not in browser._say_argv("x", "ja", 0)[1])
check("say is the program", prog.endswith("say"), prog)
check("the rate is words per minute around the 175 it defaults to",
      args[args.index("-r") + 1] == "175", args)
with Pretend("darwin"):
    fast = browser._say_argv("x", "en", 100)[1]
    slow = browser._say_argv("x", "en", -100)[1]
    silly = browser._say_argv("x", "en", 9999)[1]
check("faster is faster and slower is slower",
      int(fast[fast.index("-r") + 1]) == 275
      and int(slow[slow.index("-r") + 1]) == 90, (fast, slow))
check("and a config that says anything at all cannot ask for 0 wpm",
      90 <= int(silly[silly.index("-r") + 1]) <= 300, silly)
check("the text is NOT an argument there", "hello there" not in args, args)
check("it is fed to its input, where a dash cannot be read as a flag",
      feed == "hello there", feed)
with Pretend("darwin"):
    long_feed = browser._say_argv("x" * 9000, "en", 0)[2]
check("and it is still capped at 5000 characters", len(long_feed) == 5000)
with Pretend("linux"):
    prog, args, feed = browser._say_argv("hello", "de", 20)
check("on Linux it is spd-say, with the text as an argument, as before",
      (prog, args, feed) == ("spd-say",
                             ["-l", "de", "-r", "20", "-w", "hello"], None),
      (prog, args, feed))
with Pretend("darwin"):
    with only_which({"say": "/usr/bin/say"}) as looked:
        found = B.Browser.say_tool(browser)
check("say_tool looks for say there, not for spd-say",
      looked == ["say"] and found == "/usr/bin/say", (looked, found))
with Pretend("linux"):
    with only_which({"spd-say": "/usr/bin/spd-say"}) as looked:
        found = B.Browser.say_tool(browser)
check("and on Linux it looks for spd-say, not for say",
      looked == ["spd-say"] and found == "/usr/bin/spd-say", (looked, found))
check("read_aloud really feeds the text in rather than passing it",
      "closeWriteChannel()" in method_source("Browser", "read_aloud"))
check("stopping it is killing it, with no spd-say -C on a Mac",
      'sys.platform != "win32" and shutil.which("spd-say")'
      in method_source("Browser", "stop_aloud"))

# ---------------------------------------------------------------------
print("\n(6) what a renderer costs, with no /proc to read it from")
check("ps's two columns parse", B._mac_process_cost(42, " 123456 01:23.45\n")
      == {"pid": 42, "bytes": 123456 * 1024, "seconds": 83.45},
      B._mac_process_cost(42, " 123456 01:23.45\n"))
check("seconds alone", B._mac_process_cost(1, "8 9.5")["seconds"] == 9.5)
check("hours:minutes:seconds",
      B._mac_process_cost(1, "8 2:01:00.00")["seconds"] == 7260.0)
check("a process that has gone answers nothing, not zero",
      B._mac_process_cost(1, "") == {} and B._mac_process_cost(0, "x") == {})
check("and so does an unreadable line",
      B._mac_process_cost(1, "nonsense here") == {}
      and B._mac_process_cost(1, "1024") == {})
with Pretend("darwin"):
    real = B._mac_process_cost
    try:
        B._mac_process_cost = lambda pid, out=None: {"pid": pid,
                                                     "bytes": 7,
                                                     "seconds": 3.5}
        cost = B.Browser.process_cost(99)
        cpu = B.Browser.renderer_cpu(browser, 99)
    finally:
        B._mac_process_cost = real
check("process_cost goes through it there", cost["bytes"] == 7, cost)
check("renderer_cpu too", cpu == 3.5, cpu)
check("neither of them reads /proc on a Mac",
      "/proc" not in method_source("Browser", "process_cost").split(
          'platform == "darwin"')[1].split("try:")[0]
      and "/proc" not in method_source("Browser", "renderer_cpu").split(
          'platform == "darwin"')[1].split("try:")[0])

# ---------------------------------------------------------------------
print("\n(7) Widevine, and the space in every path a Mac keeps it behind")
cdm = SCRATCH / "Google Chrome.app/Contents/Frameworks"
leafdir = (cdm / "Google Chrome Framework.framework/Versions/142.0.1"
           / "Libraries/WidevineCdm/_platform_specific" / B._mac_arch())
leafdir.mkdir(parents=True)
(leafdir / "libwidevinecdm.dylib").write_bytes(b"not really a cdm")
roots = B._mac_cdm_roots(apps=[str(SCRATCH / "Google Chrome.app")],
                         home=str(SCRATCH / "Application Support"))
check("the framework's version directory is found",
      any("142.0.1" in str(r) for r in roots), roots)
check("and his own Application Support copies are looked for too",
      any(str(r).endswith("Google/Chrome") for r in roots), roots)
with Pretend("darwin"):
    real_roots, real_home = B._mac_cdm_roots, B.Path.home
    try:
        B._mac_cdm_roots = lambda: roots
        found = B._find_widevine()
    finally:
        B._mac_cdm_roots = real_roots
check("_find_widevine finds a Mac CDM", found and found.endswith(".dylib"),
      found)
check("it is the dylib, not the Linux .so", ".so" not in str(found), found)
check("the architecture asked for is the one this process could load",
      B._mac_arch() in ("mac_arm64", "mac_x64")
      and "os.uname()" in source_of("_mac_arch"))
check("a path with no space in it is handed back untouched",
      B._space_free("/tmp/a/libwidevinecdm.dylib")
      == "/tmp/a/libwidevinecdm.dylib")
link = B._space_free(found, cache=SCRATCH / "Caches/browser")
check("one with a space becomes a link that has none",
      link and " " not in link, link)
check("the link is really there and really points at the CDM",
      link and Path(link).is_symlink()
      and Path(link).resolve() == Path(found).resolve(), link)
check("and the engine could actually be told about it",
      link and " " not in ('--widevine-path="%s"' % link).split("=")[1],
      link)
again = B._space_free(found, cache=SCRATCH / "Caches/browser")
check("made again on the next start rather than left to go stale",
      again == link and Path(again).is_symlink())
(SCRATCH / "Caches/browser/libwidevinecdm.dylib").unlink()
(SCRATCH / "Caches/browser/libwidevinecdm.dylib").write_bytes(b"stale")
third = B._space_free(found, cache=SCRATCH / "Caches/browser")
check("a stale file in the way is replaced, not kept",
      third and Path(third).is_symlink(), third)
check("with a space in the cache folder too it says None, not half a path",
      B._space_free(found, cache=SCRATCH / "no space here") is None)
check("and it never copies the CDM anywhere",
      not any(w in source_of("_space_free")
              for w in ("shutil.copy", "copyfile", "read_bytes",
                        "write_bytes")))
check("the import-time one goes through it on a Mac",
      'if _WIDEVINE_CDM and sys.platform == "darwin":' in SRC
      and "_space_free(_WIDEVINE_CDM)" in SRC)
check("so does the launch-time one",
      'if cdm and sys.platform == "darwin":' in SRC)
with Pretend("linux"):
    check("on Linux nothing about Widevine changed",
          B._find_widevine.__doc__ and "libwidevinecdm.so" in source_of(
              "_find_widevine"))

# ---------------------------------------------------------------------
print("\n(8) the engine's flags, which are not Linux's")
flags = source_of("_install_proxy_flags")
check("HEVC is still asked for on both",
      "--enable-features=PlatformHEVCDecoderSupport" in flags)
check("but VA-API is not asked of a Mac",
      'if sys.platform != "darwin":' in flags
      and flags.index('if sys.platform != "darwin":')
      < flags.index("VaapiVideoDecoder"), )
check("nor is the NVIDIA blocklist override",
      flags.index('if sys.platform != "darwin":')
      < flags.rindex("--ignore-gpu-blocklist"))

# ---------------------------------------------------------------------
print("\n(9) which graphics card, where a program may not choose")
with Pretend("darwin"):
    check("no card list is invented", B.gpu_cards() == [])
    check("and nothing is put in the environment to steer one",
          B.gpu_env("whatever") == ({}, []))
with Pretend("linux"):
    check("on Linux the cards are still read out of sysfs",
          isinstance(B.gpu_cards(), list)
          and B.gpu_env("auto")[1] and "DRI_PRIME" in B.gpu_env("auto")[1])
check("the picker window cannot come up there",
      'if sys.platform in ("win32", "darwin"):'
      in source_of("_gpu_startup"))
check("and Settings says there is nothing to choose",
      '"gpuChoose": sys.platform not in ("win32", "darwin")' in SRC)

# ---------------------------------------------------------------------
print("\n(10) the glass look, which has no blur behind it there")
check("look_style puts glass on a solid base on a Mac",
      'if look == "glass" and sys.platform in ("win32", "darwin"):'
      in SRC)
with Pretend("darwin"):
    qss = B.look_style("glass", "mocha")
check("and the base is really in the sheet", "#root { background:" in qss,
      qss[-120:])
with Pretend("linux"):
    check("on Linux glass is untouched",
          "#root { background: #000000; }" not in B.look_style("glass",
                                                               "mocha"))
win = SRC.split("WA_TranslucentBackground")[0]
check("the window does not ask for an alpha window on a Mac",
      'and sys.platform != "darwin"' in win.rsplit("glass", 1)[1], )
check("and the Windows branch it was written for is still there",
      'active_look() == "glass" and sys.platform != "win32"' in SRC)

# ---------------------------------------------------------------------
print("\n(11) handing an address to another application")
check("a scheme that is not a scheme is refused before anything is run",
      re.match(r"^[a-z][a-z0-9+.\-]*$", "discord")
      and not re.match(r"^[a-z][a-z0-9+.\-]*$", "-x")
      and r'^[a-z][a-z0-9+.\-]*$' in SRC)
with Pretend("darwin"):
    check("what is remembered is Launch Services, not the Windows shell",
          B.Browser._shell_handler() == "mac-open")
with Pretend("win32"):
    check("and on Windows it is still windows-shell",
          B.Browser._shell_handler() == "windows-shell")
shell = method_source("Browser", "_open_with_shell")
check("`open` is what reads that register", '"/usr/bin/open"' in shell)
check("the address is one argument, never a shell line",
      "startDetached(" in shell and "shell=True" not in shell)
check("os.startfile is not called on a Mac",
      shell.index('platform == "darwin"') < shell.index("os.startfile"))
check("and the branch is entered on both",
      'if sys.platform in ("win32", "darwin"):\n            return self._open_with_shell'
      in SRC)
apps = SCRATCH / "Applications"
(apps / "VLC.app/Contents/MacOS").mkdir(parents=True)
(apps / "VLC.app/Contents/MacOS/VLC").write_text("#!/bin/sh\n")
check("VLC inside its bundle is found, which no PATH would have",
      B.Browser._mac_player([apps]).endswith("VLC.app/Contents/MacOS/VLC"),
      B.Browser._mac_player([apps]))
check("and a machine with none says so",
      B.Browser._mac_player([SCRATCH / "nothing"]) == "")
check("the video hand-off really asks it",
      "self._mac_player()" in method_source("Browser",
                                            "play_externally"))
progs = [n for n in ast.walk(TREE) if isinstance(n, ast.Assign)
         and any(getattr(t, "id", "") == "EXTERNAL_PROGRAMS"
                 for t in n.targets)]
check('"open with" offers `open` on a Mac and none of the Linux names',
      progs and '"open"' in ast.get_source_segment(SRC, progs[0])
      and "nautilus" in ast.get_source_segment(SRC, progs[0]))

# ---------------------------------------------------------------------
print("\n(12) the libraries, where there is no dnf and no pkexec")
for name, want in (("_lib_check_cmd", ["-m", "pip", "list", "--outdated"]),
                   ("_lib_upgrade_cmd", ["-m", "pip", "install",
                                         "--upgrade"])):
    with Pretend("darwin") as fake:
        prog, args = getattr(B.Browser, name)(browser)
    check("%s uses pip there" % name,
          prog == sys.executable and args[:len(want)] == want, (prog, args))
with Pretend("darwin"):
    check("no root is asked for on a Mac",
          "pkexec" not in B.Browser._lib_upgrade_cmd(browser)[0])
with Pretend("linux"):
    check("on Linux it is still dnf and pkexec",
          B.Browser._lib_check_cmd(browser)[0] == "dnf"
          and B.Browser._lib_upgrade_cmd(browser)[0] == "pkexec")
with Pretend("darwin"):
    check("pip saying nothing is not 'you are up to date'",
          B.Browser._lib_found_updates(browser, 1, "") is None)
    check("and a package it names is",
          B.Browser._lib_found_updates(
              browser, 0, "%s 1.0 2.0 wheel" % B.LIB_PIP[0]) is True)

# ---------------------------------------------------------------------
print("\n(13) the two things main() only does on a Mac")
main = source_of("main")
check("the app icon is the .icns", 'icon = "icon.icns"' in main)
check("...and only there",
      main.index('platform == "darwin"') < main.index('"icon.icns"'))
check("the .ico line the Windows port looks for is untouched",
      'icon = "icon.ico" if sys.platform == "win32" else "icon.svg"' in main)
check("Fusion is used there too, so a dark theme keeps dark furniture",
      'if sys.platform in ("win32", "darwin"):\n        # Qt picks the native'
      in main and 'app.setStyle("Fusion")' in main)

# ---------------------------------------------------------------------
print("\n(13b) will a call work here, asked the way a Mac answers it")
sys.path.insert(0, str(HERE))
import calls  # noqa: E402

real_calls_sys = calls.sys
try:
    calls.sys = Fake()
    calls.sys.platform = "darwin"
    check("the window server is not a thing to look up in the environment",
          calls.session() == "quartz", calls.session())
    IMAGES = ["/usr/lib/libSystem.B.dylib",
              "/opt/h/lib/python3.12/site-packages/PyQt6/Qt6/lib/"
              "QtWebEngineCore.framework/Versions/A/QtWebEngineCore",
              "/usr/lib/libobjc.A.dylib"]
    lib = calls.engine_lib(images=IMAGES)
    check("the engine is found in dyld's list, where there is no /proc",
          lib and "QtWebEngineCore" in str(lib), lib)
    check("...and a process without one says so rather than guessing",
          calls.engine_lib(images=["/usr/lib/libSystem.B.dylib"]) is None)
    check("the two dyld calls are the ones that read it",
          "_dyld_image_count" in source_of_file(calls, "mac_images")
          and "_dyld_get_image_name" in source_of_file(calls, "mac_images"))
    facts = calls.engine_facts(lib=str(lib))
    check("a pip wheel is still recognised as one", facts["wheel"], facts)
    check("and the 200 MB of Mach-O is NOT scanned for PipeWire there",
          facts["pipewire"] is False and facts["portal"] is False, facts)

    page = {"displayMedia": True, "h264send": True, "h264recv": True,
            "playH264": True, "playAac": True}
    def verdict(screen):
        return dict((k, lvl) for lvl, k, _ in
                    calls.verdicts(page, facts=facts, kind="quartz",
                                   screen=screen)).items()
    allowed = dict((k, lvl) for lvl, k, _ in calls.verdicts(
        page, facts=facts, kind="quartz", screen=True))
    denied = dict((k, lvl) for lvl, k, _ in calls.verdicts(
        page, facts=facts, kind="quartz", screen=False))
    unknown = dict((k, lvl) for lvl, k, _ in calls.verdicts(
        page, facts=facts, kind="quartz", screen=None))
    check("granted Screen Recording, sharing is said to work",
          allowed.get("callShareOk") == "ok", allowed)
    check("NOT granted, it is bad news and not a shrug",
          denied.get("callNoScreenPerm") == "bad", denied)
    check("...and it does not claim sharing is fine",
          "callShareOk" not in denied, denied)
    check("unreadable is a warning, not a yes and not a no",
          unknown.get("callScreenUnknown") == "warn", unknown)
    check("Wayland's PipeWire verdict never reaches a Mac",
          "callNoPipewire" not in allowed
          and "callNoPipewire" not in denied, (allowed, denied))
    check("it asks the system only when that branch is really taken",
          calls.mac_screen_recording(check=lambda: False) is False
          and calls.mac_screen_recording(check=lambda: None) is None)
    check("the question is asked without prompting him",
          "CGPreflightScreenCaptureAccess"
          in source_of_file(calls, "mac_screen_recording"))
finally:
    calls.sys = real_calls_sys
check("on Linux the session is still read out of the environment",
      calls.session() in ("wayland", "x11", "unknown"), calls.session())
for key in ("callNoScreenPerm", "callScreenUnknown"):
    check("%s exists in both languages" % key,
          B.UI_STRINGS["en"].get(key) and B.UI_STRINGS["de"].get(key))
    check("...and the German one is German",
          B.UI_STRINGS["de"][key] != B.UI_STRINGS["en"][key])
check("both name where the tick box is",
      all("Screen Recording" in B.UI_STRINGS["en"][k]
          for k in ("callNoScreenPerm", "callScreenUnknown"))
      and all("Bildschirmaufnahme" in B.UI_STRINGS["de"][k]
              for k in ("callNoScreenPerm", "callScreenUnknown")))

# ---------------------------------------------------------------------
print("\n(14) the words, in both languages")
# The Mac edition replaces a handful of settings rows whose text names a
# Linux program, and the port manifest is what does it. These are the
# keys it has to find.
#
# This file is ported too, so it runs in both trees and the right
# assertion is not the same one in each: in the Linux repository the
# rows must STILL name the Linux programs, or the manifest's find
# strings stop matching and the port quietly leaves a Mac being told
# about systemd-inhibit; in the generated edition they must already be
# gone. Which tree this is, is a question the tree can answer.
MAC_EDITION = (HERE / "tools/mac_port.json").exists()
for key in ("awakeHint", "awakeNo", "mprisMissing", "sayMissing",
            "desktopNotifyHint"):
    check("%s exists in both languages" % key,
          B.UI_STRINGS["en"].get(key) and B.UI_STRINGS["de"].get(key))
if MAC_EDITION:
    print("  (this is the generated macOS edition)")
    check("the rows have been through the port",
          "caffeinate" in B.UI_STRINGS["en"]["awakeHint"]
          and "caffeinate" in B.UI_STRINGS["de"]["awakeHint"]
          and "caffeinate" in B.UI_STRINGS["en"]["awakeNo"])
    check("...and name nothing a Mac has not got",
          "systemd-inhibit" not in B.UI_STRINGS["en"]["awakeHint"]
          and "(spd-say)" not in B.UI_STRINGS["en"]["sayMissing"]
          and "notify-send" not in B.UI_STRINGS["en"]["desktopNotifyHint"]
          and "mpris.py" not in B.UI_STRINGS["en"]["mprisMissing"])
    check("in German too",
          "systemd-inhibit" not in B.UI_STRINGS["de"]["awakeHint"]
          and "(spd-say)" not in B.UI_STRINGS["de"]["sayMissing"]
          and "notify-send" not in B.UI_STRINGS["de"]["desktopNotifyHint"])
    check("the graphics-card row gives the macOS reason, not Linux's",
          "Metal" in B.UI_STRINGS["en"]["gpuNone"]
          and "Metal" in B.UI_STRINGS["de"]["gpuNone"]
          and "Only one graphics card" not in B.UI_STRINGS["en"]["gpuNone"])
else:
    print("  (this is the Linux repository)")
    check("the Linux text still names systemd-inhibit, for the "
          "manifest to find",
          "systemd-inhibit" in B.UI_STRINGS["en"]["awakeHint"]
          and "systemd-inhibit" in B.UI_STRINGS["en"]["awakeNo"])
    check("and spd-say", "spd-say" in B.UI_STRINGS["en"]["sayMissing"])
    check("and notify-send",
          "notify-send" in B.UI_STRINGS["en"]["desktopNotifyHint"])
    # the graphics-card row: gpu_cards() answers [] on darwin, so
    # Settings shows this line -- and here it gives Linux's reason,
    # which the port replaces with the macOS one. Both halves of that
    # substitution need the Linux text to still be exactly this.
    check("the graphics-card row still gives Linux's reason here, "
          "for the manifest to find",
          B.UI_STRINGS["en"]["gpuNone"]
          == "Only one graphics card here, so there is nothing to choose."
          and "nur eine Grafikkarte" in B.UI_STRINGS["de"]["gpuNone"])

# ---------------------------------------------------------------------
print("\n(15) somewhere to keep the bytecode")
# browser.py is 3.2 MB. Compiling it is ~470 ms on this box and loading
# the cached bytecode is ~11, so a launch that cannot write a cache
# pays half a second of pure compiler every time -- which is the normal
# outcome for a bundle under /Applications (root-owned) or one
# Gatekeeper has translocated (read-only).
env = {}
fake = Fake()
fake.platform = "linux"
fake.pycache_prefix = None
check("on this machine it does nothing at all",
      B._mac_pycache(env, fake, SCRATCH) == "" and env == {}
      and fake.pycache_prefix is None)
fake.platform = "darwin"
env = {}
got = B._mac_pycache(env, fake, SCRATCH)
check("on a Mac it names a folder of ours",
      got.endswith("Library/Caches/browser/pycache"), got)
check("...and it is really made, so the first import can use it",
      Path(got).is_dir(), got)
check("the variable is set, so a child process inherits it",
      env.get("PYTHONPYCACHEPREFIX") == got, env)
check("and this process is told directly, because the variable is read "
      "at interpreter start-up and we are past it",
      fake.pycache_prefix == got)
check("...and it is inside the scratch home it was given, "
      "not beside the source",
      got.startswith(str(SCRATCH)), got)
env2 = {"PYTHONPYCACHEPREFIX": str(SCRATCH / "his")}
fake.pycache_prefix = None
check("a prefix he set himself is left alone",
      B._mac_pycache(env2, fake, SCRATCH) == str(SCRATCH / "his")
      and env2["PYTHONPYCACHEPREFIX"] == str(SCRATCH / "his"))
check("nowhere to write is slow, not fatal",
      B._mac_pycache({}, fake, "/proc/nonexistent/nope") == "")
check("it really is called at import time", "\n_mac_pycache()\n" in SRC)
src = source_of("_mac_pycache")
check("and the reason is written down where the next person will look",
      "470" in src and "translocat" in src.lower())

# ---------------------------------------------------------------------
print("\n(16) one frame, on a screen that is not 60 Hz")
# The dock's magnification eased by a fixed 0.28 of the way left every
# 16 ms. On the 120 Hz display of every MacBook Pro since 2021 that
# timer ticks twice as often, so the bulge arrived in half the time --
# and nothing in the browser had ever asked the screen anything.
Dock = B.Dock
check("60 Hz still gets the 16 ms it was written with",
      Dock.frame_ms(60.0) == 16, Dock.frame_ms(60.0))
check("120 Hz ProMotion gets 8", Dock.frame_ms(120.0) == 8,
      Dock.frame_ms(120.0))
check("...and so does 120.000008, which is what a Mac really reports",
      Dock.frame_ms(120.000008) == 8)
check("a 144 Hz panel is floored to the 6 ms clamp",
      Dock.frame_ms(144.0) == 6, Dock.frame_ms(144.0))
check("240 Hz is not worth 240 repaints of a dock",
      Dock.frame_ms(240.0) == 6)
check("a 30 Hz screen is held at 20 ms, not 33",
      Dock.frame_ms(30.0) == 20)
check("a screen that will not say falls back to 60 Hz",
      Dock.frame_ms(0.0) == 16 and Dock.frame_ms(None) == 16
      and Dock.frame_ms("nonsense") == 16)
check("nothing in the file hardcodes a frame any more",
      "setInterval(16)" not in SRC)
step = method_source("Dock", "_step")
check("the ease is over real elapsed time, not over ticks",
      "time.monotonic()" in step and "self._ease_at" in step
      and "0.28" not in step)
check("and the rate is the old one re-expressed, so 60 Hz is unchanged",
      abs(B.Dock.EASE_RATE - 0.0205445) < 1e-6)
# 0.28 per 16 ms, as a rate: 1 - exp(-rate*16) must come back to 0.28
import math as _math
check("...which it provably is",
      abs((1.0 - _math.exp(-B.Dock.EASE_RATE * 16.0)) - 0.28) < 0.0005,
      1.0 - _math.exp(-B.Dock.EASE_RATE * 16.0))
check("an App Nap of a minute does not snap the bulge into place",
      "min(100.0" in step)
check("the frame is taken again when the ease starts, never per frame",
      "self.refresh_frame()" in method_source("Dock", "_ease_on")
      and "refresh_frame" not in method_source("Dock", "paintEvent")
      and "_refresh_hz" not in step)
check("and the ease still stops itself rather than spinning",
      "self._ease.stop()" in step)

# ---------------------------------------------------------------------
print("\n(17) the housekeeping chores, spread out and coarse")
# Four chores want thirty seconds and were built microseconds apart, so
# they fired in one event-loop iteration for the life of the window. On
# macOS that is also a timer the system cannot coalesce, and an App Nap
# releases all of them at once.
offsets = {n: B.housekeep_offset(n, 30000) for n in B.HOUSEKEEPING}
check("every chore has its own slot in the interval",
      len(set(offsets.values())) == len(B.HOUSEKEEPING), offsets)
check("the first one is not delayed at all", offsets["watch"] == 0)
check("none of them waits more than half the interval",
      all(0 <= v < 15000 for v in offsets.values()), offsets)
check("the four that want thirty seconds no longer land together",
      len({offsets[n] for n in ("watch", "dllater", "track", "session")})
      == 4, offsets)
check("it is by name, so a restart does not shuffle them",
      B.housekeep_offset("session", 30000)
      == B.housekeep_offset("session", 30000))
check("a name it does not know waits for nothing",
      B.housekeep_offset("whatever", 30000) == 0)


class Clock:
    """A timer, as housekeep sees it. No Qt, no event loop."""

    def __init__(self):
        self.interval = None
        self.type = None
        self.started = False

    def setInterval(self, ms):
        self.interval = ms

    def setTimerType(self, kind):
        self.type = kind

    def start(self):
        self.started = True


def start(name, every, platform):
    clock, waits = Clock(), []
    off = B.housekeep(clock, every, name, platform=platform,
                      later=lambda ms, fn: waits.append(ms))
    return clock, waits, off


clock, waits, off = start("session", 30000, "linux")
check("on Linux it is setInterval and start, and nothing else",
      clock.interval == 30000 and clock.started and not waits and off == 0
      and clock.type is None)
clock, waits, off = start("session", 30000, "win32")
check("Windows is untouched too",
      clock.started and not waits and clock.type is None)
clock, waits, off = start("session", 30000, "darwin")
check("on a Mac the chore is handed a slack of a second to be grouped in",
      clock.type == B.Qt.TimerType.VeryCoarseTimer, clock.type)
check("...and starts in its own slot rather than at once",
      waits == [off] and off > 0 and not clock.started, (waits, off))
check("the interval itself is unchanged: nothing runs less often",
      clock.interval == 30000)
clock, waits, off = start("watch", 30000, "darwin")
check("the chore whose slot is zero just starts",
      clock.started and not waits and off == 0
      and clock.type == B.Qt.TimerType.VeryCoarseTimer)
hk = source_of("housekeep")
check("a window closed inside its own offset is not a crash",
      "sip.isdeleted(timer)" in hk)
check("and why any of this exists is written down",
      "App Nap" in hk and "coalesc" in hk.lower())
for name in ("watch", "dllater", "form", "lockidle", "desk", "track",
             "session", "snapshot"):
    check('the "%s" chore really goes through it' % name,
          'housekeep(self._%s' % {"watch": "watch_timer",
                                  "dllater": "dl_later",
                                  "form": "form_timer",
                                  "lockidle": "lock_timer_idle",
                                  "desk": "desk_timer",
                                  "track": "track_timer",
                                  "session": "session_timer",
                                  "snapshot": "snap_timer"}[name] in SRC)
check("the one-second download tick is deliberately left precise",
      "housekeep(self._dl_timer" not in SRC
      and "self._dl_timer.setInterval(1000)" in SRC)

# ---------------------------------------------------------------------
print("\n(18) one ps for every renderer, not one per tab")
# There is no /proc on a Mac, so per-tab memory comes out of ps -- and
# both places that want it walk every tab. Ten tabs was ten fork/exec
# pairs per pass, on the UI thread, every thirty seconds.
PS_MANY = ("11423 123456 01:23.45\n"
           "11424  98765 00:04.10\n"
           "11425    512 12:00:30.00\n")
rows = B.mac_cost_rows(PS_MANY)
check("every line of a multi-pid listing is read",
      sorted(rows) == [11423, 11424, 11425], sorted(rows))
check("rss is kibibytes", rows[11423]["bytes"] == 123456 * 1024)
check("mm:ss.ff is seconds", abs(rows[11424]["seconds"] - 4.10) < 0.001,
      rows[11424])
check("and hh:mm:ss too",
      abs(rows[11425]["seconds"] - (12 * 3600 + 30)) < 0.001, rows[11425])
check("a short or broken line is skipped, not guessed at",
      B.mac_cost_rows("11423 123456\nrubbish\n\n") == {}
      and B.mac_cost_rows("") == {} and B.mac_cost_rows(None) == {})
check("priming does nothing at all on this machine",
      B.mac_cost_prime([1, 2, 3]) == {})
primed = B.mac_cost_prime([11423, 11424], out=PS_MANY)
check("fed ps's own output it answers for all of them",
      sorted(primed) == [11423, 11424, 11425])
check("...and the one-pid question is then free",
      B._mac_process_cost(11423) == {"pid": 11423,
                                     "bytes": 123456 * 1024,
                                     "seconds": 83.45},
      B._mac_process_cost(11423))
B.mac_cost_prime([11423], out=PS_MANY, now=B.time.monotonic() - 60.0)
check("a stale batch is not used: an old number is worse than a slow one",
      B._mac_process_cost(11423, out="123456 01:23.45")["seconds"] == 83.45
      and B.MAC_COST_TTL <= 1.0)
check("nothing is asked for an empty list of tabs",
      B.mac_cost_prime([], out=PS_MANY) == {}
      and B.mac_cost_prime([0, None], out=PS_MANY) == {})
prime = source_of("mac_cost_prime")
check("ps is given the whole list in one go",
      '"-o", "pid=,rss=,time="' in prime and '","' in prime)
check("and both callers that walk every tab prime it",
      "mac_cost_prime(pid for _i, _v, pid in tabs)" in SRC
      and "mac_cost_prime(pids.values())" in SRC)
check("the single-pid reader still works with no batch at all",
      B._mac_process_cost(999999, out="  2048 00:01.50")
      == {"pid": 999999, "bytes": 2048 * 1024, "seconds": 1.5})

# ---------------------------------------------------------------------
print("\n(19) no Linux flag reaches the Mac")
# --disable-gpu-compositing cost the Linux edition about 20 fps in
# fullscreen video. The point of this section is not today's flag set:
# it is that a flag added for Linux in three years cannot be inherited.
forbidden = B.MAC_FORBIDDEN_FLAGS
check("the list names the one that actually cost frames",
      "--disable-gpu-compositing" in forbidden)
check("...and the software and translation-layer paths",
      "--disable-gpu" in forbidden and "--use-angle=gl" in forbidden
      and "--use-angle=swiftshader" in forbidden
      and "--disable-gpu-rasterization" in forbidden)
check("...and the ones that would put the engine in one process",
      "--single-process" in forbidden and "--in-process-gpu" in forbidden)
check("...and VA-API, which is Linux's name for a thing macOS does unasked",
      all(f in forbidden for f in ("VaapiVideoDecoder", "VaapiOnNvidiaGPUs",
                                   "--ignore-gpu-blocklist")))
check("...and anything that would take Metal away",
      "--disable-features=Metal" in forbidden
      and "QT_OPENGL" in B.MAC_FORBIDDEN_ENV
      and "QSG_RHI_BACKEND" in B.MAC_FORBIDDEN_ENV)


def flagset(platform):
    """The flags the browser itself would put on the engine there."""
    real_platform = B.sys.platform
    real_env = B.os.environ
    kept = dict(real_env)
    try:
        with Pretend(platform):
            B.os.environ = dict(kept)
            B.os.environ.pop("QTWEBENGINE_CHROMIUM_FLAGS", None)
            B._install_proxy_flags()
            return B.os.environ.get("QTWEBENGINE_CHROMIUM_FLAGS", "")
    finally:
        B.os.environ = real_env
        B.sys.platform = real_platform


mac_flags = flagset("darwin")
bad = [f for f in forbidden if f in mac_flags]
check("the real darwin flag set contains none of them", not bad,
      (bad, mac_flags[:200]))
check("...and it does ask for the one switch that is worth asking for",
      "PlatformHEVCDecoderSupport" in mac_flags, mac_flags[:200])
lin_flags = flagset("linux")
check("while Linux keeps its VA-API features",
      "VaapiVideoDecoder" in lin_flags, lin_flags[:200])

# the lint: a forbidden name in the source must be inside a darwin
# guard. An unguarded one is the Windows edition's rot, early.
GUARDS = ('sys.platform != "darwin"', 'sys.platform == "linux"',
          'sys.platform not in ("darwin"', 'MAC_FORBIDDEN',
          "MAC_DROP_FLAGS")
# the two places that name these flags as data rather than use them:
# the list above, and the curated switches Settings offers (which
# safe_flags() filters for a Mac -- see below)
DATA = []
lines = SRC.splitlines()
for first, last in (("MAC_FORBIDDEN_FLAGS = (", ")"),
                    ("MAC_FORBIDDEN_ENV = (", ")"),
                    ("    SAFE_FLAGS = (", "    )"),
                    ("    MAC_DROP_FLAGS = (", "    )")):
    for i, line in enumerate(lines):
        if line.startswith(first):
            for j in range(i, min(len(lines), i + 60)):
                if lines[j] == last or lines[j].rstrip() == last:
                    DATA.append((i, j))
                    break
            break
check("the lint found both lists and both catalogues to skip",
      len(DATA) == 4, DATA)


def is_data(i):
    return any(a <= i <= b for a, b in DATA)


unguarded = []
for i, line in enumerate(lines):
    if line.lstrip().startswith("#") or is_data(i):
        continue
    for flag in forbidden:
        if flag in line:
            window = "\n".join(lines[max(0, i - 14):i + 1])
            if not any(g in window for g in GUARDS):
                unguarded.append((i + 1, flag, line.strip()[:60]))
check("no forbidden flag appears outside a darwin guard", not unguarded,
      unguarded)
for var in ("LIBVA_DRIVER_NAME", "NVD_BACKEND"):
    check("%s is only set where there is a /proc to have asked" % var,
          '"%s"' % var not in SRC.split('Path("/proc/driver/nvidia/version")'
                                        ".exists()")[0])
env_lines = [line for i, line in enumerate(lines)
             if not is_data(i) and "MAC_FORBIDDEN" not in line]
check("nothing in the file sets QT_OPENGL, QSG_* or a Quick backend",
      not any(('"%s"' % v) in "\n".join(env_lines) for v in
              ("QT_OPENGL", "QSG_RHI_BACKEND", "QT_QUICK_BACKEND",
               "QSG_RENDER_LOOP")))

# ...and the switches Settings offers him. A tick box that cannot do
# anything is worse than no tick box, and one of them is worse again.
mac_switches = [f for f, _why in B.Browser.safe_flags("darwin")]
lin_switches = [f for f, _why in B.Browser.safe_flags("linux")]
check("Linux is offered every one of the curated flags, as before",
      len(lin_switches) == len(B.Browser.SAFE_FLAGS) == 10,
      len(lin_switches))
check("a Mac is not offered VA-API, which is not its interface",
      not any("Vaapi" in f for f in mac_switches), mac_switches)
check("...nor the ChromeOS direct decoder",
      not any("UseChromeOSDirectVideoDecoder" in f for f in mac_switches))
check("...nor --ignore-gpu-blocklist, which there switches on every "
      "blocked GPU feature and not only the decoder",
      "--ignore-gpu-blocklist" not in mac_switches)
check("the seven that do work there are still offered",
      len(mac_switches) == 7
      and "--enable-gpu-rasterization" in mac_switches
      and "--enable-smooth-scrolling" in mac_switches
      and "--disable-background-timer-throttling" in mac_switches,
      mac_switches)
check("Windows keeps exactly what it had",
      B.Browser.safe_flags("win32") == B.Browser.SAFE_FLAGS)
check("and every place that reads the catalogue goes through it",
      "for flag, why in self.safe_flags()" in SRC
      and "for one, _why in self.safe_flags()" in SRC
      and "for flag, why in self.browser.safe_flags()" in SRC
      and "in self.SAFE_FLAGS" not in SRC)

# ---------------------------------------------------------------------
print("\n(20) nothing of his lands where iCloud would sync it")
# iCloud Drive syncs ~/Desktop and ~/Documents when "Desktop &
# Documents Folders" is on, which is a tick box in the setup
# assistant. A browser profile being uploaded while he browses is a
# stall with no visible cause.
ICLOUD = ("/Documents", "/Desktop", "Mobile Documents", "iCloud")
mac_home = build("darwin", {})["BROWSER_HOME"]
check("the data folder is in Application Support, which iCloud never touches",
      "Library/Application Support" in mac_home
      and not any(bit in mac_home for bit in ICLOUD), mac_home)
mac_sys = Fake()
mac_sys.platform = "darwin"
mac_sys.pycache_prefix = None
check("the bytecode cache is under Library/Caches, which it never touches "
      "either",
      "Library/Caches" in B._mac_pycache({}, mac_sys, SCRATCH))
check("and so is the Widevine link, which is the only other thing "
      "written outside the data folder",
      "Library/Caches" in source_of("_space_free"))
check("downloads go to ~/Downloads, which is not a synced folder",
      str(B.DOWNLOAD_DIR).endswith("Downloads")
      and not any(bit in str(B.DOWNLOAD_DIR) for bit in ICLOUD))
check("and sorted downloads stay inside it",
      "base / kind" in method_source("Browser", "download_dir_for"))

# ---------------------------------------------------------------------
print("\n(21) what the browser paints itself, four times over")
# A 2x framebuffer is four times the pixels for everything the Qt
# layer draws by hand. These are the per-paint costs that were found
# and what was done about them.
check("there is no QGraphicsEffect anywhere: a blur or a drop shadow "
      "on a raster surface is CPU work per frame",
      not any(name in SRC for name in
              ("QGraphicsBlurEffect", "QGraphicsDropShadowEffect",
               "setGraphicsEffect", "QGraphicsOpacityEffect")))
glass = method_source("Dock", "_glass")
check("the dock's island is painted once into a pixmap, not every frame",
      "QPixmap(" in glass and "self._glass_cache" in glass)
check("...at the screen's own ratio, so 2x is sharp rather than soft",
      "devicePixelRatioF()" in glass and "setDevicePixelRatio" in glass)
check("...and a window dragged between screens gets a new one",
      "ratio" in glass.split("key = ")[1].split("\n")[0])
check("the palette is part of the key, so a theme switch repaints it",
      "ACTIVE_THEME" in glass)
paint = method_source("Dock", "paintEvent")
check("paintEvent blits the island instead of calling _paint_glass",
      "drawPixmap(0, 0, self._glass())" in paint
      and "_paint_glass" not in paint)
check("the twelve rounded rectangles of the shadow are still what "
      "_paint_glass does -- just not per frame",
      "for step in range(self.SHADOW, 0, -1)"
      in method_source("Dock", "_paint_glass"))
icon = method_source("Dock", "_icon_at")
check("an icon is scaled once per size it is drawn at, not once per frame",
      "self._icon_cache" in icon and "scaled(" in icon)
check("...also at the screen's ratio", "devicePixelRatioF()" in icon)
check("the cache cannot grow without bound", "clear()" in icon)
check("and a new set of pins drops the old icons",
      "self._icon_cache = {}" in method_source("Dock", "set_pins"))

# ---------------------------------------------------------------------
print("\n(22) the Linux programs that had no Mac half yet")
# Found by walking every shutil.which() in the file against what that
# platform actually has. These are features, not flags: a browser that
# says "nothing here can open that" about every file it downloads is
# not a browser with a cosmetic difference.
with Pretend("darwin"):
    with only_which({"open": "/usr/bin/open"}) as looked:
        opener = B.Browser._desktop_opener()
check("the Open button on a download reaches for `open` on a Mac",
      opener == "/usr/bin/open" and looked == ["open"], (opener, looked))
with Pretend("darwin"):
    with only_which({}):
        bare = B.Browser._desktop_opener()
check("...and falls back to the absolute path, which every Mac has",
      bare == "/usr/bin/open", bare)
with only_which({"xdg-open": "/usr/bin/xdg-open"}) as looked:
    lin = B.Browser._desktop_opener()
check("Linux still asks for xdg-open and nothing else",
      lin == "/usr/bin/xdg-open" and looked == ["xdg-open"], (lin, looked))
check("xdg-open is not run anywhere else without a branch",
      SRC.count('shutil.which("xdg-open")') == 1)
check("and the download code goes through it",
      "opener = self._desktop_opener()" in SRC)
check("the external-program list already had its Mac half",
      '("mpv", "vlc", "open") if sys.platform == "darwin"' in SRC)
check("...and an address for another application goes to Launch "
      "Services before the Linux guesses are ever consulted",
      'if sys.platform in ("win32", "darwin"):\n'
      '            return self._open_with_shell('
      in method_source("Browser", "open_with_app"))
# the three that are honestly Linux-only, and are PORT.md's business
check("the QR code has its own generator, so qrencode is optional",
      "image = self.qr_image(text)" in method_source("Browser", "qr_code")
      and (HERE / "qr.py").exists())
check("hyprctl is only the automatic half of game mode",
      SRC.count('shutil.which("hyprctl")') == 1
      and 'shutil.which("hyprctl")' in method_source("Browser",
                                                     "game_mode_tick"))
check("kdeconnect-cli is one of three ways to reach the phone",
      SRC.count('shutil.which("kdeconnect-cli")') == 2
      and "def qr_code" in SRC and (HERE / "phone.py").exists())

print("\n%d checks failed" % len(fails))
if fails:
    for f in fails:
        print("  - " + f)
shutil.rmtree(SCRATCH, ignore_errors=True)
sys.exit(1 if fails else 0)
