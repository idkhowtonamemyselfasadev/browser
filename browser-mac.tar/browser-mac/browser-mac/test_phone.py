#!/usr/bin/env python3
"""The other end of the Android edition's "Send to the desktop".

The phone's half has been finished for a while: it posts the page in
front of it to `http://<host>:8766/open?url=...`. The desktop browser
had nothing listening on any network at all, so the feature had no
other end. This proves the ear that was added, and — more to the point
— proves the four things that make an open port on the home network an
acceptable idea: only http and https addresses, only his own network,
twelve a minute, and nothing on the port but "open a tab".

Offscreen, scratch data. The listener is bound to port 0 (a free one
the kernel picks), so this never fights whatever else on the box has
8766, and the real URLs it carries are the local test server's — the
test opens no page off this machine.
"""
import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

os.environ["QT_QPA_PLATFORM"] = "offscreen"
os.environ["BROWSER_NO_LIB_CHECK"] = "1"
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE / "tests"))

import harness as H  # noqa: E402
B = H.boot()
import phone  # noqa: E402

fails = []


def check(what, ok, detail=""):
    print(("  ok   " if ok else "  FAIL ") + what
          + (("  <" + str(detail) + ">") if detail != "" else ""))
    if not ok:
        fails.append(what)


def post(port, path, body=b"", token=None, method="POST", headers=None):
    """One request, exactly as the Android edition makes it."""
    req = urllib.request.Request("http://127.0.0.1:%d%s" % (port, path),
                                 data=body if method == "POST" else None,
                                 method=method)
    req.add_header("Content-Type", "text/plain; charset=utf-8")
    for name, value in (headers or {}).items():
        req.add_header(name, value)
    if token is not None:
        req.add_header("X-Token", token)
    try:
        with urllib.request.urlopen(req, timeout=5) as r:
            return r.status, json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read() or b"{}")
        except ValueError:
            return e.code, {}


print("=== what address may be opened ===")
for good in ("http://example.com/a?b=c", "https://modrinth.com/mod/sodium",
             "http://192.168.1.50:8123/", "https://de.wikipedia.org/wiki/K1"):
    check("takes %s" % good, phone.clean_url(good) == good)
check("a bare host is read as https",
      phone.clean_url("example.com/x") == "https://example.com/x")
check("whitespace around it is not an error",
      phone.clean_url("  https://x.de  ") == "https://x.de")
for bad in ("javascript:alert(1)", "file:///etc/passwd", "file:///home/user",
            "data:text/html,<script>x()</script>", "chrome://settings",
            "about:config", "qrc:/x", "ftp://host/f", "view-source:http://x",
            "http://", "https:///path", "", "   ", "{\"op\": \"tabs\"}"):
    check("refuses %r" % bad, phone.clean_url(bad) == "", phone.clean_url(bad))
check("refuses a newline inside it",
      phone.clean_url("http://x.de/a\nHost: y") == "")
check("refuses one longer than the cap",
      phone.clean_url("http://x.de/" + "a" * phone.URL_MAX) == "")

print()
print("=== who may ask ===")
for home in ("127.0.0.1", "::1", "192.168.1.44", "10.0.0.5", "172.20.1.1",
             "fe80::1", "::ffff:192.168.1.9", "fd00::1"):
    check("%s is his own network" % home, phone.is_home(home) is True)
for out in ("8.8.8.8", "1.1.1.1", "93.184.216.34", "2606:4700::1111",
            "not-an-address", ""):
    check("%s is not" % out, phone.is_home(out) is False)
# ipaddress counts the documentation ranges as private too (they are
# not globally reachable), and for "may this host send me a tab" that
# is the right side to be on -- noted here so the list above is not
# read as a claim that every non-RFC1918 address is refused
check("the documentation range counts as not-the-internet",
      phone.is_home("203.0.113.7") is True)

print()
print("=== the rules, without a socket ===")
drop = phone.Drop(port=0)
code, answer = drop.offer("192.168.1.44", "https://example.com/a")
check("a page from the phone is taken", (code, answer["ok"]) == (200, True))
check("...and is waiting, not opened", list(drop.waiting)
      == ["https://example.com/a"])
code, answer = drop.offer("8.8.8.8", "https://example.com/b")
check("the internet gets a 403",
      (code, answer.get("error")) == (403, "not-home"))
code, answer = drop.offer("192.168.1.44", "javascript:alert(1)")
check("a javascript: URL gets a 400",
      (code, answer.get("error")) == (400, "bad-url"))
code, answer = drop.offer("192.168.1.44", "file:///etc/shadow")
check("a file: URL gets a 400",
      (code, answer.get("error")) == (400, "bad-url"))
check("neither of those is waiting", len(drop.waiting) == 1)
check("take() hands them over in order",
      drop.take() == ["https://example.com/a"])
check("...and the list is empty after it", drop.take() == [])

flood = phone.Drop(port=0, rate=3)
codes = [flood.offer("10.0.0.2", "https://x.de/%d" % i)[0] for i in range(6)]
check("a dozen a minute, then 429", codes == [200, 200, 200, 429, 429, 429],
      codes)
check("and only the ones it took are waiting", len(flood.waiting) == 3)

locked = phone.Drop(port=0, token="s3cret")
check("with a token set, no token is a 403",
      locked.offer("10.0.0.2", "https://x.de")[0] == 403)
check("the wrong token is a 403",
      locked.offer("10.0.0.2", "https://x.de", "nope")[0] == 403)
check("the right token is taken",
      locked.offer("10.0.0.2", "https://x.de", "s3cret")[0] == 200)
check("...in the query as well",
      locked.offer("10.0.0.2", "https://x.de", "",
                   {"token": ["s3cret"]})[0] == 200)
check("without a token set, nothing is asked for",
      phone.Drop(port=0).offer("10.0.0.2", "https://x.de")[0] == 200)

print()
print("=== on a real port, in the phone's own wire format ===")
live = phone.Drop(port=0)
live.start()
port = live.port
check("the port is open", port > 0 and live.status()["running"] is True)
url = "https://example.com/from-the-phone?a=b&c=d"
code, answer = post(port, "/open?url=" + urllib.parse.quote(url, safe=""),
                    url.encode())
check("POST /open?url=... is taken", (code, answer.get("ok")) == (200, True))
check("...and it is the URL that arrived", list(live.waiting) == [url])
live.take()
code, answer = post(port, "/open", b"https://example.com/body-only")
check("the URL in the body alone works too",
      (code, answer.get("ok")) == (200, True))
check("...and arrives whole",
      live.take() == ["https://example.com/body-only"])
code, answer = post(port, "/open", b"javascript:alert(1)")
check("a javascript: URL over the wire is a 400",
      (code, answer.get("error")) == (400, "bad-url"))
code, answer = post(port, "/ping", method="GET")
check("GET /ping answers", (code, answer.get("ok")) == (200, True))
check("...and says nothing about this machine",
      set(answer) == {"ok", "app"}, sorted(answer))
code, _ = post(port, "/nonsense", method="GET")
check("any other GET is a 404", code == 404)
code, answer = post(port, "/open", json.dumps({"op": "tabs"}).encode())
check("a bridge op posted at it is refused",
      (code, answer.get("error")) == (400, "bad-url"))
code, _ = post(port, "/js", b"alert(1)")
check("there is no other path to post to", code == 404)
code, _ = post(port, "/open", b"x" * (phone.BODY_MAX + 10))
check("an oversized body is refused", code == 413)
# the one hole a loopback ear has: a website open in this very browser
# can fetch() the port, and its peer address is 127.0.0.1
code, answer = post(port, "/open", b"https://evil.example/pop",
                    headers={"Origin": "https://evil.example"})
check("a website's fetch() is refused",
      (code, answer.get("error")) == (403, "from-a-page"))
code, answer = post(port, "/open", b"https://evil.example/pop",
                    headers={"Sec-Fetch-Site": "cross-site",
                             "Sec-Fetch-Mode": "no-cors"})
check("...however it dresses itself up",
      (code, answer.get("error")) == (403, "from-a-page"))
check("and nothing of a page's got through", list(live.waiting) == [])
code, answer = post(port, "/ping", method="GET",
                    headers={"Sec-Fetch-Mode": "cors"})
check("a page cannot even ping it",
      (code, answer.get("error")) == (403, "from-a-page"))
check("the phone itself still gets through after all that",
      post(port, "/open", b"https://example.com/still-fine")[0] == 200)
live.take()
live.stop()
check("stopping closes the port", live.status()["running"] is False)
closed = True
try:
    post(port, "/ping", method="GET")
    closed = False
except Exception:
    closed = True
check("...and nothing answers on it any more", closed)

print()
print("=== the browser's side ===")
app = H.app()
srv = H.Server({"/sofa": "<title>Sofa</title><body>read me at the desk</body>"})
win = B.Browser()
win.resize(1200, 800)
win.show()
H.spin(300)
check("off until he switches it on", win.phone_drop_on() is False)
check("...so nothing is listening", win.phone_status()["running"] is False)
win.config["phoneDropPort"] = 0
check("switching it on opens a port", win.phone_drop(True) is True)
status = win.phone_status()
check("...and it says so", status["running"] is True and status["port"] > 0)
before = win.tabs.count()
sofa = srv.url("/sofa")
code, answer = post(status["port"],
                    "/open?url=" + urllib.parse.quote(sofa, safe=""),
                    sofa.encode())
check("a page sent from the phone is accepted",
      (code, answer.get("ok")) == (200, True))
H.wait_for(lambda: win.tabs.count() > before, timeout=6000)
check("...and lands in a tab", win.tabs.count() == before + 1,
      "%d -> %d" % (before, win.tabs.count()))
check("...which the window did not jump to",
      win.tabs.currentIndex() != win.tabs.count() - 1
      or win.tabs.count() == before + 1)
def urls():
    """What every tab is showing. A tab widget *is* the view here."""
    out = []
    for i in range(win.tabs.count()):
        w = win.tabs.widget(i)
        for one in (w, getattr(w, "view", None)):
            if one is not None and hasattr(one, "url"):
                out.append(one.url().toString())
                break
    return out


H.wait_for(lambda: any("/sofa" in u for u in urls()), timeout=8000)
check("the tab is on the page the phone sent",
      any("/sofa" in u for u in urls()), urls())
check("the browser counted it", win.phone_status()["taken"] == 1)
check("and it is in the arrivals list",
      [row["verdict"] for row in win.phone_status()["log"]] == ["ok"])
port = win.phone_status()["port"]
check("switching it off closes it", win.phone_drop(False) is False)
check("...really off", win.phone_status()["running"] is False)
gone = True
try:
    post(port, "/ping", method="GET")
    gone = False
except Exception:
    gone = True
check("...and the port no longer answers", gone)
check("the switch is remembered", win.config.get("phoneDrop") is False)
win.config["phoneDrop"] = True
win.config["phoneDropPort"] = 0
win.refresh_phone_drop()
check("the config alone brings it back",
      win.phone_status()["running"] is True)
win.config["phoneDrop"] = False
win.refresh_phone_drop()
check("...and takes it away again",
      win.phone_status()["running"] is False)

# a port belongs to the program, not to a window: a second window
# binding the same one would only ever be told it was taken
win.config["phoneDrop"] = True
win.config["phoneDropPort"] = 0
win.refresh_phone_drop()
held = win.phone_status()["port"]
second = B.Browser()
second.config["phoneDrop"] = True
second.config["phoneDropPort"] = held
said = []
second.flash = lambda text, ms=2600: said.append(text) or True
check("a second window does not fight for the port",
      second.refresh_phone_drop() is True)
check("...and says nothing at him about it", said == [], said)
check("...and did not open one of its own",
      second.phone_status()["running"] is False)
check("the first window still has it",
      win.phone_status()["running"] is True
      and win.phone_status()["port"] == held)
check("a page still arrives at the one that has it",
      post(held, "/open", b"https://example.com/one-ear")[0] == 200)
second.close()
win.config["phoneDrop"] = False
win.refresh_phone_drop()
check("and the ear is free again once it is switched off",
      B._phone_elsewhere(second) is False)
srv.stop()

print()
print("=== the words and the switch ===")
need = ("phoneDropName", "phoneDropHint", "phoneDropPortName",
        "phoneDropTokenName", "phoneDropTokenPh", "phoneDropOn",
        "phoneDropOff", "phoneDropBusy", "phoneDropMissing",
        "phoneDropCame")
missing_en = [k for k in need if not B.UI_STRINGS["en"].get(k)]
missing_de = [k for k in need if not B.UI_STRINGS["de"].get(k)]
check("every new word has an English", missing_en == [], missing_en)
check("...and a German", missing_de == [], missing_de)
same = [k for k in need
        # "Port" is the same word in German, which is not a missing
        # translation
        if B.UI_STRINGS["en"].get(k) == B.UI_STRINGS["de"].get(k)
        and k not in ("phoneDropPortName",)]
check("and they are really translated", same == [], same)
page = (HERE / "settings.html").read_text()
for one in ("phonedrop", "phonedropport", "phonedroptoken"):
    check("“%s” is in Settings" % one, 'id="%s"' % one in page)
check("Settings writes the switch through the one door",
      'bindSwitch("phonedrop", "phoneDrop")' in page)
check("the port goes through the number door",
      'bindNumber("phonedropport", "phoneDropPort")' in page)
check("the password box saves what is typed in it",
      'saveSetting("phoneDropToken"' in page)
check("and the empty box says what empty means, translated",
      "S.phoneDropTokenPh" in page)
check("the hint is translated on that page", "t_phoneDropHint" in page)

print()
if fails:
    print("FAILED %d" % len(fails))
    for row in fails:
        print("  - " + row)
    sys.exit(1)
print("all good")
