#!/usr/bin/env python3
"""Boot the real Browser offscreen against scratch data files, take a
screenshot if asked, and never go near your own vault."""
import atexit
import json
import os
import shutil
import sys
import tempfile
from pathlib import Path

os.environ["QT_QPA_PLATFORM"] = "offscreen"
# no browser booted for a test or a screenshot goes looking for library
# updates: a real dnf/pip per boot would be slow, would depend on what the
# distribution is shipping this morning, and could raise a toast over a
# window under assertion. runall.sh sets this for its own runs, but a bare
# `python3 test_wizard.py` (which stays up past LIB_FIRST_MS) would arm and
# fire a real check without it -- so it belongs here too.
os.environ.setdefault("BROWSER_NO_LIB_CHECK", "1")
def _sweep_old_scratch(prefix):
    """Take away the scratch directories of runs that are gone.

    At STARTUP, not at exit, and that is the whole point. The harness
    next door registers its tidy-up with atexit and that tidy-up is
    correct -- but atexit does not run when a process dies by a signal
    or calls os._exit, and 18 of the suites in here end with os._exit
    precisely to dodge a Qt teardown segfault. Every one of those, and
    every crash, leaked its directory. This file had no cleanup at all,
    which is why there were 835 of them.

    A run cleaning up after its dead predecessors survives all of that,
    because the cleaning is done by whoever comes next rather than by
    the process that made the mess.

    Why this matters more than disk: /tmp is a tmpfs here, so an
    abandoned profile is RAM taken away from the browser under test.
    3.6 GB of them is what six consecutive suites crashing with no
    failed check looks like -- a browser that cannot get memory dies in
    a way that reads as a bug in whatever it was doing. The harness
    docstring next door describes the same failure for disk; on a tmpfs
    the cost is RAM and the symptom is further from the cause.

    The PID goes in the name so liveness decides and not age: a sibling
    suite started a second ago is left alone.
    """
    parent = Path(tempfile.gettempdir())
    try:
        names = os.listdir(parent)
    except OSError:
        return
    for name in names:
        if not name.startswith(prefix):
            continue
        try:
            pid = int(name[len(prefix):].split("-", 1)[0])
        except ValueError:
            continue                  # no PID in it: not ours to judge
        if pid == os.getpid():
            continue
        try:
            os.kill(pid, 0)           # alive: leave it alone
        except ProcessLookupError:
            shutil.rmtree(parent / name, ignore_errors=True)
        except OSError:
            continue                  # another user's, or not permitted


_sweep_old_scratch("browsershot-")
SCRATCH = Path(tempfile.mkdtemp(prefix="browsershot-%d-" % os.getpid()))
atexit.register(lambda: shutil.rmtree(SCRATCH, ignore_errors=True))
os.environ["XDG_DATA_HOME"] = str(SCRATCH / "share")
os.environ["XDG_CONFIG_HOME"] = str(SCRATCH / "config")
os.environ["XDG_CACHE_HOME"] = str(SCRATCH / "cache")
sys.path.insert(0, str(Path(__file__).resolve().parent))
import browser as B  # noqa: E402

B.CONFIG_FILE = SCRATCH / "config.json"
B.HISTORY_FILE = SCRATCH / "history.json"
B.DOWNLOADS_FILE = SCRATCH / "downloads.json"
B.HOSTS_FILE = SCRATCH / "hosts.json"
B.BOOKMARKS_FILE = SCRATCH / "bookmarks.json"
SCRATCH.mkdir(parents=True, exist_ok=True)
# Vault Password is opt-in, and a scratch config is a fresh install, so
# it would default off and take the whole feature with it. Every suite
# in here is testing that feature: switch it on before Browser() reads
# it, which happens at profile-build time, not on first use.
if not B.CONFIG_FILE.exists():
    B.CONFIG_FILE.write_text(json.dumps({"vaultPassword": True}))
