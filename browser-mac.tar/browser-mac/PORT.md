# The macOS edition: what came across, what did not, and what is quick

Written 2026-10-26 on the owner's **server**. There is no Mac here and none
was borrowed. **Read the last two sections before telling anyone this
works.**

The edition lives in `browser-mac/` and is **generated**, not forked:
`browser-mac/tools/mac_port.py` reads `~/browser` and
`browser-mac/tools/mac_port.json` says what of this edition is its own.
It is the Windows port's script and manifest in the same shape, on
purpose — three editions kept in step by two ways of doing it is one
way too many.

## The one structural difference from the Windows port

**This edition has no hand-kept regions.** The Windows one has three,
for its zip updater, and they are the part of that port that rots — a
`_restrict_to_owner` call sat in the shared file for weeks with no
definition anywhere in it, and nothing found out, because on Linux the
branch is never taken.

So every difference a Mac needs went into `~/browser` behind a
`sys.platform == "darwin"` branch, where

* a person reading the Linux file can see it, and
* **`test_macbranch.py` can run it on this Linux box** — 250 checks,
  every darwin branch exercised with a `sys` of our choosing.

`mac_port.json: hand_regions` is `[]`, and `test_mac.py` asserts that it
still is. There are **38 darwin branch points** now, 35 in `browser.py`
and 3 in `calls.py`.

---

## What the Mac edition does differently, and why

| Thing | Linux | macOS | Why it is not cosmetic |
|---|---|---|---|
| Data folder | `~/.local/share/browser` | `~/Library/Application Support/browser` | where that platform keeps a program's own data |
| PATH | the shell's | `+ /opt/homebrew/{bin,sbin}`, `/usr/local/{bin,sbin}`, `~/.local/bin` | an app started from the Dock gets `/usr/bin:/bin:/usr/sbin:/sbin` and **no shell profile runs**, so `shutil.which` finds no mpv, ffmpeg, git or yt-dlp and every one of those features reports "not installed" on a machine that has them |
| Bytecode cache | `__pycache__` beside the source | `~/Library/Caches/browser/pycache`, via `PYTHONPYCACHEPREFIX` | a bundle in `/Applications` is root-owned and a quarantined one is run off a read-only image, so the folder beside `browser.py` is **not writable** — and recompiling 3.2 MB costs **470 ms measured here**, on every single launch |
| Screen awake | `systemd-inhibit` | `caffeinate -d -i -m -s -w <our pid>` | `-w` ties it to this process, so a browser that is killed outright cannot leave a Mac unable to sleep |
| Notifications | `notify-send` | `osascript`, text passed as `argv` | an AppleScript is a program; a page title with a quote in it built into one is an injection, not a notification |
| Read aloud | `spd-say -w <text>` | `say`, voice from a live `say -v ?`, text on **stdin** | a voice that is not installed fails at once, and a paragraph starting with `-` would be read as a flag |
| Tab cost | `/proc/<pid>/statm`+`stat` | `ps -o pid=,rss=,time=`, **one call for every renderer** | there is no `/proc`; and both callers walk every tab, so per-pid meant ten fork/exec pairs per pass on the UI thread |
| Open a download | `xdg-open` | `open` (Launch Services) | there is no `xdg-open` there. Without this the Open button said "nothing here can open that" about **every file the browser downloads** |
| Another application | guessed binary names | `open`, before the Linux guesses are consulted | an application there is a bundle in `/Applications`, not a name on the PATH. Stored as `mac-open`, not `windows-shell` |
| Video player | `mpv`/`vlc` on PATH | also `/Applications/{VLC,IINA,mpv}.app/Contents/MacOS/...` | same reason |
| DRM | `--widevine-path=<chrome's .so>` | the same, **through a symlink in `~/Library/Caches/browser`** | Qt splits `QTWEBENGINE_CHROMIUM_FLAGS` on spaces, and every Mac path to Chrome's CDM has one ("Google Chrome.app", "Application Support"). Without the link, DRM video is refused on a machine with a perfectly good CDM on its disk |
| Video decode | `--enable-features=Vaapi*` | HEVC switch only | VA-API is Linux's; macOS decodes through VideoToolbox unasked |
| Suite runner | `python`, `timeout` | `${BROWSER_PYTHON:-python3}`, `timeout`/`gtimeout`/neither | a stock Mac has **no unversioned `python`** and **no `timeout`** (that is GNU coreutils). `tools/runall.sh` is the script `macselftest.sh` runs *on the Mac*, and without this every one of its ninety tests would have read as a failure with "command not found" |
| Chromium flag switches | all ten offered | **seven** | three of the ten mean nothing there, and `--ignore-gpu-blocklist` is worse than nothing: it *is* honoured and switches on every GPU feature Chromium blocks for broken drivers, not only the decoder he wanted |
| Graphics card | picker, `DRI_PRIME`/NVIDIA offload | nothing, and the picker never opens | Metal hands a process its card; macOS keeps that choice nowhere a program may write |
| Glass look | translucent window | solid base, as on Windows | Quartz blurs behind a window only through an `NSVisualEffectView`, which Qt gives a `QMainWindow` no way to ask for — the alpha window is a plain hole to the desktop, and a surface with alpha and no opaque region makes the compositor blend the whole window every frame |
| Housekeeping timers | all started at once | each in its own slot, and `VeryCoarseTimer` | four chores wanted thirty seconds and were built microseconds apart. macOS cannot coalesce an exact timer, and App Nap releases everything it held in one go |
| Animation frame | a hardcoded 16 ms | the screen's own frame, 6–20 ms | every MacBook Pro since 2021 is 120 Hz, and a fixed-fraction ease on a timer that ticks twice as often arrives in half the time |
| Qt style | the sheet | Fusion | the native `macos` style draws scroll bars and tabs from the system appearance, so a dark theme comes out with light furniture |
| Libraries | `dnf` / `pkexec` | `pip`, no elevation | there is no dnf and nothing to elevate to |
| Icon | `icon.svg` | `icon.icns`, 11 sizes, fitted to the rounded square | the Dock draws a Qt-rendered SVG soft, and a hard-edged tile is the one program in the row that looks like it does not belong |
| Fonts | JetBrainsMono / DejaVu / Inter / Noto | `+ SF Mono, Menlo, Monaco` and `+ SF Pro Text, Helvetica Neue` | none of the Linux faces exist there, so the stack runs out and lands on Times and Courier |

Plus one fix that is not Mac-only: a scheme is now required to look
like a scheme (`^[a-z][a-z0-9+.-]*$`) before it is handed to Launch
Services or to the Windows shell, so `-x:something` cannot arrive as a
flag.

---

## Parity: every feature, with a verdict

The owner asked for **the whole browser**, so the rule here is: a feature is
either **present**, or it is in this table as `part` or `no` **with a
platform reason next to it**. Nothing is quietly missing. The source is
`~/browser/README.md`, walked end to end.

`done` = present, and carried either by shared code or by the darwin
branch named. `part` = reduced, and the row says what is reduced.
`no` = not there, and the row says what stops it.

### Browsing

| Feature | | Carried by / why not |
|---|---|---|
| Tabs, tab groups, group pills | done | shared Qt |
| Side panel (`Ctrl+Shift+Y`) | done | shared; a second view on the same `QWebEngineProfile` |
| Game mode (`Ctrl+Alt+G`) | **part** | the mode itself is shared and works. The **automatic** half — noticing a game came to the front — asks `hyprctl`, which is Hyprland's. macOS gives a sandboxed app no way to ask what is frontmost; the shortcut and the Settings switch are the whole feature there |
| Reader mode, link hints, highlights | done | shared, all in the page |
| Read aloud (`Ctrl+Alt+V`) | done | darwin: `say`, voice off a live `say -v ?`, text on stdin |
| Screenshots, whole-page shots | done | `capture.py`, pure Qt. **The password-field blur still happens before the shutter** — it is page-side (`page_guard.py` + the capture path), nothing platform about it |
| Minecraft server status (`Ctrl+Alt+J`) | done | a TCP socket and the game's own handshake |
| Command palette, cheat sheet, rebindable keys | done | shared |
| Virtual browsers, per-jar cookies and logins | done | shared; `QWebEngineProfile` per jar under `~/Library/Application Support/browser` |
| Address bar answers questions (maths, units, time zones, colours) | done | pure Python |
| Search keywords, suggestions from history/tabs/bookmarks | done | shared |
| Copy clean address (Markdown/HTML/title) | done | shared; clipboard is Qt's |
| Find in page | done | shared |
| Save any image (overlays, CSS, canvas, SVG) | done | shared, injected script |
| Tab search, reopen closed tab, recently closed | done | shared |
| The tab's own menu (pin, mute, lock, rename, duplicate, move, sort, close-others…) | done | shared |
| Account chooser (`Ctrl+Shift+M`) | done | shared |
| Private tab (`Ctrl+Shift+N`) | done | shared, off-the-record profile |
| Page zoom from the keyboard | **needs a Mac to confirm** | Qt maps `Ctrl` in a `QKeySequence` to Command, so `Cmd+`/`Cmd+-`/`Cmd+0` should be it. `Ctrl`+wheel is a raw modifier read and is question 7 below |
| Favourites panel, bookmarks bar, bookmark manager | done | shared |
| Smart address bar, fullscreen video, sleeping tabs | done | shared. **But what a video *is* depends on the engine build** — see §5h: a pip-installed engine has no H.264, HEVC or AAC, so Twitch and `.mp4` do not play on any hardware. `brew install pyqt` is the install that has them, and `install-mac.sh` says which one is there |
| A toolbar you pick | done | shared |

### Downloads and printing

| Feature | | Carried by / why not |
|---|---|---|
| Download manager, progress, pause/resume/cancel, history | done | shared |
| Where a file lands, and sorted downloads | done | `~/Downloads`, subfolders inside it. **Not** `~/Documents` or `~/Desktop` — see §iCloud below |
| **Open** a finished download | done | **new darwin branch**: `open`. This was broken — the only opener the code knew was `xdg-open` |
| Show in folder | done | `QDesktopServices.openUrl` on the folder, which is Finder there |
| Print / save as PDF (`Ctrl+P`) | done | **checked**: `QtPrintSupport.abi3.so` is in `pyqt6-6.11.0-cp310-abi3-macosx_10_14_universal2.whl`. The browser already treats it as optional (`HAVE_PRINTER`), because on some Linux distributions it is a separate package; on macOS it is simply there |
| Play a local file (the player page) | **part** | the page and the picker are shared and work. Whether the file plays is the codec question: an `.mp4` will not on a wheel-built engine, a `.webm` will. §5h |
| Virus scan of a download | **part** | optional either way: it asks for `clamscan`. `brew install clamav` provides it; without it the feature reports not-installed, exactly as on a Linux box without it |

### Privacy and security

| Feature | | Carried by / why not |
|---|---|---|
| Vault Password (the built-in manager) | done | the file vault is an encrypted file in the data folder |
| 1Password as the store | done | `op` is the same CLI there; `_mac_path_fix` is what makes it findable from the Dock |
| Master password, lock, idle lock | done | shared |
| Per-site proxy routing, fail-closed | done | shared; a local `QTcpServer` |
| Site permissions per origin/scheme/port | done | shared |
| History control | done | shared |
| Trust boundary (our pages privileged, websites never) | done | shared; the run key and `page_guard.py` |
| The privacy launch flags (`--no-pings`, DoH, host blocking, …) | done | all platform-neutral Chromium flags |
| Camera / microphone permission | done | `Info.plist` carries `NSCameraUsageDescription` and `NSMicrophoneUsageDescription`. **Without those keys macOS kills the process** rather than refusing politely — which is why they are there and why the install signs the bundle ad-hoc, so the grant sticks across rebuilds |
| Screen recording for a share | **part** | the browser **says** whether it is granted (`CGPreflightScreenCaptureAccess`) and never pretends. It cannot *ask*: macOS has no API and no `Info.plist` key for it, so it is a tick box in System Settings and the installer says so in words |

### Setup and configuration

| Feature | | Carried by / why not |
|---|---|---|
| Setup (the seven-step first run) | done | shared |
| Settings as a pane | done | shared |
| Start page, clock, quick links, backgrounds | done | shared; `backgrounds/` comes across |
| Userscripts | done | shared, per profile |
| 115 themes | done | shared; the font stacks are substituted |
| Looks: Classic, Taskbar, Dock, Circle | done | all four. The Dock look is also where the Retina and ProMotion work landed (§5) |
| Pinned sites = the start page's quick links | done | shared |
| Interface translations | done | shared |
| Single instance, links from other applications | done | `QLocalServer` over AF\_UNIX; `$TMPDIR` on macOS is already a per-user folder under `/var/folders` |
| System default browser | done | `Info.plist` carries `CFBundleURLTypes` for http/https and `CFBundleDocumentTypes` for HTML, so Launch Services offers it in System Settings → Desktop & Dock |
| Built-in updates | done | it is `git pull` plus a zip path for a copy with no `.git`. git comes from the Xcode Command Line Tools (`xcode-select --install`) or Homebrew |
| Library updates / install missing programs | done | darwin: `pip`, and no elevation. There is no `dnf` and nothing to `pkexec` to |
| Graphics card picker | **no** | Metal hands a process its card. macOS keeps that choice nowhere a program may write, so there is nothing a window could do: `gpu_cards()` answers `[]`, the picker is never opened, and the Settings row **now gives the macOS reason** in both languages. It used to inherit Linux's — *"Only one graphics card here, so there is nothing to choose"* — which is the wrong reason on any Mac and plainly false on one with an eGPU |
| Media keys / what-is-playing to the desktop | **no** | MPRIS is a D-Bus protocol of the Linux desktop. macOS has its own (`MPNowPlayingInfoCenter`), and **Qt gives a program no way to speak it** — there is no `QMediaMetaData` route to Now Playing and no PyQt binding for the framework. The settings row says exactly that instead of showing a switch that does nothing. The dock look's own transport (play/pause/skip for whatever page is making the sound) **does** work, because that is the browser driving the page, not the system driving the browser |
| Experimental engine pane | **no** | it renders through `web_engine.so`, built on the Linux machine. There is no Mac build, and `browser.py` already treats the module as optional |
| Send this tab to the phone | **part** | three routes exist: a QR code to point a phone at (works — `qr.py` has its own generator, `qrencode` is only an optimisation), the phone receiver (works, see below), and **KDE Connect (`kdeconnect-cli`), which is not a thing on macOS**. Two of three |
| Take a page off the phone (the receiver) | done | binds all interfaces, as it must. macOS asks once whether the app may accept incoming connections, and a "Deny" leaves the switch on and the feature dead with nothing saying why — so the Mac edition's settings row warns before he turns it on, in both languages |
| The calls panel / "will a call work here" | done | darwin half written: dyld's own image list instead of `/proc/self/maps`, `session()` answers `quartz`, and the screen question is the permission rather than the build |
| Agent bridge (`agent.py` / `agent_bridge.py`) | done | AF\_UNIX exists and `$TMPDIR` is per-user. **Unlike the Windows edition**, these come across |
| Dictionary lookup | **part** | an installed `dict` client first, an online source otherwise. macOS has no `dict`, so it takes the online path and the entry says which of the two it was — the same behaviour as a Linux box without `dict` |
| The in-app security checks (`invariant_checks.py`) | done | they come across and `tools/runall.sh` runs them |
| The monthly GitHub security job | **no** | it is a workflow in the Linux repository, and this edition has never been pushed anywhere. There is nothing for Actions to run. When there is a `browser-mac` repository it is a copy of one YAML file |

### Things that deliberately do not come across as files

| File | Why |
|---|---|
| `mpris.py` | see the media-keys row above |
| `engine_pane.py` | no Mac build of `web_engine.so` |
| `install.sh`, `icon.ico` | the other editions'; `install-mac.sh` and `icon.icns` are this one's |
| `.github/` | CI runs on the Linux repository. `.github/scripts/invariant_checks.py` **does** come across, because the suite runs it |
| `test_upgrade.py` | it checks an old `browser.py` out of the repository it is in, and this edition's history is one commit long. It comes across the first time a port has two commits to stand between |
| the `_*.py` harnesses | developer screenshot tools, never shipped |

The experimental engine pane is worth one more line, because it is the
only dropped feature with no settings row: it is a **shortcut**
(`Ctrl+Shift+E`) bound only when `engine_pane` imports, and that module
does not come across. So there is nothing in Settings, nothing in the
README's key table, and no dead switch — the shortcut simply is not
bound. Tested.

---

## Speed — what was found, what was changed, what was measured

The actual request was *"not laggy but quick"*, on hardware that does
not exist here. So this section is in three parts and they are kept
apart: **changed and measured here**, **changed and argued**, and **only
a Mac can say**.

### a. arm64 all the way down — *changed, cannot be measured here*

A Rosetta-translated Chromium is the single largest source of lag
available on an Apple Silicon Mac, and the worst kind: it starts, it
runs, and it feels broken with nothing anywhere saying why.

`install-mac.sh` now asks `sysctl -n hw.optional.arm64` (**not**
`uname -m`, which tells a translated shell `x86_64` and says nothing
about the machine), prints the architecture of the hardware, of the
Python and of the PyQt6 wheel's own Mach-O, and **refuses, loudly, with
the three commands that fix it**, when an Apple Silicon Mac is handed an
x86_64 Python or an x86_64 Qt. `--force` is there for somebody who means
it. `sysctl.proc_translated` is printed too.

Why both the Python **and** the wheel are checked, rather than just the
Python: the PyQt6 *bindings* wheel is `universal2` and carries both
architectures, but `PyQt6-Qt6` and `PyQt6-WebEngine-Qt6` — which are
Qt and Chromium themselves, and all of the weight — ship as **separate
`macosx_11_0_arm64` and `macosx_10_14_x86_64` wheels**. pip picks by
the running Python's architecture. So an x86_64 Python silently pulls
an x86_64 Chromium, the bindings look fine because they are fat, and
everything heavy runs translated. That is the trap, and it is why the
check reads the Mach-O of `PyQt6/QtCore` rather than trusting
`platform.machine()` alone.

### b. Startup and the `.pyc` trap — *changed and measured*

`browser.py` is **3.2 MB / 67,169 lines**. Measured on this box with
CPython 3.14.4:

| | three runs |
|---|---|
| `compile()` source → code object | **421 / 422 / 479 ms** (best of 5 each) |
| `marshal.loads` of the cached bytecode | **11 / 11 / 16 ms** |
| **what a launch that cannot cache pays, every time** | **≈ 410–463 ms** |
| every module the bundle ships, compiled | 480 / 484 / 666 ms |
| bytecode size | 4.3 MB |
| **whole process, `import browser`, cache vs read-only cache** | **137 ms vs 1023 ms** — a penalty of **637–886 ms** over two runs |

> The spread is this box, not the measurement: it is the owner's home server
> and it was running its own services throughout. The shape is what
> matters and the shape does not move — loading cached bytecode is
> **thirty to forty times cheaper** than compiling it.

The last row is the one that counts, because it is two real processes
rather than the compiler timed in isolation: `tools/macbench.py --only
coldwarm` starts a child that does nothing but `import browser` and
exit, once with a writable cache prefix and once with a prefix that
exists and **cannot be written to** — which is precisely the
bundle-under-`/Applications` case. 137 ms against 1023 ms.

(The first version of that bench was wrong and is worth recording:
it used `PYTHONDONTWRITEBYTECODE=1` for the cold run, which stops the
*write* and then happily *reads* the `__pycache__` that is already
there. It reported a 134 ms penalty. A cache prefix is the whole of it
in both directions, which is why the bench uses one.)

This is the compiler, not the operating system, so the number is as
valid for the Mac as for here — an M-series core is faster per clock, so
expect less, but the same shape. It matters on macOS because the
read-only case is the *normal* case there:

* `install-mac.sh --system` puts the bundle in `/Applications`, owned by
  root, and the browser does not run as root;
* a bundle that still carries `com.apple.quarantine` is **app
  translocated** — macOS copies it onto a read-only disk image under
  `/private/var/folders` with a fresh random path and runs it from
  there. Nothing in it is writable, and the path is different every
  launch.

Fixed by construction, three ways:

1. the bundle's launcher exports
   `PYTHONPYCACHEPREFIX=$HOME/Library/Caches/browser/pycache`, and
   unsets it again if that cannot be made, so slow beats not starting;
2. `install-mac.sh` runs `compileall` into that same prefix at install
   time, against the files at the absolute path they will be read
   from — so even the **first** launch is a warm one;
3. `install-mac.sh` strips the quarantine xattr, which is what stops
   translocation happening at all (and incidentally what makes the
   camera and microphone grants stick, since those are remembered
   against the bundle's identity).

And `browser.py` sets `sys.pycache_prefix` itself on darwin as a
fallback (`_mac_pycache`), which cannot help `browser.py` — by then it
is compiled — but does cover the ~250 KB of sibling modules imported
after it, and every child process, which inherits the variable.

`tools/macbench.py --only coldwarm` measures the whole thing end to
end in two real processes.

### c. No Linux flags on darwin — *audited, changed, and locked*

Every `QTWEBENGINE_CHROMIUM_FLAGS`, `QT_*` and `QSG_*` the browser
touches was found with an AST walk. The whole list is short:

| Where | What | On darwin |
|---|---|---|
| import time | `--blink-settings=preferredColorScheme`, `--disable-features=WebRtcAllowInputVolumeAdjustment`, `--widevine-path=` | all three are platform-neutral and all three stay |
| import time | `LIBVA_DRIVER_NAME`, `NVD_BACKEND` | behind `Path("/proc/driver/nvidia/version").exists()`, which no Mac has |
| `_install_proxy_flags` | `--enable-features=PlatformHEVCDecoderSupport` | stays — it is the switch, not the decoder |
| `_install_proxy_flags` | `Vaapi*`, `*LinuxGL`, `--ignore-gpu-blocklist` | already behind `sys.platform != "darwin"` |
| `_install_privacy_flags`, `_install_theme_flags` | proxy, DoH, host blocking, colour scheme | platform-neutral |
| `QT_QPA_PLATFORM` | only ever `offscreen`, and only for the suite | — |

**There is no `--disable-gpu-compositing` anywhere in this browser**,
no `--use-angle`, no `--use-gl`, no software rasterizer, no
`--single-process`, no `--in-process-gpu`, and nothing setting
`QT_OPENGL`, `QSG_RHI_BACKEND` or a Quick backend. Qt picks Metal by
itself and is left to.

What is new is that this cannot drift. `MAC_FORBIDDEN_FLAGS` and
`MAC_FORBIDDEN_ENV` name the seventeen switches and nine variables that
would make a Mac worse, each with what it costs, and
`test_macbranch.py` does two things with them:

* **builds the real darwin flag set** — runs `_install_proxy_flags`
  with a faked platform — and asserts none of them is in it;
* **lints the source**: a forbidden name anywhere outside a darwin
  guard is a failure. The two places that name them as *data* (the list
  itself, and the catalogue of switches Settings offers) are excluded by
  position, not by a substring, so the lint cannot be defeated by
  accident.

That lint found a real one. **Settings offered him ten Chromium
switches, and three of them are Linux's**: VA-API hardware decode, the
ChromeOS direct decoder, and `--ignore-gpu-blocklist`. The first two do
nothing on macOS but print a warning per launch — he ticks "hardware
video decode", restarts, and nothing is different. The third is worse
because it **is** honoured there: it switches on every GPU feature
Chromium has blocked for a driver it knows to be broken — raster, WebGL,
the lot — not only the decoder he wanted. `Browser.safe_flags()` now
filters the catalogue per platform; a Mac is offered **seven**, Linux
and Windows keep all ten.

> **Handed to whoever owns the Linux file, not fixed here:**
> `config["safeFlags"]` is written by Settings, flashes "applies after a
> restart", and is then **read by nothing at launch** — not
> `_startup_flags`, not `_install_privacy_flags`, not
> `_install_proxy_flags`. Every one of those ten switches is a dead
> switch on all three editions. That is not a Mac bug and it is not
> mine to fix behind someone's back.

### d. No translucency — *already right, now tested*

`WA_TranslucentBackground` is only ever asked for by the glass look,
and the condition already excludes darwin (and win32). Kept, because a
surface with an alpha channel and no opaque region makes the compositor
blend the whole window every frame and gives up the fullscreen
direct-scanout path — and because Qt gives a `QMainWindow` no way to ask
for an `NSVisualEffectView`, so the alpha would buy nothing but a hole
to the desktop. Glass sits on the theme's solid base there, as on
Windows. `test_macbranch.py` holds both halves.

### e. Retina: four times the pixels — *changed and measured*

Everything the browser paints **itself** costs 4× on a 2× framebuffer,
and a `QWidget` is painted on the CPU. The audit:

* **no `QGraphicsEffect` of any kind** — no blur, no drop shadow, no
  opacity effect, nowhere. Those are the expensive ones and there were
  none to drop. A test asserts none appears later.
* **every `box-shadow` and `backdrop-filter` is in page CSS** (the start
  page, the themes), which Chromium composites on the GPU. Not our
  raster.
* **five `paintEvent`s in the whole file.** `GroupTabBar`, `UrlBar`,
  `FavoritesTree` and `TaskBar` are a handful of `fillRect`s and some
  text, and none of them is driven by a timer.
* **the Dock look was the whole problem**, and it was a real one — and
  note which look that is: `macos`. The one a Mac is most likely to be
  wearing was the one with the per-frame cost.

`Dock._paint_glass` lays down **twelve overlapping antialiased rounded
rectangles** to make the island's soft shadow, plus a gradient over the
whole island and two edge strokes — and then `paintEvent` drew up to ten
favicons by handing `drawPixmap` a *different destination size every
frame*, with `SmoothPixmapTransform` on, because the magnification
changes the size continuously. All of it, every frame of the ease.

None of the glass changes while the mouse moves. So:

* `Dock._glass()` paints the island **once** into a `QPixmap` at the
  screen's own `devicePixelRatioF()` and blits it. The cache key is the
  size, the palette and the ratio — so a theme switch repaints it, and a
  window dragged from a 2× laptop display to a 1× monitor gets a new one
  rather than a soft one.
* `Dock._icon_at()` scales each icon **once per size it is drawn at**.
  There are at most `ICON_MAX - ICON + 1` = 13 of those, and the cache
  is keyed on the ratio too.

`tools/macbench.py --only paint` measures exactly this. **Each ratio is
its own process**, started with `QT_SCALE_FACTOR=1` and `=2`, because
that variable is read when the `QApplication` is built and the thing
being measured is what a *real* 2× backing store costs. Median of 40
paints, ten pins, a 572×106 dock:

| | 1× (572×106 surface) | 2× (1144×212 surface) |
|---|---|---|
| every frame, as it was | 0.739 / 1.189 ms | **2.159 / 1.965 ms** |
| cached, as it is now | 0.138 / 0.242 ms | **0.336 / 0.330 ms** |
| saved | 81.3 % / 79.6 % | **84.4 % / 83.2 %** |
| share of a 120 Hz frame (8.33 ms) | 9→2 % / 14→3 % | **26→4 % / 24→4 %** |

Two runs, because the absolute numbers move with what else this
server is doing; the share saved does not, and it is **79–84 %**.

Two more things worth reading off it. The old path really does cost
**1.7–2.9× more at 2×** than at 1× — not the full 4×, because some of
those twelve rounded rectangles is geometry rather than fill. And the
dock's own painting was eating **about a quarter of a 120 Hz frame**
before the page it floats over had been composited at all. On a 60 Hz
1× Linux desktop the same change is real and nobody would have
noticed; that is why it is in the Mac job.

> **The first version of this bench was wrong and the numbers it gave
> are not the ones above.** It painted into a pixmap whose ratio it set
> by hand, in a 1× process — but `_glass()` and `_icon_at()` ask the
> *widget* for its `devicePixelRatioF`, so the cached path was blitting
> a 1× island scaled up to fit a 2× surface. Cheaper than the real
> thing, and blurrier. It reported 4.83 ms → 1.12 ms and "71–78 %
> saved" at 2×. Recorded because a measurement that flatters the change
> being measured is the worst kind.

**And it draws the same dock.** A cache that draws something subtly
different would make "84 % faster" the wrong thing to be pleased about,
so `test_macpaint.py` renders both paths into the same surface and
differences them, at whatever scale factor the process was started
with. `tools/runall.sh` runs it at 1× and 2×. At 2×: **24 of 242,528
pixels differ, worst channel delta 2** — the island is exact, because
it is blitted from a pixmap painted by the very same `_paint_glass`,
and the rest is two smooth filters disagreeing in the last bit of an
icon edge. At 1× it is 6 % of pixels with a worst delta of 5, from the
same cause and equally invisible. Both images were looked at side by
side as well as differenced.

### f. 120 Hz ProMotion — *changed and tested*

Two findings:

1. **One hardcoded frame existed**, and it was in the macOS look:
   `Dock._ease.setInterval(16)`. Worse than coarse — the ease was
   `self._reach += (target - self._reach) * 0.28`, a fixed fraction
   **per tick**, so on a 120 Hz display the timer fires twice as often
   and *the whole animation arrives in half the time*. The dock on a
   MacBook Pro would have felt different from the dock on an external
   monitor, for no reason anybody could name.

   Now: `Dock.frame_ms(hz)` asks the screen (`QScreen.refreshRate()`),
   floored and clamped to 6–20 ms — 60 Hz still gets exactly the 16 ms
   it was written with, 120 Hz gets 8, a 144 Hz panel gets 6, and a
   screen that will not say falls back to 60. `_step` measures the real
   elapsed time and eases at a *rate* (`EASE_RATE = 0.0205445`, which is
   `0.28 per 16 ms` re-expressed — the test proves
   `1 - e^(-rate·16) = 0.28`), so the animation takes the same
   wall-clock time at any refresh rate and a dropped frame catches up
   instead of crawling. The gap is clamped to 100 ms so a wake from App
   Nap does not snap the bulge into place.

   The rate is asked of the window server **once per hover**, in
   `_ease_on`, never per frame — which is also how a window dragged
   between two screens with different refresh rates picks up the new
   one.

2. **Nothing spins a repaint timer while the screen is still.** Checked
   all 53 `QTimer`s. The dock's ease stops itself when the bulge
   settles; the taskbar's clock starts on `showEvent` and stops on
   `hideEvent`; the URL bar's progress line is driven by the engine's
   `loadProgress` signal and repaints only on a change of more than 1%.
   There is no idle animation anywhere — and an idle timer is the one
   thing on an M-series Mac you can actually hear.

### g. App Nap and timer coalescing — *changed and tested*

The browser builds ten repeating timers in `Browser.__init__`, within
microseconds of each other. **Four of them want exactly 30,000 ms** —
the media watch, the scheduled-downloads tick, the track notice and the
session save. They have therefore fired *in the same iteration of the
event loop*, on the UI thread, every thirty seconds, for the life of
every window ever opened. On Linux that is a small hiccup. On macOS it
is two separate problems:

* the system groups timer wakeups so the processor can idle, and a
  timer that insists on an exact instant stops that happening;
* **App Nap** holds a backgrounded app's timers and then releases
  everything due at once — so those four, plus whatever else was held,
  land together on the thread that draws.

`housekeep(timer, every, name)` now starts all eight repeating chores.
On Linux and Windows it is `setInterval(every); start()` and *nothing
else* — bit-identical to before, which is why the Linux suite cannot
regress on it. On darwin it additionally:

* sets `Qt.TimerType.VeryCoarseTimer`, offering the system a second of
  slack to coalesce in (free for a 20–60 s chore);
* gives each chore its own deterministic slot in the first half of its
  interval (`housekeep_offset`, by name, so two windows agree and a
  restart does not shuffle them), so nothing lands together. **Nothing
  is skipped and nothing runs less often** — the interval is unchanged.

The one-second download tick, the two-second now-playing poll and the
five-second call tick are deliberately left precise and are asserted to
be: a coarse timer on the now-playing label would make the dock's
transport feel late.

### h. Hardware video decode — *measured, and it is the worst finding here*

VideoToolbox is automatic: Chromium on macOS uses it without being
asked and there is no flag to add. So the real question is the
**build**, and the answer turned out to matter far more than the
hardware.

**Measured on this box** — `tools/macbench.py --only codecs`, which
asks the engine itself with `canPlayType` and
`MediaSource.isTypeSupported`, against the PyPI wheel
`PyQt6-WebEngine 6.11.0` / `PyQt6-WebEngine-Qt6 6.11.2`:

| | |
|---|---|
| H.264 (baseline **and** high) | **no** |
| HEVC | **no** |
| AAC | **no** |
| `MediaSource.isTypeSupported(avc1)` | **false** |
| VP8, VP9, AV1 | yes |
| Opus, Vorbis, MP3, FLAC | yes |

A real 1080p60 H.264 clip served over loopback confirms it from the
other side: the element fires `error` with
`DEMUXER_ERROR_NO_SUPPORTED_STREAMS: FFmpegDemuxer: no supported
streams`. This is not a hardware question and not a flag question —
those decoders are **not in the binary**. Any build that may be
redistributed is built `ffmpeg_branding=Chromium`, which leaves the
patent-encumbered ones out.

**What that means for the Mac, where pip is the obvious install:**

* YouTube **works** — it serves VP9 and AV1 with Opus.
* **Twitch does not.** It is H.264 only.
* **An `.mp4` does not**, neither its video nor its AAC audio — not
  from a site, not off the disk, not one the browser downloaded.
* **The ARD/ZDF HEVC live streams do not**, and
  `--enable-features=PlatformHEVCDecoderSupport` cannot help: that flag
  permits a platform decoder, it does not supply a demuxer the build
  has not got.
* `calls.py` already tells the truth about this — `callNoH264` is its
  headline verdict and it is in both languages. It is not a new gap in
  the Mac edition; it is a property of the engine the user installed,
  and the browser reports it.

**The fix, verified from source rather than guessed:** Homebrew's
`qtwebengine` formula is built with
`-DFEATURE_webengine_proprietary_codecs=ON` (read out of
`Homebrew/homebrew-core`, `Formula/q/qtwebengine.rb`, 2026-10-26), and
`brew install pyqt` depends on that formula. So on a Mac:

```sh
brew install pyqt        # an engine WITH H.264, HEVC and AAC
BROWSER_PYTHON=/opt/homebrew/bin/python3 sh install-mac.sh
```

and on Apple Silicon that is arm64 native, which is also what §5a
wants. `install-mac.sh` now detects which of the two is installed —
`site-packages` in the engine's path means a wheel — and prints that
paragraph rather than letting him find out from Twitch.

Still unmeasured, and only a Mac can say: whether the **macOS** wheel
behaves identically to the Linux one. It is built by the same project
from the same Qt release, so it is expected to — but "expected to" is
not a measurement. I tried to settle it by scanning the macOS wheel's
227 MB `QtWebEngineCore` Mach-O for ffmpeg decoder symbols and **that
proved nothing**: a release build strips them, and the Linux binary we
*know* plays VP9 comes back negative for `ff_vp9_decoder` too. So it is
question 24, and `macbench.py --only codecs` answers it in five seconds
on the machine itself.

Two smaller ones: AV1 on an M3 or later is decoded in hardware and on
M1/M2 in software (nothing in the browser chooses), and
`tools/macbench.py --only video` plays a real 1080p60 clip over
loopback and reads `webkitDecodedFrameCount` /
`webkitDroppedFrameCount` off the element — skipped on this box, with
the reason named, for exactly the above.

### i. Off the UI thread, and off iCloud — *audited, already right, now tested*

Nothing moved onto the UI thread. The vault's remote store is already
reached on a worker (`vault_job`), which is the one place that used to
block — a hanging `op` bought twenty seconds of no window.

iCloud Drive syncs `~/Desktop` and `~/Documents` when "Desktop &
Documents Folders" is ticked, which is a question in the macOS setup
assistant, so it is on for a lot of people. A browser profile being
uploaded while you browse is a stall with no visible cause. Checked:

| What | Where it goes | Synced? |
|---|---|---|
| config, history, bookmarks, vault, cookie jars | `~/Library/Application Support/browser` | no — iCloud never touches it |
| bytecode cache, the Widevine symlink | `~/Library/Caches/browser` | no |
| downloads, and sorted downloads | `~/Downloads`, subfolders inside it | no |
| screenshots, PDFs | the downloads folder unless he picks otherwise | his choice |

`Info.plist` does carry `NSDesktopFolderUsageDescription` and
`NSDocumentsFolderUsageDescription` — because he may *choose* to save a
download there, and without the key that choice is a crash rather than a
prompt. Nothing the browser writes by itself lands in either. Tested.

### j. The cheap-question rule — *one real offender, fixed*

Each of these is a process spawn or a framework call, and none may run
per frame, per keystroke or per page load:

| Question | How it was asked | Now |
|---|---|---|
| `say -v ?` — which voices exist | already once per run, memoised on the window | unchanged; it cannot change without him installing a voice |
| `CGPreflightScreenCaptureAccess` | once per open of the microphone/camera page, from `verdicts()` | unchanged, and **deliberately not cached for the run**: he can tick the box in System Settings while the browser is open, and a cached "no" would be a lie |
| `engine_facts()` — the 200 MB Mach-O scan | cached for the run, and **skipped entirely** on darwin because both markers are Linux desktop things | unchanged |
| `ps -o rss=,time=` — per-tab memory | **once per pid.** `tab_costs()` walks every tab, and `cpu_hogs()` walks every renderer from a 30 s timer — so a ten-tab window was **ten fork/exec pairs per pass, on the UI thread** | `mac_cost_prime()` asks **one** `ps -o pid=,rss=,time= -p a,b,c` for all of them and leaves the answers where the per-pid reader finds them, good for 0.5 s. Both callers prime it; it is a no-op on every other platform, so no call site needed a branch |

### The benchmark harness

`browser-mac/tools/macbench.py`, shipped in the edition, with
`tools/lagtest.html` (reused from the Android edition — it is a page
built to be measured). Eight benches: `compile`, `paint`, `startup`,
`coldwarm`, `scroll`, `video`, `tabs`, `timers`. It prints a table and
writes JSON.

**The Linux baseline is in `logs/macbench-linux.json`. The macOS column
is empty and labelled `unmeasured`.** It is not estimated and not scaled
from the Linux number. `sh macselftest.sh` on a Mac fills it in.

---

## What is proven, and where

| | |
|---|---|
| `test_macbranch.py` (in `~/browser`, runs in the Linux suite) | **250 checks, 0 failed** (was 143). Every darwin branch with `sys.platform` faked; every parser fed real input (`ps` output for one pid and for many, `say -v ?`, the CDM paths and the spaces in them); the real darwin flag set built and checked against the forbidden list; the source linted for an unguarded Linux flag |
| `test_mac.py` (in `browser-mac`) | **186 checks, 0 failed** (was 109). The edition itself: every font stack, every settings row in both languages, `Info.plist`, the `.icns` walked slot by slot, `install-mac.sh --dry-run`, the Rosetta refusal, the bytecode prefix, the benchmark harness, the self test, and what is and is not in the tree |
| `test_macpaint.py` (new, in `browser-mac`, run at 1× **and** 2×) | the cached dock draws the same dock: 24 of 242,528 pixels differ at 2×, worst channel delta 2. Both images looked at as well as differenced |
| `tools/mac_port.py --check` | **50 markers**, 18 substitutions, every `.py` parses |
| `tools/mac_port.py --to worktree --dry-run` | "would change: nothing" — it is idempotent |
| `tools/macbench.py` | nine benches, Linux column filled in: `logs/macbench-linux.json` and `.txt` |
| the edition's own suite, re-run 2026-10-27 after the history fixes | **85 top-level `test_*.py`, 84 green.** The one red is `test_screenshare.py` — `AbortError` on "picking a screen gives the page a live track", the same standing failure as before any of this work; it needs a real screen |
| the edition's own suite (`tools/runall.sh`), earlier run | **92 files, 90 green.** `test_screenshare.py` is the same standing red; one SIGSEGV teardown flake (`tests/test_masterlock.py`) that exits 0 on its own — see the note below. `test_macpaint.py` green at **both** 1× and 2× |
| the whole Linux suite, with the darwin branches in | **94 test files, 93 green.** The one red is `test_screenshare.py`, which needs a real screen and failed on this box before any of this work. It is the same shared file in both editions: a branch that broke something would break there |

### One thing worth saying about that suite

It was run three times. The **third run is the one above** — 93 of 94,
the standing red, invariants 10/10 — and it is the honest number. The
first two each threw up a handful of extra reds, and they were **not
the same reds**: run one gave `test_media` and `test_msaccounts`
(SIGSEGV), run two gave `test_permreload` (SIGABRT, a
`wrapped C/C++ object of type Browser has been deleted` at teardown),
and `test_perf2` went red in both.

Every one of them passes on its own — `test_perf2` four times out of
four, including in its own suite order — and all four are green in the
run above. The first run had me building the benchmark on the same
eight cores, which is my fault; the second did not, which is why this
was chased properly rather than waved away with "flaky". The thing
that settled it was keeping every test's log instead of the three
lines the runner tails.

For the record, this is **not new**: the previous session's own first
suite log (`logs/linuxsuite1.log`, written before any of this work)
has `test_downloads` exiting 134 — the same shutdown race, on a
different test. This suite has a teardown flake under load and it
moves around. Worth someone's time, and it is not the Mac job's.

---

## What a real Mac still has to answer

**Nothing below is claimed.** Each is a thing this box physically
cannot try. `sh macselftest.sh` walks all of them, in these words, and
writes the answers one to a line. The first thirteen are the original
list; 14–23 are the performance questions §5 could not answer.

1. **Does it start at all.** Qt 6.11 on macOS 12+, PyQt6 from brew
   (`brew install pyqt`; the pip wheel has no H.264/HEVC/AAC, see §5h).
   `sh install-mac.sh`, then right-click → Open.
2. **`osascript -e ... -- text title`.** The `--` is how `getopt` ends
   options, and `osascript` uses `getopt` — but if that platform's one
   does not take it, `--` arrives as `item 1 of argv` and the
   notification reads "--". A wrong notification, not a hole; still the
   single most likely thing here to be wrong.
3. **`caffeinate -w <pid>`** really holding the screen, and really
   letting go when the video stops.
4. **`say -v <voice>`** with a voice from the live listing, and the
   text arriving on stdin rather than being waited for.
5. **Widevine.** Whether the symlink under `~/Library/Caches/browser`
   is accepted by the engine, and whether DRM video then plays. No
   Chrome installed means no CDM and nothing to test.
6. **The icon.** Whether the squircle lines up with the rest of the
   Dock. Fitted to Apple's own grid (824 of 1024, radius 185.4), but
   nobody has seen it next to another icon.
7. **`⌘` vs `Ctrl`.** Qt maps `Ctrl` in a `QKeySequence` to Command.
   Whether every shortcut came through that mapping, or whether one
   reads a raw modifier and now wants the physical Control key —
   `Ctrl`+wheel zoom is the likeliest — is a thing only a keyboard can
   say.
8. **The menu bar.** Qt moves a `QMenuBar`'s actions to the system bar.
   This browser has no `QMenuBar`, so the Mac menu bar will be bare
   except for the automatic items. Not broken; not native either.
9. **Closing the last window.** On a Mac an app normally stays running
   with no window. This one quits, as on Linux — deliberately, because
   without a menu bar or a Dock menu to make a new window, an invisible
   running browser is a browser you cannot get back.
10. **Screen sharing** needs Screen Recording in System Settings. macOS
    has no key and no API for an app to ask, so `install-mac.sh` says so
    in words and nothing in the browser prompts.
11. **The firewall prompt** for the phone receiver, and whether a
    "Deny" can be taken back from System Settings without reinstalling.
12. **`CGPreflightScreenCaptureAccess`** really answering, and the panel
    really saying the right one of its three lines.
13. **Retina.** `NSHighResolutionCapable` is set, so pages should be
    drawn at 2×. Whether the screenshot path assumes 1× is unmeasured —
    and whether the password-field blur still lands on the right
    rectangles at 2×.
14. **arm64, or translated.** `install-mac.sh` prints hardware, Python
    and wheel. Whether all three say arm64 on his machine.
15. **The second launch.** Click to window, timed twice. The `.pyc` work
    predicts a first launch about as fast as the second (the install
    warms the cache) and both well under the 470 ms penalty. Unverified.
16. **120 Hz.** Whether the dock's magnification glides on a ProMotion
    display now that the frame comes from the screen, and whether it
    feels the same on an external 60 Hz monitor.
17. **Video decode.** 1080p60 YouTube and a Twitch stream, fullscreen,
    with Activity Monitor open: CPU percentage and dropped frames.
18. **Idle with ten tabs.** CPU while nothing happens, and whether the
    fan is audible. This is what the timer work in §5g is for and the
    only number that can confirm it.
19. **Coming back from the background.** Ten minutes behind another app,
    then click it: immediate, or a stall first. The App Nap question.
20. **Two screens.** Dragging the window between a 120 Hz and a 60 Hz
    display with the Dock look on — smooth on both, and the chrome still
    sharp (the glass pixmap is re-cut on a ratio change; untested).
21. **HEVC.** Whether an ARD or ZDF live stream plays or says
    "Wiedergabefehler" — **expect the error on a pip-installed engine**;
    §5h says why and what to install instead.
22. **The glass look on a solid base.** Whether it reads as deliberate
    rather than as a mistake, next to real macOS chrome.
23. **Where things land.** A download in `~/Downloads`, and nothing of
    the browser's in Documents, Desktop or iCloud Drive.
24. **Which codecs that Mac's engine really has.** Not a judgement
    call: `python3 tools/macbench.py --only codecs` prints the whole
    table and a verdict. The Linux wheel has no H.264, no HEVC and no
    AAC (§5h); whether the macOS wheel is the same is the one thing a
    binary scan could not settle from here.

### When the answers come back, read them against this first

Not "which questions failed". **Which of the things called verified here
turn out to have been verified against the wrong set.** That is what
2026-10-27 was, eight times in one day, and every instance was a true
statement:

| | the set it was true of | the set it claimed |
|---|---|---|
| a sweep for one of his own strings came back clean, twice | `*.py *.sh *.md *.json` | every file — the hit was in an `Info.plist` |
| "the screenshots are synthetic" | nothing; inherited unread | 43 images |
| `test_histicon.py` green for five days | the page's **source** | the page, which drew nothing |
| "all images verified" | 47 | 49 |
| `test_histrender.py`, 21 green checks | rows that drew | the timestamp path, never exercised |
| "the 16 px icon is a downscale" | how it looked | how it was built — it is its own render |
| "our measurements agree exactly" | two numbers that resembled each other | two methods, never put side by side |
| "the 28 PNGs have no text chunks" | a `head`-truncated listing | 43 PNGs |

None of these were errors of fact. Every one was a correct sentence with
the wrong scope, and six of the eight survived a review by someone who
agreed with it. A green suite, a clean scan and a confident handover are
all compatible with every one of them.

So the useful question of a returned answer sheet is not only what it
says. It is which claim in this document it quietly contradicts —
starting with anything above that says *verified*, *every*, *all*, or
*none*.

---

## Known defects this edition inherits (not macOS-specific)

These are faults of the source tree, carried into the macOS edition because
the edition is generated rather than written. They are listed here so the
next session does not have to rediscover them, and so nobody reads a green
mac suite as "this edition is clean".

### A live privacy leak: the history page tells Google where he has been

`history.html:223` builds every row's icon as

    img.src = "https://www.google.com/s2/favicons?sz=32&domain=" + host;

so opening the history page hands Google the hostname of **every site in his
history**, on every render. The README says browsing data stays local. It
does not.

The browser already has the right mechanism and documents it: `cache_favicon`
keeps icons on disk, and its own docstring says a list that asks fifty sites
for their icons "tells each one of them that he is looking at his bookmarks".
`bookmarks.html` honours that. `history.html` does not.

**Status: fixed in `~/claude/browser-linux`, not here.** The linux-browser
session replaced it with a `siteIcons` bridge slot reading the on-disk store,
plus `test_histicon.py`, which also scans every shipped `.html` for
third-party favicon URLs so it cannot come back in another page. That fix is
uncommitted work in canonical.

**Fixed here now, 2026-10-27.** That reasoning held while nothing was
shipping. It stopped holding the moment this edition got a real tester: the
person whose history would go to Google is not the owner, it is somebody who was
handed a browser and has no way to know. So canonical's commit `eee92d7` was
backported into `~/browser` — the `siteIcons` slot plus `site_icon_data`,
the page's one-call-per-render icon map, and `test_histicon.py` — and the
port carried it in. No hand region: the fix is in the Linux tree, which is
where the rule says features live. `test_histicon.py` is now in `copy_files`
and runs in this edition (`0 checks failed`), and it scans **every** shipped
`.html`, so the call cannot come back on another page.

Verified after the port: `--check` passes 50/50 markers, `--to worktree
--dry-run` says *would change: nothing*, and the only remaining mention of
`s2/favicons` anywhere in the edition is the comment in `history.html` that
explains why it is gone.

### The DST one: already fixed here

For the record, since it travelled with the same report: `_day_start` returns
local midnight and three callers stepped days with a flat `86400`, which lands
on 01:00 or 23:00 and never a midnight. The clocks went back 2026-10-25, so it
was live. This edition already carries the calendar-step fix (`_day_before` /
`_day_after`, browser.py:17723 and :17742) and `test_daystep.py` passes here —
`all good`, exit 0, run on this box. No action needed.

### The app icon is a blob at 16 px, and not for the reason it looks like

Found 2026-10-27 by `server-be`, who unpacked `icon.icns` and read all
eleven images in it rather than the one PIL hands back. The symptom is real:
at 16 px the icon is a purple blob on a dark squircle. No meridians, no
orbit ring, no moon. It reads as "a round thing", not as a browser. Visible
in Finder list view and the sidebar; the Dock and ⌘-Tab take 128 px and up
and look right.

**The mechanism reported with it was wrong, and the wrong fix follows from
it.** It looks like a downscale of the 1024 px artwork. It is not.
`tools/mkicns.py:build()` calls `render(svg_bytes, size)` once per slot, so
every entry is its own `QSvgRenderer` pass over `icon.svg`. Measured rather
than read: the shipped 16 px entry differs from a downscale of the 1024 px
entry in **152–177 of its 256 pixels counting any RGB difference**, or
88–133 counting only deltas greater than 2, under Lanczos, bicubic,
bilinear, box and nearest alike. A resample would have scored 0 under one
of them.

The method belongs with the number, and this is where that was learned:
`155/256` is not a fact, `155/256 RGBA with Δ>2` is. Two sessions measured
this pair, quoted bare counts, and spent a round believing they disagreed
— the only variable was whether `max` ran over RGBA or RGB, and the icon is
a rounded square on transparency, so including alpha lifts every count
wherever the edge lands. Both readings put every cell between 88 and 200
of 256. The conclusion never depended on which.

So the cause is the artwork, not the pipeline. The meridians and the orbit
ring are strokes that fall well under one pixel wide at 16 px; antialiasing
turns a sub-pixel stroke into a faint grey wash whatever renders it, and
rendering from vector at the small size does not help. Somebody acting on
"it is a downscale" would go and change the resampling filter and achieve
exactly nothing.

The arithmetic says so before any pixel does. `icon.svg` is drawn on a 512
viewBox, so a stroke scales by `size / 512`:

| element | stroke in the SVG | at 16 px | at 32 px | at 64 px |
|---|---|---|---|---|
| meridians and parallels | 10 | **0.31** | 0.63 | 1.25 |
| orbit ring | 17 | **0.53** | 1.06 | 2.13 |
| moon | `r="17"`, so ⌀ 34 | **1.06** | 2.13 | 4.25 |
| squircle outline | 6 | **0.19** | 0.38 | 0.75 |

That table is worth more than an explanation because it **predicts** what is
on screen: at 32 px the ring and the moon clear a pixel and the meridians do
not, and that is exactly what the 32 px entry shows — a globe with a ring and
one vertical smudge where four lines should be. A cause that only explains is
a story; one that predicts is the cause.

Which fixes the scope of the fix, read at true pixels rather than through a
smoothed contact sheet:

* **64 px and up: fine.** Meridians, ring and moon all legible.
* **32 px: marginal, but it reads.** Globe and ring are there.
* **16 px: gone.** A purple blob; the moon is one teal pixel.

So `icp4` is the slot that is actually broken. `icp5`/`ic11` would improve
and are not failing.

**The fix is a second, simplified `icon-small.svg`** — one meridian, one
equator, a thicker orbit, no moon, every stroke a whole pixel or more — and
two lines in `mkicns.py` choosing it below 64 px. If that turns into a
fiddle, 16 px alone is the slot that earns it. New artwork, so it goes
through `ig2` per the house rule, not hand-placed pixels.

**Deliberately not done yet, and this is a scoping call rather than an
oversight.** It is cosmetic, it changes no answer in the list below, and the
package already in the tester's hands carries the current icon — rebuilding
for it would mean a third tarball and a re-read of the pinned image verdict
in `pack/evidence/`, to fix a blur in one Finder view. It is worth doing
before any wider release, and it costs no Mac to do or to verify.

### The translation blob cannot take a Linux-side edit without a hand merge

Found 2026-10-27 while backporting the favicon fix. The `en` and `de`
translation dictionaries are each **one line** of about 1611 keys. `git
merge-file` is line-based, so when the Linux side changes any string inside
that line and the Mac side has also changed it (which it always has — the
substitutions rewrite four keys there), both sides differ from the base on the
same line and the merge has to stop. It is not a judgement call and it is not
re-base-specific: **any** Linux edit to a user-facing string conflicts.

The two conflicts measured against canonical earlier were read as a symptom of
the re-point. They are not. They are this.

Resolving it costs two steps and no hand region:

1. make the identical change in the edition's `browser.py` (both language
   halves), so ours and theirs agree on what the string should say;
2. refresh `tools/_base/browser.py.gz` from `~/browser/browser.py`, which
   records the resolution — the port does exactly this to the base itself
   after every successful worktree run.

Worth fixing properly one day by splitting the dictionaries one key per line.
Until then, this is the procedure, and it is the reason a trivial string fix
on the Linux side is not free here.

## When this is ported again

```sh
cd ~/claude/browser-mac/browser-mac
python3 tools/mac_port.py --to main --dry-run
python3 tools/mac_port.py --to main
PATH=~/claude/browser-mac/.venv/bin:$PATH sh tools/runall.sh
```

`ported_from` is `28a6995` **plus the working tree**
(`ported_from_worktree: true`): the darwin branches are written in
`~/browser` and were still uncommitted when this was written. Once they
are in `main`, a normal `--to main` hands the same change in from both
sides, which `git merge-file` takes without a conflict, and the flag
goes back to `false` by itself.
